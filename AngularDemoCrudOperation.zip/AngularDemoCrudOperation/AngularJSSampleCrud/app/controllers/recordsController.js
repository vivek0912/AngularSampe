(function (app) {
    var recordsController = function ($scope, recordService) {
       
        var init = function () {
          
            $scope.Records = recordService.getRecord(0);
       };

        var index = 0;

        $scope.nextRecord = function () {
        
            index++;
            if (recordService.isOverflow(index))
            {
                index--;
            }
            $scope.Records = recordService.getRecord(index);

        }

        $scope.previousRecord = function () {
         
            index--;
            if (index < 0) {
                index = 0;
            }
            $scope.Records = recordService.getRecord(index);
        }

        $scope.addRecord = function () {
            index--;
            if (index < 0) {
                index = 0;
            }
            $scope.Records = recordService.addRecord(index);
        }

        $scope.deleteRecord = function () {
         
            $scope.Records = recordService.deleteRecord(index);
            index--;
        }      

        init();
    };

    app.controller("recordsController", ["$scope", "recordService", recordsController]);
}(angular.module("demoApp")));