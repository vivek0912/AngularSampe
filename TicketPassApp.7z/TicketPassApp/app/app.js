define(	
	function(require,exports,module)
	{		
		var app=require("app");
		var angular=require("angular");		
		var asyncLoader = require('angular-async-loader');
		require("jquery");
		require("jqueryUI");
		require("bootstrap");
		require("angular-ui-router");
		require('angular-async-loader');
		require('bootstrapui');
		require("angular-ui-bootstrap");	
		require("angular-sanitize");
		require("angular-elastic");		
        require("Sortable");
        require("angular-legacy-sortable");
        require("form-utils");
        require("form-builder");
        require("form-builder-bootstrap-tpls");
        require("form-viewer");
        require("form-viewer-bootstrap-tpls");	
		require("angular-animate");
		require("angular-route");
		require("angular-translate");
		require("angular-translate-loader-static-files");
		require("ocLazyLoad-require");
		require("angular-moment");
		require("angular-validation");
		require("ng-xeditable");				
        require("datatables");
        require("angular-datatables-bootstrap");
        require("angular-datatables-colreorder");
        require("angular-datatables-columnfilter");
        require("angular-datatables-colvis");
        require("angular-datatables-fixedcolumns");
        require("angular-datatables-fixedheader");
        require("angular-datatables-scroller");
        require("angular-datatables-tabletools");
        require("angular-datatables-buttons");
        require("angular-datatables-select");        
        require("FileUploader");
        require("FileUploadershim");
        require("imagecrop");
        require("Qr_Code"); 
        require("Qrcode_UTF8");    
        require("angular-qrcode"); 
        require("angular-massautocomplete"); 
        require("angular-chart");
		require("chart");
		require("chosenmin");
		require("prism");
        

		 
		var app=angular.module("app",["xeditable","ui.router","ngAnimate","ui.bootstrap","ngRoute","chart.js",
			"pascalprecht.translate","oc.lazyLoad","angularMoment","validation","validation.rule",
			"ngFileUpload","ngImgCrop","monospaced.qrcode","MassAutoComplete","ng-sortable","mwFormUtils","monospaced.elastic","mwFormBuilder","mwFormViewer"]);
		app.config(["$translateProvider",
			function($translateProvider){$translateProvider.useStaticFilesLoader(
				{prefix:"static/i18n/message.",suffix:".json"}),
			$translateProvider.useSanitizeValueStrategy("escape"),
			//$translateProvider.preferredLanguage("zh-tw")}]);
		    $translateProvider.preferredLanguage("en")}]);
		app.config(["$ocLazyLoadProvider",function($ocLazyLoadProvider)
			{$ocLazyLoadProvider.config({jsLoader:requirejs,debug:!1,events:!0,cache:!1})}]);
		app.config(["$validationProvider",function($validationProvider)
			{$validationProvider.setErrorHTML(function(msg,element,attrs)
				{return'<span class="fa fa-info-circle red"><small><strong>{{"'+msg+attrs.placeholder+'"}}</strong></small></span>'}),
			$validationProvider.setSuccessHTML(function(msg,element,attrs){});
			var expression={required:function(value,name){return!!value}},
			defaultMsg={required:{error:"Please fill in your "},
			email:{error:"This should be "},
			minlength:{error:"This should be longer "},
			number:{error:"This should not be a negative number"},
			date:{error:"Can't do set expired_date before issue_date"}};
			$validationProvider.setExpression(expression).setDefaultMsg(defaultMsg)}]);
		    app.run(function(editableOptions){editableOptions.theme="bs3"});		
		    asyncLoader.configure(app);
		    module.exports=app;	
		    angular.module("app").factory('myInterceptor', ['$q','$location','$rootScope', function($q,$location,$rootScope,config) {  
		    	 return{
				    request : function(config) { 
				    	var UserDetails = JSON.parse(window.localStorage.getItem("UserDetails")); 
				    	if(UserDetails)
				    	{	
				    	 config.headers['token'] = UserDetails.AuthToken; //'dgauthtoken ' +session.UserDetails.AuthToken;
				    	 config.headers['Content-Type'] = 'application/json; charset=utf-8';	        
				    	}
				    	else
				    	{
				    	  config.headers['token'] = ''; //'dgauthtoken ' +session.UserDetails.AuthToken;
				    	   config.headers['Content-Type'] = 'application/json; charset=utf-8';	
				    	}

				    	return config;
				    },
				    responseError : function(response) {
				        if (response.status === 404 || response.status === 401) 
				        {       
				        	$location.path("/user/login");
				        	
				        }else if(response.status=== 500)
				        {
				        	 $rootScope.$broadcast( 'httpError', { message: 'An unexpected error has occurred. Please try again.' } ); 
				        }	
				        
				        return $q.reject(response);
				    }
    			 }
			}]); 
			angular.module("app").factory("dataFactory", function() {			    
			     var visitor;
			     var exhibitor;
			     var id;
			     var siteserver;
			     var pagename;
			     var companyId;
			     var visitorname;
			     var event;
			     var role;
			     var surveyformId;
			     var surveyformdata;
			     var siteserverId;
			     var responseFormdetails;
			     var selectedEvent;
		        return {
		            getUserId: function () {
		            	return localStorage.getItem("userId");
		            },
		            setUserId: function(value) {
		               localStorage.setItem("userId", value);
		            },
		            getvisitor: function () {
		                return localStorage.getItem("visitor"); 
		            },
		            setvisitor: function(value) {
		                localStorage.setItem("visitor", value);
		            },
		            getvisitorProfile: function () {
		                return JSON.parse(localStorage.getItem("visitorProfile"))	
		            },
		            setvisitorProfile: function(value) {
		                localStorage.setItem("visitorProfile", JSON.stringify(value));
		            },
		             getvisitorId: function () {
		                return localStorage.getItem("visitorId"); 
		            },
		            setvisitorId: function(value) {
		                localStorage.setItem("visitorId", value);
		            },
		            getvisitorObject: function () {
		            	 return JSON.parse(localStorage.getItem("visitorobj"))		                 
		            },
		            setvisitorObject: function(value) {
		                localStorage.setItem("visitorobj", JSON.stringify(value));
		            },
		            getexhibitor: function () {    
		                return  JSON.parse(localStorage.getItem("exhibitor"))
		            },
		            setexhibitor: function(value) {		
		                localStorage.setItem("exhibitor", JSON.stringify(value));               
		            },

		            getEventId: function () {		               
		                return localStorage.getItem("eventid");    
		            },
		            setEventId: function(value) {		               
                        localStorage.setItem("eventid", value);
		            },
                     getSiteServerId: function () {
		                //return id;
		                 return localStorage.getItem("siteserverId");   

		            },
		             setSiteServerId : function(value) {
		                //id= value;
		                localStorage.setItem("siteserverId", value);
		            },
		            getPreviousPageName:function(){
		            	return localStorage.getItem("pagename");
		            },
		            setPreviousPageName : function(value){
		            	localStorage.setItem("pagename", value);
		            },
		             getSurveyPage:function(){
		            	return localStorage.getItem("surveypage");
		            },
		            setSurveyPage : function(value){
		            	localStorage.setItem("surveypage", value);
		            },
		            setEvent: function(value) {		            	
		            	localStorage.setItem("event", JSON.stringify(value));		               
		            },
		            getEvent: function () {		            	           
		                return  JSON.parse(localStorage.getItem("event"))
		            },
		            getCompanyId: function () {
		                //return companyId;
		                return localStorage.getItem("companyId");
		            },
		            setCompanyId: function(value) {
		                //companyId= value;
		                localStorage.setItem("companyId", value);
		            }, 
		            getVisitorName:function()
		            {
                       return visitorname;
		            },
		            setVisitorName:function(value){
                       visitorname=value;
		            },  
		            getSiteServer: function () {
		                return siteserver;
		            }, 
		            setSiteServer: function(value) {
		                siteserver= value;
		            },
		            getRole: function () {
		                return role;
		            }, 
		            setRole: function(value) {
		                role= value;
		            },
		            getsurveyformId: function () {
		                return localStorage.getItem("surveyFormId");
		            }, 
		            setsurveyformId: function(value) {
		                localStorage.setItem("surveyFormId", value);
		            },
		             getsurveyformObj: function () {
		                return JSON.parse(localStorage.getItem("surveyFormObj"));
		            }, 
		            setsurveyformObj: function(value) {
		                localStorage.setItem("surveyFormObj", JSON.stringify(value));
		            },
		            getsurveyformdata: function () {
		                return JSON.parse(localStorage.getItem("surveyFormData"));
		            }, 
		            setsurveyformdata: function(value) {
		                localStorage.setItem("surveyFormData", JSON.stringify(value));
		            },
		             getsurveyresponsedata: function () {
		                return  JSON.parse(localStorage.getItem("surveyresponsedata"))
		            }, 
		            setsurveyresponsedata: function(value) {
		                localStorage.setItem("surveyresponsedata",JSON.stringify(value))
		            },
		             getSelectedEvent: function () {		               
		                return selectedEvent;    
		            },
		            setSelectedEvent: function(value) {	              
                        selectedEvent= value;
		            },
 					getSurveyForm: function () {
		               return localStorage.getItem("surveyForm")
		            },
		            setSurveyForm: function(value) {
		                localStorage.setItem("surveyForm",value)
		            },		            
					getSurveyProfile: function () {
		               return localStorage.getItem("surveyProfile")
		            },
		            setSurveyProfile: function(value) {
		                localStorage.setItem("surveyProfile",value)
		            },		            
					getVisitorPage:function(){
		            	return localStorage.getItem("visitorpage");
		            },
		            setVisitorPage : function(value){
		            	localStorage.setItem("visitorpage", value);
		            },
		            getAllVisitor:function(){
		            	return localStorage.getItem("allvisitor");
		            },
		            setAllVisitor : function(value){
		            	localStorage.setItem("allvisitor", value);
		            },	
		            getAllExhibitor:function(){
		            	return localStorage.getItem("allexhibitor");
		            },
		            setAllExhibitor : function(value){
		            	localStorage.setItem("allexhibitor", value);
		            },	
		            getAllUser:function(){
		            	return localStorage.getItem("alluser");
		            },
		            setAllUser : function(value){
		            	localStorage.setItem("alluser", value);
		            }, 
		            getUserRole: function () {
		                return localStorage.getItem("userrole");
		            }, 
		            setUserRole: function(value) {
		               localStorage.setItem("userrole", value);
		            },  
		            getEventType: function () {
		                return localStorage.getItem("eventtype");
		            }, 
		            setEventType: function(value) {
		               localStorage.setItem("eventtype", value);
		            }      
		        };
		        
			})	

		    app.config(['$httpProvider', function($httpProvider) {  
				    $httpProvider.interceptors.push('myInterceptor');
			}]); 
			//create directive for verify password
			angular.module("app").directive("passwordVerify", function() {
   				return {
	     		 	require: "ngModel",
	     			scope: {
	     	  	 	passwordVerify: '='
	     		 	},
		 		 	link: function(scope, element, attrs, ctrl) {
		  		 		scope.$watch(function() {
		     		    var combined;

		        		if (scope.passwordVerify || ctrl.$viewValue) {
		           			combined = scope.passwordVerify + '_' + ctrl.$viewValue; 
		       		 	}                    
		       	 		return combined;
		   			 }, function(value) {
		       				 if (value) {
		            			ctrl.$parsers.unshift(function(viewValue) {
		              			var origin = scope.passwordVerify;
		              			if (origin !== viewValue) {
		                   					 ctrl.$setValidity("passwordVerify", false);
		                   					 return undefined;
		                		} 
		                		else {
		                    		ctrl.$setValidity("passwordVerify", true);
		                    		return viewValue;
		                		}
		            			});
		       				}
		    			});
		 			}
   				};
			});
			angular.module("app").directive('contactType', function() {
			  return {
			    restrict: "E",    
			    templateUrl:'./app/event/eventdetails/ContactType.html',
			    controller: function($rootScope, $scope, $element) {    
			      $scope.contacts = $rootScope.GetContactTypes;     
			      $scope.Delete = function(e) {      
			        //remove element and also destoy the scope that element
			        $element.remove();
			        //$scope.$destroy();
			      }
			    }
			  }
			});
			angular.module('app').directive('fileDropzone', function() {
			  return {
			    require: '^?form',
			    restrict: 'A',
			    scope: {
			      file: '=',
			      fileName: '=',
			      dropzoneHoverClass: '@'
			    },
			    link: function(scope, element, attrs, form) {
			      var checkSize, getDataTransfer, isTypeValid, processDragOverOrEnter, validMimeTypes;
			      getDataTransfer = function(event) {
			        var dataTransfer;
			        return dataTransfer = event.dataTransfer || event.originalEvent.dataTransfer;
			      };
			      processDragOverOrEnter = function(event) {
			        if (event) {
			          element.addClass(scope.dropzoneHoverClass);
			          if (event.preventDefault) {
			            event.preventDefault();
			          }
			          if (event.stopPropagation) {
			            return false;
			          }
			        }
			        getDataTransfer(event).effectAllowed = 'copy';
			        return false;
			      };
			      validMimeTypes = attrs.fileDropzone;
			      checkSize = function(size) {
			        var ref;
			        if (((ref = attrs.maxFileSize) === (void 0) || ref === '') || (size / 1024) / 1024 < attrs.maxFileSize) {
			          return true;
			        } else {
			          alert("File must be smaller than " + attrs.maxFileSize + " MB");
			          return false;
			        }
			      };
			      isTypeValid = function(type) {
			        if ((validMimeTypes === (void 0) || validMimeTypes === '') || validMimeTypes.indexOf(type) > -1) {
			          return true;
			        } else {
			          alert("Invalid file type.  File must be one of following types " + validMimeTypes);
			          return false;
			        }
			      };
			      element.bind('dragover', processDragOverOrEnter);
			      element.bind('dragenter', processDragOverOrEnter);
			      element.bind('dragleave', function() {
			        return element.removeClass(scope.dropzoneHoverClass);
			      });
			      return element.bind('drop', function(event) {			      	
			        var file, name, reader, size, type;
			        if (event != null) {
			          event.preventDefault();
			        }
			        element.removeClass(scope.dropzoneHoverClass);
			        reader = new FileReader();
			        reader.onload = function(evt) {
			          if (checkSize(size) && isTypeValid(type)) {
			            scope.$apply(function() {
			              scope.file = evt.target.result;
			              if (angular.isString(scope.fileName)) {
			                return scope.fileName = name;
			              }
			            });
			            if (form) {
			              form.$setDirty();
			            }
			            return scope.$emit('file-dropzone-drop-event', {
			              file: scope.file,
			              type: type,
			              name: name,
			              size: size
			            });
			          }
			        };
			        file = getDataTransfer(event).files[0];
			        if (!angular.isObject(file)) {
			          return;
			        }
			        name = file.name;
			        type = file.type;
			        size = file.size;
			        reader.readAsDataURL(file);
			        return false;
			      });
			    }
			  };
			});

			// Uniq1u filter for sorting arrays Json

			
	       angular.module('app').filter('startFrom', function () {
				return function (input, start) {
					if (input) {
						start = +start;
						return input.slice(start);
					}
					return [];
				};
			});

			angular.module('app').filter('unique', function () {

			  return function (items, filterOn) {

			    if (filterOn === false) {
			      return items;
			    }

			    if ((filterOn || angular.isUndefined(filterOn)) && angular.isArray(items)) {
			      var hashCheck = {}, newItems = [];

			      var extractValueToCompare = function (item) {
			        if (angular.isObject(item) && angular.isString(filterOn)) {
			          return item[filterOn];
			        } else {
			          return item;
			        }
			      };

			      angular.forEach(items, function (item) {
			        var valueToCheck, isDuplicate = false;

			        for (var i = 0; i < newItems.length; i++) {
			          if (angular.equals(extractValueToCompare(newItems[i]), extractValueToCompare(item))) {
			            isDuplicate = true;
			            break;
			          }
			        }
			        if (!isDuplicate) {
			          newItems.push(item);
			        }

			      });
			      items = newItems;
			    }
			    return items;
			  };
			});
			

			angular.module('app').filter('startFrom', function () {
				return function (input, start) {
					if (input) {
						start = +start;
						return input.slice(start);
					}
					return [];
				};
			});
			angular.module('app').directive('numbersOnly', function () {
			    return {
			        require: 'ngModel',
			        link: function (scope, element, attr, ngModelCtrl) {
			            function fromUser(text) {
			                if (text) {
			                    var transformedInput = text.replace(/[^0-9]/g, '');

			                    if (transformedInput !== text) {
			                        ngModelCtrl.$setViewValue(transformedInput);
			                        ngModelCtrl.$render();
			                    }
			                    return transformedInput;
			                }
			                return undefined;
			            }            
			            ngModelCtrl.$parsers.push(fromUser);
			        }
			    };
			});
			//auto focus

			app.directive('focusMe', function ($timeout) {    
		    	return {    
		        	link: function (scope, element, attrs, model) {                
		            	$timeout(function () {
		                	element[0].focus();
		            	});
		        	}
		     	};
		});
});