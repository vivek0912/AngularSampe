define(function(require){
	angular.module("app").controller("eventsCtrl",function($window,eventService,session,$scope,$location,$state,$rootScope,$timeout, dataFactory,$translate){
  		$scope.sucessmessage=false;		
  		$scope.eventResult=[];
      $scope.IsonLoad = false;	
  		session.getSession();
  	  $scope.userdetails = session.UserDetails;	
      localStorage.removeItem("allvisitor"); 
      localStorage.removeItem("alluser") 
      localStorage.removeItem("allexhibitor");
           
    	 setTimeout(function() {	           
               $('[data-toggle=collapse]').click(function(){
                // toggle icon
                $(this).find("i").toggleClass("fa-angle-down");
                });
                 
                $("#menu-toggle").click(function(e) {
                $(".content").toggleClass("toggled");
                e.preventDefault();
                   
                });
                 
                $("#menu-toggle").click(function(e) {
                
                $("#sidebar").toggleClass("toggled");
                e.preventDefault();
                  
                }); 
            }, 2000);
  
             $scope.eventStatus = [
                      {"EventTypeID": 2, "Name": "Online"}, 
                      { "EventTypeID": "all", "Name": "All Event Status"},
                      { "EventTypeID": 1, "Name": "Draft" },
                      { "EventTypeID": 3, "Name": "Offline" },
                      { "EventTypeID": 4, "Name": "Closed" },
             ];

            $scope.SearchByEvent = function(selected){
                    $scope.events=JSON.parse(localStorage.getItem("eventobj"));	
                    if(selected!=undefined){
                      $scope.EventSelected=selected;
                      if(selected!="all"){
                        $scope.EventSelected=parseInt($scope.EventSelected);
                              $scope.IsonLoad = false;
                          }
                    }            
                    if($scope.EventSelected != null){
                      if($scope.EventSelected=="open"){
                            $scope.IsonLoad = false;
                            dataFactory.setEventType("open");
                            $scope.eventResult = $scope.events.filter(function (obj) {
                                if (obj.Status ==2) {
                                    return obj;
                                }
                            });
                      }
                      else if($scope.EventSelected=="all"){
                          dataFactory.setEventType("all");
                         $scope.eventResult = $scope.events.filter(function (obj) {
                               return obj;
                                
                            });
                      }
                      else
                      {
                        localStorage.removeItem("eventtype"); 
                        $scope.eventResult = $scope.events.filter(function (obj) {
                            $scope.IsonLoad = false;
                                if (obj.Status === $scope.EventSelected) {
                                    return obj;
                                }
                            });
                      }                       
                    }
                    else 
                    {
                        $scope.eventResult = $scope.events;
                    }                      
                    if($scope.eventDatatable!=null && $scope.eventDatatable!=undefined && $scope.eventDatatable!=""){
                         $scope.eventDatatable.destroy();  
                           }

                        if($scope.IsonLoad !== true){                          
                            var ddd=$scope.EventSelected;
                             $timeout(function() {  
                                   $scope.eventDatatable = $('#eventTable').DataTable({   
                                         "paging":   true,              
                                         "info":     true,
                                         "searching": true,
                                         "pageLength":10,
                                         "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                                         language: {
                                         emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                            searchPlaceholder: searchtext,
                                            search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                            infoFiltered: " "
                                          }       
                                });
                                   $('#eventTable').wrap('<div class="responsive-datatable" />');
                         },0);
                      }
                  }
	  	    //Get Events
    	  	 var noitemfounds = "";
    	  	 var searchtext = "";
               $translate(['itemnotfound']).then(function (translations) {
                          noitemfounds = translations.itemnotfound;                      
                });

               $translate(['searchevents']).then(function (translations) {
                          searchtext = translations.searchevents;                      
             });
               
        	  	eventService.getEvents().then(function(data){
        	  		   $scope.events=data.data;
        	  		   localStorage.setItem("eventobj", JSON.stringify($scope.events));
                   if(dataFactory.getEventType()===undefined ||dataFactory.getEventType()==null)
                   {
                     $scope.EventSelected=2;    
                   }
                   else{
                     $scope.EventSelected=dataFactory.getEventType();    
                   }
                        $scope.IsonLoad = true;
        	  		  
                        $scope.SearchByEvent($scope.EventSelected); 

                         if($scope.eventDatatable!=null && $scope.eventDatatable!=undefined && $scope.eventDatatable!=""){
                               $scope.eventDatatable.destroy();  
                            }  
        	  	  })
    	  

          	    $scope.viewEvent= function (event) {   
              			   localStorage.removeItem("activeTab");  			
              			   localStorage.removeItem("event");
                       if(dataFactory.getEventType()!="all")   
                            dataFactory.setEventType(event.Status);	 
                         	   dataFactory.setEventId(event.Event_Id);
                             $location.path("/event/eventdetails");
                }   
	  	
 })});