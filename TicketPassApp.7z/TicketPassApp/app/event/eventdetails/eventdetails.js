define(function(require){
	angular.module("app").controller("eventdetailsCtrl",function($window,$uibModal,apiService,eventService, $scope,$location,$rootScope,dataFactory,session,$compile,$translate,$element,$timeout){
    $scope.eventId = dataFactory.getEventId();   
    if($scope.eventId === undefined)
    $location.url("/events");   
    $scope.title = "Authenticate";
    $scope.buttonValue='Confirm';
    $scope.message= "";
    $scope.authenticatewrning = true;
    $scope.badgeRuleTypes = {};
    $scope.eventLocations = [];
    $scope.updatedEventLocations = [];
    $scope.IsInvalid=false;
    $scope.hideSuccess=true;
    $scope.excelProcess=false;
    $scope.excelError=false;
    $scope.eventStatus = [
              { "EventTypeID": 1, "Name": "Draft" },
              { "EventTypeID": 2, "Name": "Online" },
              { "EventTypeID": 3, "Name": "Offline" },
              { "EventTypeID": 4, "Name": "Closed" },
     ];

       

      $scope.showErrorMessage = function(message){
                  $scope.errorMessage = message;
                  $scope.hideSuccess=true;
                  $scope.showeerror = true;
                   $timeout(function () { $scope.errorMessage = ''; $scope.showeerror = false;}, 3000);
              }   
    
      $scope.ShowUpdateMessage = function(pagerefresh){     
        if(pagerefresh==true)
        {
          $scope.event = dataFactory.getEvent();

          $scope.savedEvent = $scope.event;
          if($scope.savedEvent != undefined) {
                if($scope.savedEvent.IsUpdated !== undefined && $scope.savedEvent.IsUpdated === true)
                {
                  $translate(['iseventsaved']).then(function (translations) {
                      $scope.message = translations.iseventsaved;    
                  });

            $scope.eventdetailsmessageshow = true;   
            $scope.event.IsUpdated = false;   
          }

                if($scope.savedEvent.IsDeleted !== undefined && $scope.savedEvent.IsDeleted === true)
                {
                   $translate(['iseventdeleted']).then(function (translations) {
                      $scope.message = translations.iseventdeleted;    
                    });

            $scope.eventdetailsmessageshow = true;   
            $scope.event.IsDeleted = false;   
          }

          $timeout(function () {
            $scope.eventdetailsmessageshow = false;           
            $scope.savedEvent =[];
        }, 3000);
      }     
    }

      if(dataFactory.getPreviousPageName()=="eventdetails"){
            dataFactory.setPreviousPageName("");
            $scope.event = dataFactory.getEvent();
            $scope.savedEvent =  $scope.event;
            $scope.siteeventdetailsmessageshow = true;  
            $translate(['iseventsaved']).then(function (translations) {
                      $scope.message = translations.iseventsaved;    
                  });
            $timeout(function () {
            $scope.siteeventdetailsmessageshow = false;           
            $scope.savedEvent =[];
        }, 3000);
        }
        /*
        if(dataFactory.getPreviousPageName()=="servereventdetails"){
           dataFactory.setPreviousPageName("");
        }
        if(dataFactory.getPreviousPageName()=="canceleventdetails"){
          dataFactory.setPreviousPageName("");
        } */
      }

    $scope.ShowUpdateMessage();
    $scope.PageLoad = function()
      {  
        
   eventService.getVisitorTypes().then(function (data) {  
       $scope.visitorTypes = data;        
        });
 
   eventService.getCustomVisitorTypes($scope.eventId).then(function (data) {  
      $scope.customVisitorTypes = data.data;        

    });

   eventService.getLocations().then(function (data) {   
      $scope.locations = data.data;        
    });

    eventService.getEvent($scope.eventId).then(function(data){                
                 $scope.event=data.data.data;  
                if ($scope.event != null || $scope.event != undefined) {      
                 $scope.eventCode = $scope.event.Event_Code;
                 $scope.eventName = $scope.event.Name;     
                 $scope.eventYear = new Date($scope.event.Start_Date).getFullYear();                  
                 $scope.eventStartYear = $scope.event.Start_Date;
                 $scope.eventEndYear =   $scope.event.End_Date;    
                 $scope.event.IsUpdated = false;       
                 $scope.event.EventStatus = $scope.eventStatus[$scope.event.Status - 1].Name;
                 $scope.eventURL = $scope.event.URL;  
                 eventService.getEventServers($scope.event.Event_Id).then(function (data) {  
                     $scope.eventservers = data.data.data;   
                     /*$scope.syncEventServers = $scope.eventservers.filter(e => e.Event_Id === $scope.event.Event_Id)*/
                     $scope.syncEventServers = $scope.eventservers.filter(function(e) { return e.Event_Id === $scope.event.Event_Id; });
                     angular.forEach($scope.siteservers, function (value, index) {
                         angular.forEach($scope.syncEventServers, function (arrayvalue, index) {                  
                                  if(value.Server_Id === arrayvalue.Server_Id)
                                  {
                                    value.checked = true;
                                  }                      

                               })
                         })

                 });

                eventService.getEventLocations($scope.event.Event_Id).then(function (data) {  
                   $scope.eventLocations = data.data.data;  
                    $scope.Event_Location={};
                    var divElement = angular.element(document.querySelector('#contactTypeDiv'));
                    for (var i = 0; i < $scope.eventLocations.length; i++) {                      
                       var item = $scope.eventLocations[i];
                        /*var selectedLocation = $scope.locations.filter(e => e.Location_Id === item.Location_Id)*/
                        var selectedLocation = $scope.locations.filter(function(e) { return e.Location_Id === item.Location_Id; });
                        /*$scope.Event_Location.Location_Id = item.Location_Id;*/
                        $scope.ContactValue = selectedLocation[0].Location_Name;
                        /*$scope.Event_Location.Event_Id = item.Event_Id;
                        $scope.eventLocations.push($scope.Event_Location); */                      
                        var appendHtml = $compile('<div id="'+ $scope.ContactValue+'" class="inner-addon right-addon" ng-model="ContactValue" ><input readonly class="form-control" type="text" value="'+ $scope.ContactValue+'"><button ng-click="DeleteLocation($event,this)" class="btn btn-danger" style="background:transparent; padding: 0px; border: none; height: 37px; color:#000; position:absolute; right:0px; top: 0px;"><i class="fa fa-times" aria-hidden="true" style="position:relative;"></i></button></div>')($scope);
                        divElement.append(appendHtml);

                  }

               });

            if(dataFactory.getPreviousPageName()=="SiteServer"){
               dataFactory.setPreviousPageName("");
              $scope.savedEvent = $scope.event;
               $scope.eventdetailsmessageshow = true;
                $translate(['iseventsaved']).then(function (translations) {
                         $scope.message = translations.iseventsaved;    
                     });
               $timeout(function () {
               $scope.eventdetailsmessageshow = false;           
              }, 3000);
            }     
        }
    })     
  }
   $scope.PageLoad();
   
   $scope.saveEvent=function(event){  
              /*var locations = $scope.eventLocations;*/
              $scope.locations = $scope.updatedEventLocations;
              /*var filteredEvent = $scope.eventStatus.filter(e => e.Name === $scope.event.EventStatus)*/
              var filteredEvent = $scope.eventStatus.filter(function(e) { return e.Name === $scope.event.EventStatus; });
              $scope.event.Status = filteredEvent[0].EventTypeID;
              eventService.saveEvent($scope.event).then(function (data){         
              if (data.status === 200 || data.status === 201) {   
                eventService.saveEventLocations($scope.locations).then(function (data){         
                  if (data.status === 200 || data.status === 201) {  
                        $scope.event.IsUpdated = true;                       
                        dataFactory.setEvent($scope.event);               
                        /*$location.url("/events");*/  
                        var divElement = angular.element(document.querySelector('#contactTypeDiv'));
                        divElement.empty();
                        $scope.eventLocations = [];
                        $scope.updatedEventLocations = [];
                        $scope.ShowUpdateMessage(true);
                        $scope.PageLoad();
                          
                     }
                  });                                 
                 }
              });            
    }

   $scope.deleteEvent=function(){  

      //Password verification
      $scope.userdetails = session.UserDetails;  
      $scope.user = {};
      $scope.user.Password = $scope.password;
      $scope.user.Email = $scope.userdetails.Email;
     
      eventService.veryPassword($scope.user).then(function(data){
          if (data.status === 200 || data.status === 201) { 
          $('#eventModal').modal('hide');               
            eventService.deleteEvent($scope.event).then(function (data){
            if (data.status === 200 || data.status === 201) {    
                    $scope.event.IsDeleted = true;
                    dataFactory.setEvent($scope.event);              
                    $location.url("/events");                    
                    /*$scope.$apply(); */         
              }
          });    
         }
         else
         {
          $scope.message = "Invalid Password! Please try again.";
           $scope.invalidMessage = true;
           $timeout(function () {
            $scope.invalidMessage = false;  
            $scope.password="";      
             $scope.message= "";
          }, 3000);

          $scope.authenticatewrning = false;
           $('#eventModal').modal('hide');
         }
     });  
    }
   
     $scope.saveMultiple = function(){   
       
        var list = $scope.siteservers.filter(function (obj) {
                    if (obj.checked !== undefined && obj.checked === true) {
                        return obj;
                    }
                });

        eventService.saveMultipleEventSiteServers(list, $scope.event.Event_Id).then(function(Response){
          if(Response.data.status === 200)
          {
            if(dataFactory.getPreviousPageName()=="servereventdetails"){
                 dataFactory.setPreviousPageName("");
                 $location.url("/siteserverprofile");
            } 
            else
            {
                  $scope.event.IsUpdated = true;
                  dataFactory.setEvent($scope.event);  
                  $scope.savedEvent = $scope.event;
                  $scope.siteeventdetailsmessageshow = true;
                  $translate(['iseventsaved']).then(function (translations) {
                         $scope.message = translations.iseventsaved;    
                     });
               $timeout(function () {
               $scope.siteeventdetailsmessageshow = false;           
              }, 3000);

                 //$scope.ShowUpdateMessage(true);
                 /*$location.url("/events");*/
            } 
          }
        });
   }

   $scope.formatDate=function(value){           
              return value.getMonth()+1 + "-" + value.getDate() + "-" + value.getFullYear();      
    }

	 $scope.gotouser = function()
   {
          $location.url("/users");
   }

   $scope.closeEvent=function(){
        $scope.myDialog.close();
   }


   $scope.confirm=function(event){ 
    $scope.event = event;
    $scope.myDialog = $uibModal.open({
                    scope: $scope,
                    animation: $scope.animationsEnabled,
                    templateUrl: '../app/event/eventdetails/event.popup.html'                        
                  });

                  $scope.myDialog.result.then( function( modalResult ){               
                  $scope.$apply();}).finally(function(){
                  $scopemyDialog.$destroy();               
        });
  }
 var noitemfounds = "";
 var searchtext = "";
         $translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
                    });
          $translate(['searchserver']).then(function (translations) {
                      searchtext = translations.searchserver;                      
         });
          
 eventService.getSiteServers().then(function (data) {   
   $scope.siteservers = data.data;  
         setTimeout(function() { 
          $('#siteserverTable').DataTable( {  
              "paging":   true,             
                "info":     true,
                 "searching": true,
                 "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                   language: {
                     emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                    searchPlaceholder: searchtext,
                      search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                      infoFiltered: " "
                }                    
          } );
           
           $('.table_format').wrap('<div class="responsive-datatable" />');
           

      },200);    

    });   

    $scope.deleteCustomVisitorType=function(customvisitortype){
    
                $scope.action="is deleted";
                var visitortype=customvisitortype.VisitorType;          
                eventService.deleteCustomVisitorType(customvisitortype.CustomVisitorType_Id).then(function (data){
                  
                  if(data.data.status==200)
                  {
                        $scope.hideSuccess=false;
                        $scope.SuccessMessage=visitortype;
                        window.scrollTo(0, 'SuccessInfo'.offsetTop - 100)
                       
                        $timeout(function () { $scope.hideSuccess = true }, 3000);

                        eventService.getCustomVisitorTypes($scope.eventId).then(function (data) {   
                            $scope.customVisitorTypes = data.data;  
                        });
                  }
                  else{
                        $scope.showErrorMessage(visitortype);
                  }
                   
             });            
    }

   $scope.addCustomVisitorType=function(customVisitorType){ 
    $scope.newCustomVisitorType.Event_Id =  $scope.event.Event_Id;     
      eventService.saveCustomVisitorType($scope.newCustomVisitorType).then(function (data){         
            if (data.status === 200 || data.status === 201) {     
             eventService.getCustomVisitorTypes($scope.eventId).then(function (data) {     
              $scope.customVisitorTypes = data.data;        

            });         
                  /*$location.url("/events");*/ 
                   $('#newCustomModal').modal('hide');                  
               }
         });  
    }

   $scope.AddLocationTypeControl = function(selectedItem) { 
    /*var selectedLocation = $scope.locations.filter(e => e.Location_Name === selectedItem)*/   
    var selectedLocation = $scope.locations.filter(function(e) { return e.Location_Name === selectedItem; });

    /*$scope.selectedItem = $scope.eventLocations.filter(e => e.Location_Id === selectedLocation[0].Location_Id)*/
    $scope.selectedItem = $scope.eventLocations.filter(function(e) { return e.Location_Id === selectedLocation[0].Location_Id; });
    if($scope.selectedItem.length === 0)
    {      
        $scope.Event_Location={};
        $scope.newEventLocation = {};
        $scope.ContactValue = "";
        $scope.newEventLocation.Location_Name = selectedItem;
        $scope.ContactValue = selectedItem;   
        $scope.name = "ravi"
        $scope.Location_Name = "Add another venue";    
        $scope.Event_Location.Location_Id = selectedLocation[0].Location_Id;
        $scope.Event_Location.Event_Id = $scope.event.Event_Id;
        $scope.Event_Location.State = "Add";
        $scope.updatedEventLocations.push($scope.Event_Location);
        $scope.eventLocations.push($scope.Event_Location);   
        var divElement = angular.element(document.querySelector('#contactTypeDiv'));   
        var appendHtml = $compile('<div id="'+ $scope.ContactValue+'" class="inner-addon right-addon" ng-model="ContactValue" ><input readonly class="form-control" type="text" value="'+ $scope.ContactValue+'"><button ng-click="DeleteLocation($event,this)" class="btn btn-danger" style="background:transparent; padding: 0px; border: none; height: 37px; color:#000; position:absolute; right:0px; top: 0px;"><i class="fa fa-times" aria-hidden="true" style="position:relative;"></i></button></div>')($scope);
        divElement.append(appendHtml);
       }
       else
       {
        $scope.Location_Name = "Add another venue";    
       }
   }
 
  
   $scope.DeleteLocation = function(e,location) {    
       $scope.location = $(e.target).parent()[0].id;
       $(e.target).parent().remove();    
      
       /*$scope.selectedLocation = $scope.locations.filter(e => e.Location_Name === $scope.location)*/
       $scope.selectedLocation = $scope.locations.filter(function(e) { return e.Location_Name === $scope.location; });
       if($scope.selectedLocation[0].Location_Id > 0)
       {
         $scope.Event_Location = {};
         $scope.Event_Location.Location_Id = $scope.selectedLocation[0].Location_Id;
         $scope.Event_Location.Event_Id = $scope.event.Event_Id;      
         $scope.Event_Location.State = "Delete";
         $scope.updatedEventLocations.push($scope.Event_Location);
       }

       var index = $scope.eventLocations.indexOf($scope.selectedLocation[0].Location_Id);
       $scope.eventLocations.splice(index, 1);   
        //$scope.$destroy();
   }

    var ClearControls = function(allContacts) {
    var i;
    for (i = 0; i < allContacts.length; i++)
      angular.element(allContacts[i]).remove();

    $scope.employee = '';
    $scope.employee.contacts = '';
    $scope.$$childHead = $scope.$new(true);
   }  
   
    $scope.getBadgeRulesTypes=function(visitortype){       
       $scope.BadgeRule={};
       $scope.selectedType="VisitorType";
       $scope.selectedVisitorType = visitortype;
       $scope.visitorType = visitortype.VisitorType;
       $scope.visitortypecode = visitortype.VisitorType_Code;
       $scope.BadgeRule.Visitortype_Id = visitortype.Visitortype_Id;
       $scope.BadgeRule.CustomVisitorType_Id = 0;
       $scope.BadgeRule.Event_Id = $scope.event.Event_Id;
       eventService.getBadgeRulesTypes($scope.BadgeRule).then(function (data) {   
       $scope.badgeruletypes = data.data;     
       $scope.selectedBadgeType = visitortype.VisitorType;
       $('#myModal').modal('show');    
    });
     }

      $scope.getCustomBadgeRulesTypes=function(customvisitortype){       
       $scope.BadgeRule={};
       $scope.selectedType="CustomVisitorType";
       $scope.selectedCustomVisitorType = customvisitortype;
       $scope.visitorType = customvisitortype.VisitorType; 
        $scope.visitortypecode = customvisitortype.CustomGateVisitor_Code;
       $scope.BadgeRule.Visitortype_Id = 0;
       $scope.BadgeRule.CustomVisitorType_Id = customvisitortype.CustomVisitorType_Id;
       $scope.BadgeRule.Event_Id = $scope.event.Event_Id;
       eventService.getBadgeRulesTypes($scope.BadgeRule).then(function (data) {   
      
       $scope.badgeruletypes = data.data;  
       $scope.selectedBadgeType = customvisitortype.VisitorType;
      $('#myModal').modal('show');          
    });
     }

     $scope.saveBadgeRule=function(badgeruletypes,selectedType){     
       if($scope.IsInvalid==false)
       {
              $scope.BadgeRule={};
              $scope.visitorType = $scope.visitorType;  
             if(selectedType === "VisitorType")
             {
               $scope.BadgeRule.Visitortype_Id =  $scope.selectedVisitorType.Visitortype_Id;
             }
             else
             {
                 $scope.BadgeRule.CustomVisitorType_Id =  $scope.selectedCustomVisitorType.CustomVisitorType_Id;
             }
             $scope.BadgeRule.BadgeRule_Id = badgeruletypes.BadgeRule_Id;    
             $scope.BadgeRule.Event_Id = $scope.event.Event_Id;       
             $scope.BadgeRule.BadgeRuleValue = JSON.stringify(badgeruletypes.BadgeRuleTypesList);
             eventService.saveBadgeRule($scope.BadgeRule).then(function (data){         
              if (data.status === 200 || data.status === 201) {                
               if(selectedType === "VisitorType"){
                     $scope.visitorType={};                      
                      $scope.Visitor_Type = $scope.visitorTypes.filter(function(v) { return v.Visitortype_Id === $scope.BadgeRule.Visitortype_Id; });
                      $scope.visitorType = $scope.Visitor_Type[0];                    
                      $scope.visitorType.VisitorType_Code=  $scope.visitortypecode;                     
                      eventService.saveVisitorType($scope.visitorType).then(function (data){ 
                        if (data.status === 200 || data.status === 201) {                
                              $('#myModal').modal('hide');                     
                           }
                        }); 
                    } 
                    else if(selectedType === "CustomVisitorType"){                     
                     $scope.customVisitorType={};                      
                      $scope.CustomVisitor_Type = $scope.customVisitorTypes.filter(function(v) { return v.CustomVisitorType_Id === $scope.BadgeRule.CustomVisitorType_Id; });
                      $scope.customVisitorType = $scope.CustomVisitor_Type[0];                    
                      $scope.customVisitorType.CustomGateVisitor_Code=  $scope.visitortypecode;                     
                      eventService.saveCustomVisitorType($scope.customVisitorType).then(function (data){ 
                        if (data.status === 200 || data.status === 201) {                
                              $('#myModal').modal('hide');                     
                           }
                        }); 
                    }  
                    else{
                        $('#myModal').modal('hide');     
                    }                               
                 }
              });   
       }
       else{
        return false;
       }
        
                      
    }
  
     $scope.editVisitorType=function(customVisitorTypeId){          
      eventService.getCustomVisitorType(customVisitorTypeId).then(function (data){         
            if (data.status === 200 || data.status === 201) {              
                 $scope.newCustomVisitorType = data.data;   
                  $translate(['customvisitoreditpagetitle']).then(function (translations) {
                 $scope.customPopupTitle = translations.customvisitoreditpagetitle;    
                 });
                  $('#newCustomModal').modal('show');             
               }
      });           
    };
    
        $scope.AddVisitorType=function(){ 
             $scope.newCustomVisitorType ={};
             $translate(['customvisitorpagetitle']).then(function (translations) {
             $scope.customPopupTitle = translations.customvisitorpagetitle;    
            });
              $('#newCustomModal').modal('show');    
        };    

    var GetContactType = function(id) {
      return $filter('filter')($rootScope.GetContactTypes, {
        contactId: id
      })[0].contactType;
    }

    // for site server profile navigation
     $scope.viewSiteServer = function (siteserverId) {             
                dataFactory.setSiteServerId(siteserverId);
                dataFactory.setEvent($scope.event);
                localStorage.removeItem("pagename"); 
                dataFactory.setPreviousPageName("eventdetails");
                $location.path("/siteserverprofile");
      }

     // Validating badge rule popup for EntryStartTime,EntryEndTime,EntryLimitType,EntryLimitPerEvent,EntryLimitPerDay,EntryStartDate and EntryEndDate
      $scope.validateBadgeRule=function(parametername,value)
      {
        var numbers = /^[0-9]+$/;
       
        var timRegX = /^(\d{1,2}):(\d{2})?$/;

         var hh=value.substring(0,2);
         var mm=value.substring(2,4);
          hh=parseInt(hh);
          mm=parseInt(mm);

        if(parametername=="EntryStartTime")
        { 
            if(value!="")
            { 
                 if(!value.match(numbers)){
                    $('#EntryStartTime').addClass('error-text');
                  }
                  else if(hh>24){
                    $('#EntryStartTime').addClass('error-text');
                  }
                  else if(mm>59){
                     $('#EntryStartTime').addClass('error-text');
                   }
                   else{
                   $('#EntryStartTime').removeClass('error-text');
                    }   
            }
            else{
              $('#EntryStartTime').removeClass('error-text');
            }
        }

          if(parametername=="EntryEndTime")             
          {
             if(value!="")
              {
                    if(!value.match(numbers)){
                    $('#EntryEndTime').addClass('error-text');
                    }
                   else if(hh>24){
                    $('#EntryEndTime').addClass('error-text');
                  }
                  else if(mm>59){
                     $('#EntryEndTime').addClass('error-text');
                   }
                  else{
                     $('#EntryEndTime').removeClass('error-text');
                  }
              }
              else
               $('#EntryEndTime').removeClass('error-text');
        }

        if(parametername=="EntryLimitType")             
          {
             if(value!="")
              {
                if(!value.match(numbers))
                {
                  $('#EntryLimitType').addClass('error-text');
                }
                else
                {
                   $('#EntryLimitType').removeClass('error-text');
                }
            }
            else
               $('#EntryLimitType').removeClass('error-text');
        }

        if(parametername=="EntryLimitPerEvent")             
          {
            if(value!="")
              {
                  if(!value.match(numbers))
                  {
                    $('#EntryLimitPerEvent').addClass('error-text');
                  }
                  else
                  {
                     $('#EntryLimitPerEvent').removeClass('error-text');
                  }
              }
              else
                 $('#EntryLimitPerEvent').removeClass('error-text');
        }

        if(parametername=="EntryLimitPerDay")             
          {
            if(value!="")
              {
                if(!value.match(numbers))
                {
                $('#EntryLimitPerDay').addClass('error-text');
                 }
                 else
                 {
                   $('#EntryLimitPerDay').removeClass('error-text');
                 }
               }
               else
                 $('#EntryLimitPerDay').removeClass('error-text');

        }
     
       var year=value.substring(0,4);
       var month=value.substring(4,6);
       var day=value.substring(6,8);
       year=parseInt(year);
       month=parseInt(month);
       day=parseInt(day);
         
       //date format in yyyyMMdd
       
       if(parametername=="EntryStartDate")   
       {
           $('#EntryStartDate').removeClass('error-text'); 
           if(!value.match(numbers))
            {
            $('#EntryStartDate').addClass('error-text');
            $scope.IsInvalid=true;
            return false;
            }
             


          // if((isNaN(year))){  //&& !(value.length==4)
          // $('#EntryStartDate').addClass('error-text');
          // $scope.IsInvalid=true;
          // return false;
          // }

          //  if(value.length==5 && value.length==6)
          //  {

          //  }
          // else if((isNaN(month))){  //&& !(value.length==6)
          // $('#EntryStartDate').addClass('error-text');
          // $scope.IsInvalid=true;
          // return false;
          // }

          // else if((isNaN(day))){ //&& !(value.length ==8)         
          // $('#EntryStartDate').addClass('error-text');
          // $scope.IsInvalid=true;
          // return false;
          // }

          // else if(value.length>8)
          // {
          // $('#EntryStartDate').addClass('error-text');
          // $scope.IsInvalid=true;
          // return false;
          // }

         // if((angular.isNumber(year)) ||(angular.isNumber(month)) ||(angular.isNumber(day)))
         // {
         // $('#EntryStartDate').addClass('error-text');
         // $scope.IsInvalid=true;
         // return false;
         // }

        else if ( month < 1 ||  month > 12) { // check month range
          $('#EntryStartDate').addClass('error-text');
        }

        else if ( day < 1 ||  day > 31) {
          $('#EntryStartDate').addClass('error-text');
        }

       else if ((month==4 || month==6 || month==9 || month==11) && day==31) {
         $('#EntryStartDate').addClass('error-text');
        }

        else if (month == 2) { // check for february 29th
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day>29 || (day==29 && !isleap)) {
        $('#EntryStartDate').addClass('error-text');
          }
        }

        else
            {
              $('#EntryStartDate').removeClass('error-text');
            }
       }


       if(parametername=="EntryEndDate"){

        $('#EntryEndDate').removeClass('error-text');

          if(!value.match(numbers))
            {
            $('#EntryEndDate').addClass('error-text');
            $scope.IsInvalid=true;
            return false;
            }

         // if(isNaN(year)){
         //  $('#EntryEndDate').addClass('error-text');
         //  $scope.IsInvalid=true;
         //  return false;
         //  }

        // if((angular.isNumber(year)) ||(angular.isNumber(month)) ||(angular.isNumber(day)))
        //  {
        //  $('#EntryEndDate').addClass('error-text');
        //  $scope.IsInvalid=true;
        //  return false;
        //  }

        else if (month < 1 || month > 12) { // check month range
        $('#EntryEndDate').addClass('error-text');
        }

        else if (day < 1 || day > 31) {
          $('#EntryEndDate').addClass('error-text');
        }

       else if ((month==4 || month==6 || month==9 || month==11) && day==31) {
         $('#EntryEndDate').addClass('error-text');
        }

        else if (month == 2) { // check for february 29th
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day>29 || (day==29 && !isleap)) {
        $('#EntryEndDate').addClass('error-text');
          }
        }

        else
            {
              $('#EntryEndDate').removeClass('error-text');
            }
       }
     

       if(($('#EntryEndDate').hasClass('error-text'))||($('#EntryStartDate').hasClass('error-text'))||($('#EntryStartTime').hasClass('error-text'))||($('#EntryEndTime').hasClass('error-text'))||($('#EntryLimitType').hasClass('error-text'))||($('#EntryLimitPerEvent').hasClass('error-text'))||($('#EntryLimitPerDay').hasClass('error-text'))) 
       {
           $scope.IsInvalid=true;
       }
       else
       {
         $scope.IsInvalid=false;
       }  
    }
         

      if(dataFactory.getPreviousPageName()=="Event"){
         dataFactory.setPreviousPageName("SiteServer");
         $scope.activeTab = 1;
         
      }
      else
      {   
        if (localStorage.getItem("activeTab") != null || localStorage.getItem("activeTab") != undefined) {     
            $scope.activeTab = parseInt(localStorage.getItem("activeTab"));
         }
         else {
              localStorage.setItem("activeTab", 1);
              $scope.activeTab = parseInt(localStorage.getItem("activeTab"));
         }        
      }
      
      $scope.setActiveTab = function(tabToSet) {  
      localStorage.setItem("activeTab", tabToSet);      
      $scope.activeTab = tabToSet;
    }
     $scope.excleFileChanged=function(evt, type) {
       $scope.excelProcess=true;
        var file=evt.currentTarget.files[0];
        var reader = new FileReader();
        reader.readAsDataURL(file);

        if(file != null)
        {      
             eventService.ImportExcelData(file).then(function(ResponseMedia){
              
                     if(ResponseMedia.status==200)
                      {
                        $scope.ExcelStatus() 
                      }            
                                                                              
                    })
                                
        }
      }

     $scope.ExcelStatus=function(file){
      
           eventService.ImportExcelDataStatus().then(function(response){
            
            var _int=response.data.data;
            if(_int==1){
                           $scope.excelProcess=true;
                           $scope.excelError=false;
                            $timeout(function(){
                                $scope.ExcelStatus(); 
                              },2000);  
            } else if (_int==-1){
                  $scope.excelProcess=false;
                  $scope.excelError=true;
                  

             } else if (_int==0){
                          angular.element(excelfileInput).val(null);
                          $scope.excelProcess=false;
                          $scope.excelError=false;                                                                                     
              } else {
                    $scope.excelProcess=false;
                    $scope.excelError=false;                    
              }
           });
        }	  
 })}
);
