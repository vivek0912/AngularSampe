define(function(require){
angular.module("app").controller("dashboardCtrl",function($window,dashboardService,apiService,$scope,$location,$state,$rootScope){ 
  $scope.nodata=true;  
dashboardService.GetDashboardReportData().then(function (data) {  
    if(data.data.length>0){
          $scope.events = data.data;   
          $scope.nodata=true;     
           
    
      }
    else {
          $scope.nodata=false;          
      }     
    });

  setTimeout(function() { 
                 
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
             
             $("#menu-toggle").click(function(e) {                          
            e.preventDefault();
            $(".content").toggleClass("toggled");
            });
             
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar").toggleClass("toggled");
            });

         }, 3000);

	    $(".content" ).removeClass( "hideleftnav" );
	    $rootScope.islogin = false;
 })}
	);