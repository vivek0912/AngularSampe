define(function(require){
 
angular.module("app").controller("siteserverprofileCtrl",function($window,siteServerService,apiService,eventService,$scope,$location,$state,$rootScope,$timeout,$translate,dataFactory){

         $scope.sucessmessage=false;
	 	 $scope.siteserverid = dataFactory.getSiteServerId();
	 	 $scope.eventId = dataFactory.getEventId(); 
	 	 $scope.Locations = [];
	 	 $scope.LocationDetails=[];
	 	 $scope.updatedSiteServer={};
	 	 $scope.siteServer={};

	 	 $scope.previousPageName=dataFactory.getPreviousPageName();
	 	  if($scope.siteserverid === undefined)
        	$location.url("/siteservers");
            //$location.url("/siteserverprofile");
        	
        siteServerService.getSiteServer($scope.siteserverid).then(function(response){
       		$scope.siteServer = response.data;
       		$scope.siteServer.IsUpdated = false;  
     	})

        $scope.cancel=function(){
          	if($scope.previousPageName=="SiteServer")
          		$location.url("/siteservers");
          	if($scope.previousPageName=="eventdetails"){
          		 dataFactory.setPreviousPageName("cancelservereventdetails");
          		 $location.url("/event/eventdetails");
          		}
          	}
			var noitemfounds = "";
			var searchtext = "";
         $translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
                    });
          $translate(['searcheventname']).then(function (translations) {
                      searchtext = translations.searcheventname;                      
         });
	 	 eventService.getEventData($scope.siteserverid).then(function(data){
                 $scope.user=data.data;
                 $scope.eventsiteservers = data.data.data; 
                  
                 setTimeout(function() {    
                 $('#eventserverTable').DataTable( {		
				   "paging":   true,				      
				        "info":     true,
				         "searching": false,
				         "pageLength":10,
				         "lengthMenu": [[10, 20, 30], [10, 20, 30]],
				         language: {
				         	emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
						        searchPlaceholder: searchtext,
						          search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
						          infoFiltered: " "
						      }			  
				} );
                 $('#eventserverTable').wrap('<div class="responsive-datatable" />'); 
            },200);   
                                  
         })       
      
         eventService.getLocations().then(function(response){    
             $scope.Locations=response.data;
             })       

		 $scope.updateServerProfile=function(){
			         siteServerService.UpdateSiteServer($scope.siteServer).then(function(Response){
			 			if(Response.status == 200)
						{ 
							if(dataFactory.getPreviousPageName()=="eventdetails")
							{								
                                $location.url("/event/eventdetails");
							}
							else
							{
								$scope.siteServer.IsUpdated = true;  
								dataFactory.setSiteServer($scope.siteServer);
								$location.url("/siteservers");
							}						
						}						
			 	});
		        
		        }

                // for navigation
        $scope.viewEventDetail = function (EventId) {  
               dataFactory.setEventId(EventId);
                dataFactory.setPreviousPageName("servereventdetails");
        	    $location.url("/event/eventdetails");
         	    }

    

		    $scope.gotocompany = function()
 			{
 			   $location.url("/company/addcompany");
 			}

	  		setTimeout(function() {  
				  $(".systm-setting .submenu").addClass("in");
				  $(".systm-setting .Toggleonload").removeClass("collapsed");
				  $(".systm-setting .Toggleonload i").addClass("fa-angle-down");  
				},200);
 })}
);