define(function(require){
angular.module("app").controller("siteserversCtrl",function($window,siteServerService,apiService,$scope,$timeout,$location,$state,$rootScope,$translate,$timeout,session,dataFactory){

            $scope.sucessmessage=false;
            $scope.hideSuccess=false;
			      $scope.count='no item selected';
         	  $scope.selection=[];
            $scope.errorDeleteMessage=false;
            $scope.SuccessMessageShow = false;
            $scope.sucessmsg= false;
            $scope.siteServerDatatable;
            $scope.siteServerResult=[];
            $scope.deletedsiteServers ="";
            $scope.siteserverdeleted = false;
            $scope.siteservermessageshow = false;
            $scope.errorDeleteMessage =='';
            $scope.showeerror = false;
            localStorage.removeItem("allvisitor"); 
            localStorage.removeItem("alluser") 
            localStorage.removeItem("allexhibitor");
            localStorage.removeItem("eventtype"); 


            setTimeout(function() {                  
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
             
             $("#menu-toggle").click(function(e) {                          
            e.preventDefault();
            $(".content").toggleClass("toggled");
            });
             
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar").toggleClass("toggled");
            });
        }, 1500);

        var noitemfounds = "";
        var searchtext = "";

         $translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
         });
          $translate(['searchsiteserver']).then(function (translations) {
                      searchtext = translations.searchsiteserver;                      
         });


         	
	  			$timeout(function() {  
				  $(".systm-setting .submenu").addClass("in");
         $(".systm-setting .Toggleonload").removeClass("collapsed");
          $(".systm-setting .Toggleonload i").addClass("fa-angle-down");    
				
				},200);


  $scope.GetSiteServers = function(){   
          
        siteServerService.getSiteServers().then(function (data) {
        $scope.siteservers = data.data;  
        $scope.siteServerResult=data.data;

        if(!$scope.siteserverdeleted)
        {
          
           $timeout(function() {  
           $scope.siteServerDatatable = $('#siteserverTable').DataTable( {   
           "paging":   true,              
                "info":     true,
                 "searching": true,
                 "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                 language: {
                  emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                    searchPlaceholder: searchtext,
                       search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                       infoFiltered: " "
                  }       
        } );
           $('#siteserverTable').wrap('<div class="responsive-datatable" />');

           },200);    
        }
        else
        {
          $scope.count = "no item selected";
          $scope.siteServerDatatable.destroy();
           $timeout(function() {  
           $scope.siteServerDatatable = $('#siteserverTable').DataTable( {   
           "paging":   true,              
                "info":     true,
                 "searching": true,
                 "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                 language: {
                  emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                    searchPlaceholder: searchtext,
                     search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                     infoFiltered: " "
                  }       
        } );
           $('#siteserverTable').wrap('<div class="responsive-datatable" />');

           },0);    

        }
        $scope.siteserverdeleted = false;
        })
  }


  $scope.ShowUpdateMessage = function()
           { 
            
            $scope.siteserver = dataFactory.getSiteServer();
            if($scope.siteserver != undefined) {
            if($scope.siteserver.IsUpdated !== undefined && $scope.siteserver.IsUpdated === true)
                {
                  //alert($scope.siteserver.Server_Name);
                  $scope.messageshow = true; 
                  //$scope.message=$scope.siteserver.Server_Name;
                 }
                 $scope.siteserver.IsUpdated =false;
                 $timeout(function () {
                $scope.messageshow = false;           
                $scope.siteserver =[];
               }, 3000);
            }
           }

    $scope.GetSiteServers();
    $scope.ShowUpdateMessage();

   	          //multiple selection...
          		$scope.multipleSelection = function multipleSelection(serverId){
           		var id = $scope.selection.indexOf(serverId); 
           		if (id > -1) 
          		{
                    $scope.selection.splice(id, 1);
                    $scope.count--;
                    if($scope.selection.length==0)
                    {
                    $scope.count = "no item selected";
                    }
                    else{
                    	$scope.count = $scope.selection.length  + " item(s) selected";
                    }
                    
                }
                else
                {
                $scope.selection.push(serverId);
                $scope.count++;
                if($scope.selection.length==0)
                {
                  $scope.count = "no item selected";
                }
                else{
                    	$scope.count = $scope.selection.length  + " item(s) selected";
                    }
                }
		    }

     $scope.siteserverCheckedchanged = function(){
           var list = $scope.siteServerResult.filter(function (obj) {
                    if (obj.checked !== undefined && obj.checked === true) {
                        return obj;
                    }
                });
        if(list.length == 1)
          $scope.count = list.length + " item selected";
        else if (list.length > 1)
          $scope.count = list.length + " items selected";
        else 
          $scope.count = 'no item selected';
      }

     // **** Multiple Delete ***** 

      $scope.deleteMultipleServer = function(){
      
        var list = $scope.siteServerResult.filter(function (obj) {
                    if (obj.checked !== undefined && obj.checked === true) {
                        return obj;
                    }
                });
        if(list.length > 0)
        {
          siteServerService.deletemMultipleSiteServer(list).then(function(Response){

            $scope.deletedsiteServers="";
            angular.forEach(list, function(value){
            $scope.deletedsiteServers += value.Server_Name+',';

            })
            $scope.deletedsiteServers= $scope.deletedsiteServers.substring(0, $scope.deletedsiteServers.length - 1);
           
            //$scope.deletedsiteServers = list;
            if(Response.data.status === 200)
            {
               
              $scope.GetSiteServers();
              $scope.ShowDeletedMessage();              
            }
            else
            {
              $scope.showErrorMessage(Response.data.err_msg);
            }


          });
      }
      }

     
      $scope.showErrorMessage = function(message){
          $scope.errorDeleteMessage = message;
          $scope.showeerror = true;
         $timeout(function () {
          $scope.errorDeleteMessage = '';
          $scope.showeerror = false;
      }, 3000);
      }


       $scope.ShowDeletedMessage = function(){             
        
          $scope.siteserverdeleted = true;
          $scope.siteservermessageshow = true; 
       

        $timeout(function () {
          $scope.siteservermessageshow = false;
          //$scope.deletedsiteServers =[];
      }, 3000);
      }


        //delete siteserver
				$scope.deleteSiteServer=function(serverId){
				 	siteServerService.deleteSiteServerData(serverId).success(function (data){
	                		siteServerService.getSiteServers().then(function(data){
	                     	$scope.siteservers=data.data;  
	                     	$scope.ReloadSiteServers();          
	                  		});
	                });
				 }

        
      //$scope.GetSiteServers();
        //$scope.ShowUpdateMessage();
				$scope.viewSiteServer = function (siteserverId) {    
                localStorage.removeItem("siteserverId");
                localStorage.removeItem("pagename");   	    	  
           	    dataFactory.setSiteServerId(siteserverId);
           	    dataFactory.setPreviousPageName("SiteServer");
           	    $location.path("/siteserverprofile");
        }

      
    
		})}
);
		 
 