define(
	function(require)
	{
	angular.module("app").service("authenticationService",function($http,apiService,$window,$location,UtilsService)
		{
			var authService = {};
 
			  authService.login = function (credentials) {
			    return $http
			      .post(UtilsService.Login, credentials)
			      .then(function (res) { 
			      if(res.data.status == 200)   
			        return res.data.data;
			       else 
			       	return res.data;
			      },function(error){ return error; });
			  };
			   //forgot password
			  authService.forgotPassword=function(email){
			   	return $http
			      		.post(UtilsService.Forgot, email)
			      		.then(function (response) {   
			       		 return response.data;
			      		},function(error){ return error; });
			  };

			  authService.setPassword=function(password,token){
			  	var data=JSON.stringify({password:password,token:token});
			  	return $http
			      		.post(UtilsService.Reset, data)
			      		.then(function (response) {   
			       		 return response.data;
			      		},function(error){ return error; });
			  }
			  return authService;

			 


		});
});
