	define(
			function(require)
			{angular.module("app").
			service("countryService",function($http,UtilsService)
			{

			//get countries
				this.getCountries=function(){
					return $http.get(UtilsService.CountryUrl).then(function(data){						
					return data;
					});
				}

              //get regions		
			    this.GetRegions=function(){					
					return $http.get(UtilsService.RegionUrl)
							.then(function(data){						
							return data.data;
					});
					
				}

				 
				this.getRegionWiseReportDate=function(reportdata){  					 
					return $http({
						method: "POST",
                        url: UtilsService.CountryReportDataUrl + "/"+"regiondata",
                        data: reportdata 
                     }).then(function(data)
                     {          
                       return data.data;
                     });
                 }

                 this.getCountryWiseReportDate=function(reportdata){   
					return $http({
						method: "POST",
                        url: UtilsService.CountryReportDataUrl + "/"+"countrydata",
                        data: reportdata 
                     }).then(function(data)
                     {          
                       return data.data;
                     });
                 }
                 

                 this.excelExportcountries = function (countries)
                 {
             
                 return $http({
                  url: UtilsService.CountryReportDataUrl +"/"+ "Export",
                        method: "POST",
                        data: countries,
                        responseType: 'arraybuffer'
                  }).then(function(data)
                     {  
                       return data;
                     },function(error){ return data.data});
                 }

                  




			  this.saveCountry=function(country){
						var response = $http({
									method: "POST",
									url: UtilsService.CountryUrl,
									data: country,
									dataType: "json"});
								return response;	
				}



				//get search countries
				this.getSearchCountries=function(searchstring){
					if(searchstring == '')
					{
						return $http.get(UtilsService.CountryUrl).then(function(data){						
						return data.data;
						});
					}
					else
					{
					return $http.get(UtilsService.ContrySearchUrl+"/"+searchstring).then(function(data){						
					return data.data;
					});
					}
				}
			//get specific country
				this.getCountry=function(countryCode){					
					return $http.get(UtilsService.CountryUrl+"/"+countryCode)
							.then(function(data){						
							return data;
					});
					
				}
			//create country
				this.saveCountry=function(country){
						var response = $http({
									method: "POST",
									url: UtilsService.CountryUrl,
									data: country,
									dataType: "json"});
								return response;	
				}
			//update country
				this.updateCountry=function(country){
				
				 		var response = $http({
                               		method: "PUT",
                               		url: UtilsService.CountryUrl,
                               		data: country,
                               		dataType: "json"});
                                  return response;
				}
			//delete country
				this.deleteCountryData=function(countryCode){
						var response= $http({
			                    	url: UtilsService.CountryUrl+"/"+countryCode,
			                    	method: "DELETE"});
			                    return response;
				}
			//multiple deletion
			this.deleteMultipleCountry=function(country){
				return $http({
    							url: UtilsService.CountryUrl +"/"+ "DeleteMultiple",
                        		method: "POST",
                        		data: country
                  				}).then(function(data)
                     		{          
                       			return data;
                     		});
			  }
			
          
	});
});