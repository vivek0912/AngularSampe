define(
	function(require)
	{
	angular.module("app").
	service("authinterceptorService",function($http,apiService,$window,$location,$q)
		{
			var service = this;

		    service.request = function(config) { 
		    	 session.getSession();
		    	 config.headers['token'] = 'dgauthtoken ' +session.UserDetails.AuthToken;
		    	 config.headers['Content-Type'] = 'application/json; charset=utf-8';		         
		    };

		    service.responseError = function(response) {
		        if (response.status === 404 || response.status === 401) 
		        {        	
		        	session.destroy();
		        	$location.path("/user/login");
		        	
		        }else if(response.status=== 500)
		        {
		        	 $rootScope.$broadcast( 'httpError', { message: 'An unexpected error has occurred. Please try again.' } ); 
		        }	
		        
		        return $q.reject(response);
		    };
			
	})
});