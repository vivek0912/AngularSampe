define(function(require){
angular.module("app").service("surveyService",function($http,UtilsService)
  {   
  	        // get all survey details
			   this.getSurveys=function() {	    
		       return $http
		         .get(UtilsService.GetSurveyUrl)
		         .then(function (result) {   
		           return result.data;
		         },function(error){ return error; });
		     };
        
         // get all survey response details by FormId
         // this.getSurveyResponse=function(formId) {     
         //   return $http
         //     .get(UtilsService.SurveyResponse + "/" + formId)
         //     .then(function (result) {   
         //       return result.data;
         //     },function(error){ return error; });
         // };


         this.saveSurveyResponse=function(survey){   
            return $http({
              url: UtilsService.SurveyResult,
                    method: "PUT",
                    data: survey
              }).then(function(data)
               {          
                 return data.data;
               },function(error){ return error; });
         }
        // Update survey Response details 
        this.getSurveyResponse=function(formId){    
                       
        return $http({
                url: UtilsService.SurveyResponse +"/" +formId,
                method: "GET"            
                }).then(function(data)
                  {        
                     return data.data;
                  });
        }
         //get user details by userid
        this.getUser=function(userId){                   
                return $http({
                        url: UtilsService.UserUrl+"/"+userId,
                        method: "GET"            
                        }).then(function(data)
                          {        
                             return data;
                          });
            }

         


		     // updating pause status of survey
		     this.updateSurvey=function(survey)
             {              
               return $http({
                  url: UtilsService.SurveyUrl,
                        method: "PUT",
                        data: survey
                  }).then(function(data)
                     {          
                       return data.data;
                     },function(error){ return error; });
            }
             // updating pause status of survey
         this.updateSurveyStatus=function(survey)
             {              
               return $http({
                  url: UtilsService.SurveyStatusUrl,
                        method: "PUT",
                        data: survey
                  }).then(function(data)
                     {          
                       return data.data;
                     },function(error){ return error; });
            }

        // Get New Survey object
         this.NewSurveyObject=function(survey)
             {              
               return $http({
                  url: UtilsService.SurveyUrl +"/New",
                        method: "GET"
                  }).then(function(data)
                     {          
                       return data.data;
                     },function(error){ return error; });
            }

             // delete specific survey
		      this.deleteSurvey = function(surveyId)
			     {
			  	   var response= $http({
                        url: UtilsService.SurveyUrl+"/"+surveyId,
                          method: "DELETE"});
                        return response;
			    }

            // delete multiple surveys
            this.deletemMultipleSurvey = function (surveys)
			       {
			  	      return $http({
                  url: UtilsService.SurveyUrl +"/"+ "DeleteMultiple",
                        method: "POST",
                        data: surveys
                  }).then(function(data)
                     {          
                       return data;
                     });
			        }

              // Excel export for the Response
            this.excelExportresponse = function (formId)
             {
                return $http({
                  url: UtilsService.SurveyResultExcel+"/"+formId,
                        method: "GET",
                        responseType: 'arraybuffer'
                  }).then(function(data)
                     {  
                       return data;
                     },function(error){ return data.data});
              }

             // getting survey details based on surveyId 
				     this.getSurveyDetails=function(surveyId){             
            	return $http({
                url: UtilsService.GetSurveyUrl+"/"+surveyId,
                method: "GET"            
                }).then(function(result)
                  {        
                     return result.data;
                  },function(error){ return error; });
             } 
		    
             // getting survey details based on fromid 
             this.getSurveyFormDetails=function(surveyId){             
              return $http({
                url: UtilsService.SurveyUrl+"/"+surveyId,
                method: "GET"            
                }).then(function(result)
                  {        
                     return result.data;
                  },function(error){ return error; });
             } 

             // Adding Survey 
             this.AddSurvey = function(Survey)
             {
              return $http({
                url: UtilsService.SurveyUrl+"/add",
                method: "POST",
                data:Survey            
                }).then(function(result)
                  {        
                     return result.data;
                  },function(error){ return error; });
             }
            
			
  })
});