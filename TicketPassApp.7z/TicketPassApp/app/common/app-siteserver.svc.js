define(function(require){
angular.module("app").service("siteServerService",function($http,UtilsService)
  {   
			this.getSiteServers=function() {	    
		       return $http
		         .get(UtilsService.SiteServerUrl)
		         .then(function (result) {   
		           return result.data;
		         },function(error){ return error; });
		     };

             // getting server details based on serverId 
				this.getSiteServer=function(serverId){             
            	return $http({
                url: UtilsService.GetSiteServerDetails+"/"+serverId,
                method: "GET"            
                }).then(function(result)
                  {        
                     return result.data;
                  });
             }


		     // update siteserver
		     this.UpdateSiteServer = function (siteserverforupdate)
				  {
				  	return $http({
	                  url: UtilsService.DeleteSiteServerUrl,
	                        method: "PUT",
	                        data: siteserverforupdate
	                  }).then(function(data)
	                     {          
	                       return data.data;
	                     });
				  }	


            //delete multiple or single siteserver

            this.deletemMultipleSiteServer = function (siteservers)
			  {
			  	return $http({
                  url: UtilsService.DeleteSiteServerUrl +"/"+ "DeleteMultiple",
                        method: "POST",
                        data: siteservers
                  }).then(function(data)
                     {          
                       return data;
                     });
			  }
			  //end of multiple or single siteserver
			  

		     //delete siteserver
				this.deleteSiteServerData=function(siteServerId){
						var response= $http({
			                    	url: UtilsService.DeleteSiteServerUrl+"/"+siteServerId,  
			                    	method: "DELETE"});
			                    return response;
				}
			//multiple deletion
			this.deleteMultipleSiteServer=function(siteServerId){
				var response={};
                  	angular.forEach(siteServerId, function(value){
                     response= $http({
                                    url: UtilsService.DeleteSiteServerUrl+"/"+value,
                                      method: "DELETE"});
					});
			   return response;
			}

			

		    
			
  })
});