define(
	function(require){
	angular.module("app").service("userService",function($http,UtilsService)
		{			
			 this.getUsers=function(){
		     return $http.get(UtilsService.UserUrl).then(function(data){      
		      return data.data;
		     },function(error){ return error; });
            }
            
            this.deleteUser=function(userId){    
                var response= $http({
                                url: UtilsService.UserUrl+"/"+userId,
                                  method: "DELETE"});
                                return response;
            }	

          this.saveUser=function(user)
            {              
             
              if(user.User_Id==null || user.User_Id==undefined)
              {                
                user.IsActive=true;
                return $http({
                  url: UtilsService.UserUrl,
                        method: "POST",
                        data: user
                  }).then(function(data)
                     {          
                       return data;
                     });
                
              }else
              { 
                            
                user.IsActive=true;              
                return $http({
                  url: UtilsService.UserUrl,
                        method: "PUT",
                        data: user
                  }).then(function(data)
                     {   
                        return data;
                     });
                
              }   
            }

            this.getUser=function(userId){                   
                return $http({
                        url: UtilsService.UserUrl+"/"+userId,
                        method: "GET"            
                        }).then(function(data)
                          {        
                             return data;
                          });
            }
            this.isValidPassword=function(isValidPassword){
              return $http({
                  url: UtilsService.ValidPwdUrl,
                        method: "POST",
                        data: isValidPassword
                  }).then(function(data)
                     {          
                       return data;
                     });

            }
            this.isExistEmail=function(isExistEmail){
               return $http({
                  url: UtilsService.CheckEmail,
                        method: "POST",
                        data: isExistEmail
                  }).then(function(data)
                     {          
                       return data;
                     });
            }	
              this.IsValidQRCode=function(QRCode){                  
                  return $http({
                          url: UtilsService.UserUrl+"/QRValidate",
                          method: "POST",
                          data: QRCode,
                          dataType: "json"            
                          }).then(function(data)
                            {                                     
                               return data.data;
                            });
          }
		})
});