 define(function(require){
      angular.module("app").service("integrationService",function($http,UtilsService){

			//get integrations
				this.getIntegrations=function(){
					return $http.get(UtilsService.IntegrationUrl).then(function(data){						
					return data;
					});
				}
			//get specific integration
				this.getIntegration=function(integrationId){
							
					return $http.get(UtilsService.IntegrationUrl+"/"+integrationId)
							.then(function(data){						
							return data;
					});
					
				}
      	
            //update integration
               	this.updateIntegration=function(integration){
               	
                   var response = $http({
                                   method: "PUT",
                                    url: UtilsService.IntegrationUrl,
                                   data: integration,
                                   dataType: "json"});
                                      return response;
            	}

      })
  })