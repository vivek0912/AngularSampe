define(
	function(require)
	{
	angular.module("app").
	service("session",function($http,apiService,$window,$location)
		{
			 this.create = function (UserDetails) {
				    window.localStorage.setItem("UserDetails",JSON.stringify(UserDetails));  				    
			  };
			  this.destroy = function () {
				  window.localStorage.setItem("UserDetails",null);  	
			  };
			  this.getSession=function()
			  {
				   this.UserDetails = JSON.parse(window.localStorage.getItem("UserDetails"));   
			  }
		})
});