define(
	function(require)
	{
	angular.module("app").service("filterservice",function($http,apiService,$window,$location,UtilsService)
		{
			var filterservice = {};
 				filterservice.Filter = function(collumnName , FilterKey, JsonObjectList , filtertype)
 				{
 					if(filtertype = 'text')
 					{
 					return JsonObjectList.filter(function (obj) {
			              if (obj[collumnName].toLowerCase().indexOf(FilterKey.toLowerCase()) >= 0) {
			                  return obj;
			              }
			          });
 					}
 					else if(filtertype ='number')
 					{
 						return JsonObjectList.filter(function (obj) {
			              if (obj[collumnName] == FilterKey) {
			                  return obj;
			              }
			          });
 					}
 				}		  
			  return filterservice;			
		});
});
