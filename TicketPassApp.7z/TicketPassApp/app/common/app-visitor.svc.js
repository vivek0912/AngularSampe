define(
	function(require)
	{
	angular.module("app").service("visitorService",function($http,apiService,$window,$location,UtilsService)
		{
			var visitorService = {};


 
			  visitorService.getVisitors = function	()
			  {
			  	 return $http.get(UtilsService.PageLoadVisitorUrl).then(function(data, textStatus, xhr){ 
			  	 		if(data.data.status == 200)
			  	 		{
				      		return data.data.data;
			  	 		}
				  },function(error){ return error; });
			  }
			//get survey response
			   visitorService.getVisitorSurveyResponse = function(visitorUUID)
				{
				  	 return $http.get(UtilsService.SurevyResponseURL +"/" + visitorUUID).then(function(data, textStatus, xhr){ 
					      		return data;
				  	 		
					  },function(error){ return error; });
				}
			 visitorService.getFilteredVisitors = function	(StringString,EventId)
			  {
			  	 return $http.get(UtilsService.FilteredVisitorsURL+"/"+StringString +"/"+EventId).then(function(data, textStatus, xhr){ 
			  	 		if(data.data.status == 200)
			  	 		{
				      		return data.data.data;
			  	 		}
				  },function(error){ return error; });
			  }

			  visitorService.deleteVisitor = function(visitorId)
			  {
			  	var response= $http({
                        url: UtilsService.VisitorUrl+"/"+visitorId,
                          method: "DELETE"});
                        return response;
			  }

			  visitorService.deletemMultipleVisitor = function (visitors)
			  {
			  	return $http({
                  url: UtilsService.VisitorUrl +"/"+ "DeleteMultiple",
                        method: "POST",
                        data: visitors
                  }).then(function(data)
                     {          
                       return data;
                     });
			  }
			 visitorService.getVisitorDetails = function(visitorId)
			  {
			  	 return $http.get(UtilsService.VisitorUrl +"/" + visitorId).then(function(data, textStatus, xhr){ 
			  	 		if(data.data.status == 200)
			  	 		{
				      		return data.data.data;
			  	 		}
				  },function(error){ return error; });
			  }

			visitorService.UpdateVisitor = function (visitor)
			  {
			  	return $http({
                  url: UtilsService.VisitorUrl,
                        method: "PUT",
                        data: visitor
                  }).then(function(data)
                     {          
                       return data;
                     });
			  }
			 visitorService.GetCompany = function(companiesId)
			  {
			  	 return $http.get(UtilsService.CompanyUrl +"/"+ companiesId).then(function(data, textStatus, xhr){ 
			  	 		if(data.data.status == 200)
			  	 		{
				      		return data.data.data;
			  	 		}
				  },function(error){ return error; });
			  }

			  visitorService.updateMedia = function(visitorId , blob)
			  {
			        var fd = new FormData(document.forms[0]);
			        var UserDetails = JSON.parse(window.localStorage.getItem("UserDetails")); 
			        fd.append("file", blob);
			        var token = UserDetails.AuthToken;
			        return $.ajax({           
			            url: UtilsService.VisitorUrl +"/uploadimage/"+ visitorId,
			            data: fd,
			            cache: false,
			            beforeSend: function (xhr) {
			                xhr.setRequestHeader("token", token);
			            },
			            contentType: false,
			            processData: false,
			            type: 'POST',
			            success: function (data) {               
			                return data;
			            }
			        });
			  }
			  return visitorService;			 
		});
});
