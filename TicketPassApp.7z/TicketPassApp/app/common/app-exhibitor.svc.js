define(
	function(require)
	{
	angular.module("app").service("exhibitorService",function($http,apiService,$window,$location,UtilsService)
		{
			var exhibitorService = {};
				exhibitorService.getExhibitors = function()
				{
				return $http.get(UtilsService.ExhibitorUrl).then(function(data){					
							return data.data;
							},function(error){ 
								return error; 
							});
				}

		    exhibitorService.getFilteredExhibitors = function	(StringString,EventId)
			  {
			  	 return $http.get(UtilsService.FilteredExhibitorsURL+"/"+StringString+"/"+EventId).then(function(data, textStatus, xhr){ 
			  	 		if(data.data.status == 200)
			  	 		{
				      		return data.data.data;
			  	 		}
				  },function(error){ return error; });
			  }

				exhibitorService.deleteExhibitor = function(exhibitorId)
				  {
				  	var response= $http({
	                        url: UtilsService.ExhibitorUrl+"/"+exhibitorId,
	                          method: "DELETE"});
	                        return response;
				  }
				exhibitorService.deletemMultipleExhibitors = function (exhibitors)
				  {
				  	return $http({
	                  url: UtilsService.ExhibitorUrl +"/"+ "DeleteMultiple",
	                        method: "POST",
	                        data: exhibitors
	                  }).then(function(data)
	                     {          
	                       return data;
	                     });
				  }
				exhibitorService.getExhibitorDetails = function(exhibitorId)
					  {
					  	 return $http.get(UtilsService.ExhibitorUrl +"/" + exhibitorId).then(function(data, textStatus, xhr){ 
					  	 		if(data.data.status == 200)
					  	 		{
						      		return data.data;
					  	 		}
						  },function(error){ return error; });
					  }	
				exhibitorService.AddExhibitor = function (exhibitorforadd)
				  {
				  	return $http({
	                  url: UtilsService.ExhibitorUrl+"/add",
	                        method: "POST",
	                        data: exhibitorforadd
	                  }).then(function(data)
	                     {          
	                       return data.data;
	                     });
				  }	
				  exhibitorService.UpdateExhibitor = function (exhibitorforadd)
				  {
				  	return $http({
	                  url: UtilsService.ExhibitorUrl,
	                        method: "PUT",
	                        data: exhibitorforadd
	                  }).then(function(data)
	                     {          
	                       return data.data;
	                     });
				  }	

				  exhibitorService.uploadExcel = function(blob)
				  {
				        var fd = new FormData();
				        var UserDetails = JSON.parse(window.localStorage.getItem("UserDetails")); 
				        fd.append("file", blob);
				        var token = UserDetails.AuthToken;
				        return $.ajax({           
				            url: UtilsService.ExhibitorUrl +"/uploadexcel",
				            data: fd,
				            cache: false,
				            beforeSend: function (xhr) {
				                xhr.setRequestHeader("token", token);
				            },
				            contentType: false,
				            processData: false,
				            type: 'POST',
				            success: function (data) {               
				                return data;
				            }
				        });
				  }	
				  exhibitorService.addMultiple = function (exhibitors)
				  {
				  	return $http({
	                  url: UtilsService.ExhibitorUrl +"/"+ "AddMultiple",
	                        method: "POST",
	                        data: exhibitors
	                  }).then(function(data)
	                     {          
	                       return data;
	                     });
				  }

				   /* export country report data */
               exhibitorService.DownloadExcelTemplate = function (fileName){
                 return $http({
                  url: UtilsService.ExhibitorUrl +"/"+ "downloadexceltemplate"+"/"+fileName,
                        method: "GET",                       
                        responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }
			return exhibitorService;
		});
});
