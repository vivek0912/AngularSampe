define(
	function(require){
	angular.module("app").service("posService",function($http,UtilsService)
	{			
			 this.getPosDetails=function(){        
		     return $http.get(UtilsService.PosUrl).then(function(data){   
		      return data;
		     },function(error){ return error; });
    		} 

     		this.getPosById = function(posid)
			  {
			  	 return $http.get(UtilsService.PosByIDUrl +"/" + posid).then(function(data, textStatus, xhr){ 
			  	 		if(data.data.status == 200)
			  	 		{
				      		return data.data.data;
			  	 		}
				  },function(error){ return error; });
			  }

			  this.getVisitorPass = function(visitoruuid)
			  {
			  	 return $http.get(UtilsService.VisitorPassUrl +"/" + visitoruuid).then(function(data, textStatus, xhr){
			  	  
			  	 		if(data.data.status == 200)
			  	 		{
				      		return data.data.data;
			  	 		}
				  },function(error){ return error; });
			  } 
            
})
});