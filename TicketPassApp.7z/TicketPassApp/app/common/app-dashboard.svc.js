define(function(required){
	angular.module("app").service("dashboardService",function ($http,UtilsService) {	
			this.GetDashboardReportData=function(){				
				return $http({
                            url: UtilsService.DashboardMasterEventReportUrl,
                            method: "GET"            
                            }).then(function(data)
                                      {        
                                         return data.data;
                                      });
                
			}		
	});
});