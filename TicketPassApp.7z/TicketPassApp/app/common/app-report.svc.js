define(
	function(require){
	angular.module("app").service("reportService",function($http,UtilsService)
		{			
              	this.getEvents=function(){				
                   return $http({
                          url: UtilsService.EventUrl,
                          method: "GET"            
                          }).then(function(data)
                          {        
                             return data.data;
                          });  
              	}

               this.getCountries=function(){
                          return $http.get(UtilsService.CountryUrl).then(function(data){                      
                          return data.data;
                          });
               }   

                 /*
                 this.getVisitorsData=function(reportdata){
                  
                  return $http({
                              url: UtilsService.VisitorReportUrl +"/"+ reportdata.eventids+ "/"+ reportdata.visitortype, //+"/"+reportdata.startdate+"/"+reportdata.enddate,
                              method: "GET",                                    
                              }).then(function(data)
                                 {          
                                   return data.data;
                                 });
                 } */



                /* export country report data */
                 this.excelExportcountries = function (countries){
                 return $http({
                  url: UtilsService.CountryReportDataUrl +"/"+ "Export",
                        method: "POST",
                        data: countries,
                        responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }


                  /* export region report data */
                 this.excelExportregions = function (regions){
                 return $http({
                  url: UtilsService.RegionReportDataUrl +"/"+ "Export",
                        method: "POST",
                        data: regions,
                        responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }

                 this.getVisitorsData=function(visitorreportdata){
                          return $http({
                                      url: UtilsService.VisitorReportUrl,
                                      method: "POST",  
                                      data:visitorreportdata                                  
                                      }).then(function(data)
                                         {          
                                           return data.data;
                                         });
                         }

                          this.excelExportVisitor = function (visitorreport){
                           return $http({
                             url: UtilsService.VisitorReportUrl +"/"+ "Export",
                             method: "POST",
                             data: visitorreport,
                             responseType: 'arraybuffer'
                            }).then(function(data){  
                             return data;
                           },function(error){ return data.data});
                           }  


      
              /*POS Report Data   */

             this.getPassReportData=function(posreportdata){
               return $http({
                          url: UtilsService.POSReportDataUrl,
                          method: "POST",  
                          data:posreportdata                                  
                          }).then(function(data)
                             {          
                               return data.data;
                             });
                 }

                 this.getPOSReportData=function(posreportdata){
                  return $http({
                  url: UtilsService.POSReportDataUrl+"/"+"efficiency",
                  method: "POST",  
                  data:posreportdata                                  
                  }).then(function(data){          
                       return data.data;
                     });
               }    

               this.getTimeReportData=function(reportdata){   
                          return $http({
                              method: "POST",
                              url: UtilsService.TimeReportDataUrl,
                              data: reportdata 
                           }).then(function(data)
                           {          
                             return data.data;
                           });
                       }

                 this.getEventPeriodReportData=function(eventIds){
                   return $http({
                  url: UtilsService.DashboardMasterEventPeriodReportUrl +"/"+eventIds,
                  method: "GET"                       
                  }).then(function(data)
                     {          
                       return data.data;
                     });
                }

                 /* get regionwise report data */        
               this.getRegionWiseReportDate=function(reportdata){     
               return $http({
               method: "POST",
                        url: UtilsService.CountryReportDataUrl + "/"+"regiondata",
                        data: reportdata 
                     }).then(function(data){          
                       return data.data;
                     });
                 }
                  
                  /*get countrywise report data */
                  this.getCountryWiseReportDate=function(reportdata){   
                    return $http({
                    method: "POST",
                        url: UtilsService.CountryReportDataUrl + "/"+"countrydata",
                        data: reportdata 
                     }).then(function(data){          
                       return data.data;
                     });
                 } 


 
             this.excelExportTime = function (timereport){
 
                 return $http({
                  url: UtilsService.TimeReportDataUrl +"/"+ "Export",
                        method: "POST",
                        data: timereport,
                        responseType: 'arraybuffer'
                  }).then(function(data)
                     {  
                       return data;
                     },function(error){ return data.data});
      }    

       /* POS Report Data */   

          /* this.getPassReportData=function(passreportdata){   
          return $http({
            method: "POST",
                        url: UtilsService.PASSReportDataUrl,
                        method: "POST", 
                        data: passreportdata 
                     }).then(function(data)
                     {          
                       return data.data;
                     });
                 }  */


         this.getPOSReportData=function(posreportdata){
         return $http({
                  url: UtilsService.POSReportDataUrl+"/"+"efficiency",
                  method: "POST",  
                  data:posreportdata                                  
                  }).then(function(data)
                     {          
                       return data.data;
                     });
         }


               this.excelExportPOS = function (posreport){
                  return $http({
                  url: UtilsService.POSReportDataUrl +"/"+ "Export",
                        method: "POST",
                        data: posreport,
                        responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }  

         /* end of POS Report Data */

         /*Staff Report Data */

         this.getStaffPassReportData=function(staffreportdata){
         return $http({
                  url: UtilsService.StaffReportDataUrl,
                  method: "POST",  
                  data:staffreportdata                                  
                  }).then(function(data)
                     {          
                       return data.data;
                     });
         }

         this.getStaffPOSReportData=function(staffreportdata){
         return $http({
                  url: UtilsService.StaffReportDataUrl +"/"+"efficiency",
                  method: "POST",  
                  data:staffreportdata                                  
                  }).then(function(data)
                     {          
                       return data.data;
                     });
         }

          this.excelExportStaff = function (staffreport){
                  return $http({
                  url: UtilsService.StaffReportDataUrl +"/"+ "Export",
                        method: "POST",
                        data: staffreport,
                        responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }  

         /*end of Staff Report Data */ 

         /* Survey Report */ 
         this.getSurveyData=function(surveyreportdata){
                return $http({
                    url: UtilsService.SurveyReportUrl,
                    method: "POST",  
                    data:surveyreportdata                                  
                    }).then(function(data){          
                    return data.data;
                    });
                    }
          
          this.excelExportSurvey = function (surveyreport){
                  return $http({
                  url: UtilsService.SurveyReportUrl +"/"+ "ExportSurvey",
                        method: "POST",
                        data: surveyreport,
                        responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }  

         /* End of Survey Reprt */
         /* Reports PDF.............. */
         
          /* export region and country pdf report data */
                 this.exportCountryPdf = function (regions,countries,imageData,ReportEvent,eventperiod){
                 return $http({
                  url: UtilsService.exportCountryPdfUrl,
                        method: "POST",
                        data: {regions:regions,countries:countries,image:imageData,eventdata:ReportEvent,eventPeriod:eventperiod},
                          responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }
                /* export POS Pdf report data */
                this.exportPOSPdf = function (passgenerationdata,posefficiencydata,ReportEvent,eventperiod){
                 return $http({
                  url: UtilsService.exportPOSPdfUrl,
                        method: "POST",
                        data: {passGeneration:passgenerationdata,posEfficiency:posefficiencydata,eventdata:ReportEvent,eventPeriod:eventperiod},
                          responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }
                 /* export Staff Pdf report data */
                this.exportStaffPdf = function (staffgeneration,staffefficiency,ReportEvent,eventperiod){
                 return $http({
                  url: UtilsService.exportStaffPdfUrl,
                        method: "POST",
                        data: {staffGeneration:staffgeneration,staffEfficiency:staffefficiency,eventdata:ReportEvent,eventPeriod:eventperiod},
                          responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }
                 /* export Visitor Pdf report data */
                this.exportVisitorPdf = function (reportTime){
                 return $http({
                  url: UtilsService.exportVisitorPdfUrl,
                        method: "POST",
                        data: reportTime,
                          responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }
                /* export Time Pdf report data */
                this.exportTimeReportPdf = function (timedata,image,ReportEvent,tab,eventperiod){
                 return $http({
                  url: UtilsService.exportTimePdfUrl,
                        method: "POST",
                        data: {timeData:timedata,image:image,eventdata:ReportEvent,activeTab:tab,eventPeriod:eventperiod},
                          responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }
                /* export Time Pdf report data */
                this.exportSurveyReportPdf = function (surveydata,ReportEvent,eventperiod){
                 return $http({
                  url: UtilsService.exportSurveyPdfUrl,
                        method: "POST",
                        data: {surveyData:surveydata,eventdata:ReportEvent,eventPeriod:eventperiod},
                          responseType: 'arraybuffer'
                  }).then(function(data){  
                       return data;
                     },function(error){ return data.data});
                 }
            
     })
});