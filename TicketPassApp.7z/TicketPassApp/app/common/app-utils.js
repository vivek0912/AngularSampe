define(
	function(require)
	{
		angular.module("app").service("UtilsService",
			function($location,$timeout)
			{

				//this.domine ="http://182.156.90.124:2019";
				//this.domine="http://192.10.250.190:2022";			         
                this.domine = "http://localhost:50673";
				this.Login = this.domine+"/login";
				this.Forgot = this.domine+"/forgot";
				this.Reset = this.domine+"/reset";
				this.ValidPwdUrl = this.domine+"/validatePwd";
				this.CompanyUrl=this.domine + "/company";
				this.AddCompanyUrl=this.domine+"/company/add"
				this.CountryUrl=this.domine + "/countryCode";
				this.EventUrl=this.domine + "/events";				
				this.VisitorUrl=this.domine+"/visitors";
				this.PageLoadVisitorUrl=this.domine+"/syncvisitors";
				this.ExhibitorUrl=this.domine+"/exhibitors";
				this.LocationUrl=this.domine+"/Locations";
				this.AddLocationUrl=this.domine+"/Locations/add";			
				this.UserUrl=this.domine + "/users";
				this.CheckEmail=this.domine+"/checkUserEmail";	
				this.SiteServerUrl=this.domine + "/siteserverdetails";
				//
				this.GetSiteServerDetails=this.domine + "/siteServerdetailsbyId"; 
				//...
				this.IntegrationUrl=this.domine+"/serverIntegrations";
				this.PosUrl=this.domine +"/posdetails";	
				this.CompanySearchUrl=this.domine + "/companysearch";		
				this.ContrySearchUrl = this.domine+"/countrysearch";
				this.PosByIDUrl=this.domine +"/POS";
				this.VisitorPassUrl=this.domine +"/passbypos";		
				this.EventSiteUrl=this.domine +"/eventServer";
				this.eventsSearchUrl=this.domine + "/eventsearch";			
				this.EventSiteSaveUrl=this.domine +"/saveMultipleEventServers";		
				this.EventSiteUrl=this.domine +"/eventServer";	
				this.VisitorTypeUrl=this.domine +"/visitortypes";	
				this.CustomVisitorTypeUrl=this.domine +"/customVisitorTypes";	
				this.BadgeRuleUrl=this.domine +"/badgerules";	
				this.EventLocationSaveUrl=this.domine +"/saveMultipleEventLocations";	
				this.EventLocationUrl=this.domine +"/eventlocations";	
				this.DeleteSiteServerUrl=this.domine +"/siteServer";	
				this.EventServerUrl=this.domine + "/eventServer";
				this.EventCustomVisitorTypeUrl=this.domine + "/eventcustomVisitorTypes";
				this.GetSurveyUrl=this.domine+ "/surveysdetails"; // for survey
				this.SurveyUrl=this.domine+ "/surveys";
				this.SurveyStatusUrl=this.domine+ "/surveysStatus";
				this.SurveyResponse=this.domine+ "/surverResultDetails";
				this.SyncVisitorsUrl= this.domine +"/syncttsvisitors";	
				this.SurveyPublicURl = this.domine+"/surveys/";
				this.SurveyResult = this.domine+"/surverResult";
                this.DashboardMasterEventReportUrl=this.domine+"/masterservereventreport";
                this.RegionUrl=this.domine + "/regions";
                this.DashboardMasterEventPeriodReportUrl=this.domine+ "/masterservereventperiodreport";
                this.LocalOverseasVisitorTypeUrl=this.domine+"/localoverseasvisitortypes";
                this.CountryReportDataUrl=this.domine + "/countryreport";
                this.CountryResult = this.domine+"/Export";
                this.POSReportDataUrl=this.domine+"/posreport";
                this.StaffReportDataUrl=this.domine+"/staffreport";
                this.VisitorReportUrl=this.domine + "/visitorsreportdata";
                this.SurveyReportUrl=this.domine+"/surveyreport";
                this.TimeReportDataUrl=this.domine+"/timereport";
                this.FilteredVisitorsURL=this.domine+"/filteredvisitors";
                this.FilteredExhibitorsURL=this.domine+"/filteredexhibitors";
                //this.POSReportDataUrl=this.domine+"/posreport";
                this.PASSReportDataUrl=this.domine+"/passreport";
                this.SurevyResponseURL=this.domine+"/surverResponse";
                this.exportCountryPdfUrl=this.domine+"/exportCountryPdf";
                this.exportPOSPdfUrl=this.domine+"/exportPOSPdf";
                this.exportStaffPdfUrl=this.domine+"/exportStaffPdf";
                this.exportVisitorPdfUrl=this.domine+"/exportVisitorPdf";
                this.exportTimePdfUrl=this.domine+"/exportTimeHourPdf";
                this.exportSurveyPdfUrl=this.domine+"/exportSurveyPdf";
                this.SurveyResultExcel = this.domine+"/surverResultExcelExport";

			}

	
	)});