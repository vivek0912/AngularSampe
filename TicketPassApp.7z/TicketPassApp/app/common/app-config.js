define(function(require)
{
	var angular=require("angular");		
	angular.module("app").factory("config",function()
		{
			return{website:"http://singtel.projects.phokki.com/e-invoice/site/#/",
			apiPath:"http://singtel.projects.phokki.com/e-invoice/api/index.php/"}
		})
});