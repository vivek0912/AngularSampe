    define(function(require){
      angular.module("app").service("companyService",function($http,UtilsService){
    			       //get all companies
                this.getCompanies=function(){
               
                    return $http
                    .get(UtilsService.CompanyUrl)
                    .then(function(data){     

                        return data;
                     });   
                }
                //get specific company
                this.getCompany=function(companyId){ 
                          
                    return $http({
                            url: UtilsService.CompanyUrl+"/"+companyId,
                            method: "GET"            
                            }).then(function(data)
                                      {                    
                                         return data;
                                      });
                }
                //get company by search Text
                this.getCompanybyText = function(searchText)
                    {
                    return $http.get(UtilsService.CompanySearchUrl+"/"+searchText).then(function(data){          
                          return data.data;
                          },function(error){ 
                            return error; 
                          });
                    }
                //create company
                this.saveCompany=function(company){
               
                    var response = $http({
                                    method: "POST",
                                    url: UtilsService.AddCompanyUrl,
                                    data: company,
                                    dataType: "json"});
                                    return response;        
                }
                //delete company
                this.deleteCompanyData=function(companyId){   
                    var response= $http({
                                    url: UtilsService.CompanyUrl+"/"+companyId,
                                      method: "DELETE"});
                                    return response;
                }
                //multiple deletion
                this.deleteMultipleCompany=function(company){
                  return $http({
                    url: UtilsService.CompanyUrl +"/"+ "DeleteMultiple",
                          method: "POST",
                          data: company
                    }).then(function(data)
                       {          
                         return data;
                       });


                }
               //update company
               this.updateCompany=function(companyProfile){
                   var response = $http({
                                   method: "PUT",
                                    url: UtilsService.CompanyUrl,
                                   data: companyProfile,
                                   dataType: "json"});
                                      return response;
            }

            this.UploadCompany = function(blob){
               var fd = new FormData(document.forms[0]);
                var UserDetails = JSON.parse(window.localStorage.getItem("UserDetails")); 
                fd.append("file", blob);
                var token = UserDetails.AuthToken;
                return $.ajax({           
                    url: UtilsService.CompanyUrl +"/uploadexcel",
                    data: fd,
                    cache: false,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader("token", token);
                    },
                    contentType: false,
                    processData: false,
                    type: 'POST',
                    success: function (data) {               
                        return data;
                    }
                });
            }
        
    	});	
    });