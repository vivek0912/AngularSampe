define(function(required){
	angular.module("app").service("eventService",function ($http,UtilsService) {		

        	this.getEvents=function(){				
        		return $http({
                            url: UtilsService.EventUrl,
                            method: "GET"            
                            }).then(function(data)
                                      {        
                                         return data.data;
                                      });
                
        	}

        	this.getactiveEvents = function()
        		{
        			return $http.get(UtilsService.EventUrl +"/active").then(function(data, textStatus, xhr){ 
        			  	 		if(data.data.status == 200)
        			  	 		{
        				      		return data.data;
        			  	 		}
        				  },function(error){ return error; });
        		}

              this.saveEvent=function(event)
                {        
                    return $http({
                      url: UtilsService.EventUrl,
                            method: "PUT",
                            data: event
                      }).then(function(data)
                         {     
                           return data;
                         });           
                
                  
                }
             this.getAllEvents = function(){
              return $http({
                            url: UtilsService.EventUrl+"/all",
                            method: "GET"            
                            }).then(function(data)
                                      {        
                                         return data.data;
                                      });
             }      
             this.deleteEvent=function(event){   
               event.IsActive = false;
                return $http({
                      url: UtilsService.EventUrl,
                            method: "PUT",
                            data: event
                      }).then(function(data)
                         {    
                           return data;
                         });
               }	

            this.getEventServers=function() {     
                    return $http({
                        url: UtilsService.EventSiteUrl,
                        method: "GET"            
                        }).then(function(data)
                          {       
                             return data;
                          });
              }  

            this.getSiteServers=function() {     
                   return $http
                     .get(UtilsService.SiteServerUrl)
                     .then(function (result) {   
                       return result.data;
                     },function(error){ return error; });
                 }    

        	   this.getEvent=function(eventId){                   
                return $http({
                        url: UtilsService.EventUrl+"/"+eventId,
                        method: "GET"            
                        }).then(function(data)
                          {        
                             return data;
                          });
                }	

          this.getVisitorTypes=function() {     
                   return $http
                     .get(UtilsService.VisitorTypeUrl)
                     .then(function (result) { 
                       return result.data.data;
                     },function(error){ return error; });
             }   

             //get local & overseas visitors
             this.getLocalOverseasVisitorTypes=function() {     
                   return $http
                     .get(UtilsService.LocalOverseasVisitorTypeUrl)
                     .then(function (result) { 
                       return result.data.data;
                     },function(error){ return error; });
             }   

             this.getEventPeriodReportData=function(eventIds){
              return $http({
                          url: UtilsService.DashboardMasterEventPeriodReportUrl +"/"+eventIds,
                          method: "GET"                       
                          }).then(function(data)
                             {          
                               return data.data;
                             });
             }



            this.getCustomVisitorTypes=function(eventId) {   
                    return $http({
                          url: UtilsService.EventCustomVisitorTypeUrl +"/"+eventId,
                          method: "GET"                       
                          }).then(function(data)
                             {          
                               return data.data;
                             });
            }   

           this.saveMultipleEventSiteServers = function (siteservers, eventId)
                {
                  return $http({
                          url: UtilsService.EventSiteSaveUrl +"/"+eventId,
                                method: "POST",
                                data: siteservers
                          }).then(function(data)
                             {          
                               return data;
                             });
                }

           this.saveCustomVisitorType=function(CustomVisitorType)
                {    
                if(CustomVisitorType.CustomVisitorType_Id==null || CustomVisitorType.CustomVisitorType_Id==undefined)
                  {
                       return $http({
                          url: UtilsService.CustomVisitorTypeUrl,
                                method: "POST",
                                data: CustomVisitorType
                          }).then(function(data)
                             {     
                               return data;
                      });     

                  }
                   else
                   {
                        return $http({
                          url: UtilsService.CustomVisitorTypeUrl,
                                method: "PUT",
                                data: CustomVisitorType
                          }).then(function(data)
                             {     
                               return data;
                      });     
                  }      
                
                  
                }

           this.deleteCustomVisitorType=function(customVisitorTypeId){    
                  var response= $http({
                                  url: UtilsService.CustomVisitorTypeUrl+"/"+customVisitorTypeId,
                                    method: "DELETE"});
                                  return response;
            } 


          this.veryPassword = function (user) {
                  return $http
                    .post(UtilsService.Login, user)
                    .then(function (res) {             
                      return res.data;
                    },function(error){ return error; });
                };

            this.getLocations=function(){          
                  return $http.get(UtilsService.LocationUrl).then(function(data){           
                  return data.data;
                  });
                }

          this.getBadgeRulesTypes = function (badgeRule)
                {
                  return $http({
                          url: UtilsService.BadgeRuleUrl,
                                method: "POST",
                                data: badgeRule
                          }).then(function(data)
                             {          
                               return data.data;
                             });
                }

            this.saveBadgeRule=function(badgeRule)
                {    
                 if(badgeRule.BadgeRule_Id==null || badgeRule.BadgeRule_Id==undefined || badgeRule.BadgeRule_Id==0)
                  { 
                    return $http({
                      url: UtilsService.BadgeRuleUrl+"/add",
                            method: "POST",
                            data: badgeRule
                      }).then(function(data)
                         {     
                           return data;
                         });
                    
                  }
                  else
                  {
                      return $http({
                          url: UtilsService.BadgeRuleUrl+"/update",
                                method: "PUT",
                                data: badgeRule 
                          }).then(function(data)
                             {     
                               return data;
                            });     

                  }
                  
                }

             this.getCustomVisitorType=function(customVisitorTypeId){                   
                return $http({
                        url: UtilsService.CustomVisitorTypeUrl+"/"+customVisitorTypeId,
                        method: "GET"            
                        }).then(function(data)
                          {        
                             return data.data;
                          });
                } 

          this.saveEventLocations = function (eventlocations)
            {
              return $http({
                      url: UtilsService.EventLocationSaveUrl,
                            method: "POST",
                            data: eventlocations
                      }).then(function(data)
                         {          
                           return data;
                         });
            }  

             this.getEventLocations=function(eventId){                   
            return $http({
                    url: UtilsService.EventLocationUrl+"/"+eventId,
                    method: "GET"            
                    }).then(function(data)
                      {        
                         return data;
                      });
            }  

           /*this.getEvents=function(){		
        			return $http({
        	                    url: UtilsService.EventServerUrl,
        	                     method: "GET"            
        	                      }).then(function(data)
        	                            {        
        	                             return data.data;
        	                             });
        		}*/

        	this.getEventData=function(eventServerId){                  
                return $http({
                        url: UtilsService.EventServerUrl+"/"+eventServerId,
                        method: "GET"            
                        }).then(function(data)
                          {        
                             return data;
                          });
            }
             //get event by search Text
                this.getEventbyText = function(searchText){
                      
                    return $http.get(UtilsService.eventsSearchUrl+"/"+searchText).then(function(data){          
                          return data.data;
                          },function(error){ 
                            return error; 
                          });
                    }

                    //get event by search Text
                this.getEventsforVisitor = function(){
                      
                    return $http.get(UtilsService.EventUrl+"/forvisitors").then(function(data){          
                          return data.data;
                          },function(error){ 
                            return error; 
                          });
                    }

              this.saveVisitorType = function (Visitor_Type)
              {
              return $http({
                      url: UtilsService.VisitorTypeUrl,
                            method: "PUT",
                            data: Visitor_Type                         
                        
                      }).then(function(data)
                         {         
                           return data;
                         });
              }
              this.ImportExcelData = function(blob)
              {
                var fd = new FormData();
                var UserDetails = JSON.parse(window.localStorage.getItem("UserDetails")); 
                fd.append("file", blob);
                var token = UserDetails.AuthToken;
                return $.ajax({           
                    url: UtilsService.EventUrl +"/importexcel",
                    data: fd,
                    cache: false,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader("token", token);
                    },
                    contentType: false,
                    processData: false,
                    type: 'POST',
                    success: function (data) {               
                        return data;
                    }
                  });
                }
                this.ImportExcelDataStatus = function ()
                {
                  return $http({
                          url: UtilsService.EventUrl+"/importexcelstatus",
                                method: "GET",
                          }).then(function(data)
                             {         
                               return data;
                             });
                }

 });});
