	define(function(require){
		angular.module("app").
				service("locationService",function($http,UtilsService)
				{
					//get locations
						this.getLocations=function(){
							
							return $http.get(UtilsService.LocationUrl).then(function(data){						
							return data;
							});
						}
					//get specific location
						this.getLocation=function(locationId){					
							return $http.get(UtilsService.LocationUrl+"/"+locationId)
							.then(function(data){						
							return data;
							});
					
						}
					//create locayion
						this.saveLocation=function(location){
						
							var response = $http({
										method: "POST",
										url: UtilsService.AddLocationUrl,
										data: location,
										dataType: "json"});
										return response;	
						}
					//update location
						this.updateLocation=function(location){
				 			var response = $http({
                               			method: "PUT",
                               			url: UtilsService.LocationUrl,
                               			data: location,
                               			dataType: "json"});
                                  		return response;
						}
					//delete location
						this.deleteLocationData=function(locationId){
							
							var response= $http({
			                    		url: UtilsService.LocationUrl+"/"+locationId,
			                    		method: "DELETE"});
			                    		return response;
						}
					//multiple deletion
						this.deleteMultipleLocation=function(locations){
			   					return $http({
                  						url: UtilsService.LocationUrl +"/"+ "DeleteMultiple",
                        				method: "POST",
                        				data: locations
                  						}).then(function(data)
                     			{          
                       			return data;
                     		});
						}


				});//End service()
	});