define(
	function(require)
	{
		angular.module("app").factory("apiService",
			function($http,$location,$window,$q,config,$rootScope)
			{
				var defaults=
				{
					onFail:function(error)
					{console.log("fail: "+error.reason),$rootScope.alerts=[
					{show:1,type:"danger",title:"Error",text:error.reason,dismissTimeout:5e3}]},
					onError:function(error,status)
					{console.log("error: "+error.reason),
					$rootScope.alerts=[{show:1,type:"danger",title:"Error",
					text:error.reason,dismissTimeout:5e3}]}},
					ajaxPost=function(apiName,params,onSuccess,onFail,onError,isDefer)
					{var deferred=$q.defer(),url=config.apiPath+apiName+"?callback=JSON_CALLBACK";
					return params.session_key=$window.localStorage.getItem("session_key"),
					onSuccess=angular.isFunction(onSuccess)?onSuccess:function(){},
					onFail=angular.isFunction(onFail)?onFail:defaults.onFail,o
					nError=angular.isFunction(onError)?onError:defaults.onError,
					$http({method:"jsonp",url:url,params:params,timeout:1e4}).
					success(function(response){"ok"===response.status?(
						onSuccess(response),deferred.resolve(!0)):
					(1===response.errorId||2===response.errorId||3===response.errorId?
						$location.url("/user/login"):(console.warn("API Warning: "+url),
							console.warn(response.reason),onFail(response)),deferred.resolve(!1))}).
					error(function(error,status){var message=error||"Request Failed";onError(message,status),
						deferred.reject(error)}),deferred.promise};return{ajaxPost:ajaxPost}
			})
	});