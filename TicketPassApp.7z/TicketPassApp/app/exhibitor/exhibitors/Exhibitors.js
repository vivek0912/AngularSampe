define(function(require){
  angular.module("app").controller("exhibitorsCtrl",function($window,exhibitorService,eventService,apiService,
    dataFactory,$scope,$location,$timeout,$state,$rootScope,$translate,filterFilter){
    $scope.deletedExhibitors=[];
    $scope.deletedExhibitornames="";
    $scope.exibitorDeletedShow = false;
    $scope.exibitorMultipleDeletedShow=false;
    $scope.showeerror = false;
    $scope.exibitorSingleSelectDeletedShow=false;
    $scope.errorMessage ='';
    $scope.noitemsselected = 'no item selected';  
    $scope.exhibitors =[];    
    $scope.NewExhibitor = {};
    $scope.isupdate = false;
    $scope.isadd = false;
    $scope.exhibitorDataTable;
    $scope.totalItems=0;
    $scope.currentPage=0;
    $scope.nodata=false; 
    localStorage.removeItem("allvisitor"); 
    localStorage.removeItem("alluser");
    localStorage.removeItem("eventtype"); 
        $scope.PageOptions = {
          10: 10,
          20: 20,
          30: 30      
        };
       
     setTimeout(function() { 
                 
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
             
             $("#menu-toggle").click(function(e) {                          
            e.preventDefault();
            $(".content").toggleClass("toggled");
            });
             
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar").toggleClass("toggled");
            });
 
        }, 1500);

    $scope.addExhibitor = function()
     {
          localStorage.removeItem("exhibitor");    
        dataFactory.setexhibitor($scope.NewExhibitor)     
        $location.url("/exhibitors/addexhibitors");
     }
     $scope.impExhibitor = function()
     {
        $location.url("/exhibitors/impexhibitors");
     }

     var noitemfounds = "";
        var searchtext = "";

         $translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
                    });
         $translate(['searchexhibitor']).then(function (translations) {
                      searchtext = translations.searchexhibitor;                      
         });
         
      $scope.SearchByEvent = function(searchString)
      {
        if($scope.EvenSelected != null)
        {
            if(($scope.SearchString==null)|| ($scope.SearchString=="")){  
             searchresult = "All Exhibitors"; 
                 $scope.GetFilteredExhibitors(searchString);
             }
             else
             {
              $scope.GetFilteredExhibitors(searchString);
             }
        }
        else 
        {
           if(($scope.SearchString==null)|| ($scope.SearchString=="")){  
             searchresult = "All Exhibitors"; 
               dataFactory.setAllExhibitor("All"); 
                 $scope.GetFilteredExhibitors(searchString);
             }
          else
          {
            $scope.GetFilteredExhibitors(searchString);
          }
          $scope.ExhibitorsResule = $scope.visitors;
        }       
      }
     $scope.displayExhibitor = function()
      {
        eventService.getEventsforVisitor().then(function(data){ 
            $scope.events=data.data;          
              if(dataFactory.getAllExhibitor()!="All" )
                {
                   if(data.data.length > 0)
                        $scope.EvenSelected = data.data[0];
                    $scope.Event_Id=$scope.EvenSelected.Event_Id;
                    $scope.SelectedEventId = $scope.EvenSelected.Event_Id;
                    $scope.eventId=dataFactory.getEventId();    
                    if($scope.eventId!==undefined && $scope.eventId != null)
                    {
                      $scope.SelectedEventId =parseInt($scope.eventId);
                       var selectedEvent = $scope.events.filter(function(e) { return e.Event_Id === $scope.SelectedEventId; });
                       $scope.EvenSelected= selectedEvent[0];
                       $scope.Event_Id=$scope.EvenSelected.Event_Id; 
                        $scope.nodata=true;             
                    }
                }
                else{
                  $scope.Event_Id=0;
                  //scope.EvenSelected="All Events";
                }
        
            if($scope.events.length > 0)
            {
                exhibitorService.getFilteredExhibitors("All Exhibitors",$scope.Event_Id).then(function(Response){
                     
                      if(Response.length >0)
                      {
                          $scope.exhibitors=Response;
                                 // pagination controls
                          $scope.currentPage = 1;
                          $scope.totalItems = $scope.exhibitors.length;
                          $scope.entryLimit = 10; // items per page
                          $scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
                                    $scope.maxSize = 10; //Number of pager buttons to show
                                     if( $scope.exhibitors.length == 0){
                                      $scope.nodata=false;   
                                    }
                                    else
                                    {
                                      $scope.nodata=true;  
                                    }                                                          
                        }
                        else
                        {
                        	 $scope.entryLimit = 10; 
                        	 $scope.nodata=false;   
                        }
                        localStorage.removeItem("eventid");
                });
            }
        });
       
    }

    $scope.DeleteExhibitor = function(exhibitor)
    {
        $scope.deletedExhibitors =[];
        $scope.deletedExhibitors.push(exhibitor);
        exhibitorService.deleteExhibitor(exhibitor.Exhibitor_Id).then(function(Response){
          if(Response.data.status === 200)
          {   
            $scope.displayExhibitor();  
            $scope.ShowDeletedMessage(true); 
                                    
          }
          else
          {
            $scope.showErrorMessage(Response.data.err_msg);
          }

        });

    }

    $scope.DeletemMultipleExhibitors = function()
    {
      
      var list = $scope.exhibitors.filter(function (obj) {
                    if (obj.checked !== undefined && obj.checked === true) {
                        return obj;
                    }
                });
      if(list.length==1)
          $scope.singleItemSelected=true;
        else
          $scope.singleItemSelected=false;


       if(list.length > 0)
       {      
        exhibitorService.deletemMultipleExhibitors(list).then(function(Response){
          
          $scope.deletedExhibitornames="";

                    angular.forEach(list, function(value){
                    $scope.deletedExhibitornames += value.Staff_Name+',';
                    $scope.EventName=value.EventName;
                    })
                     $scope.deletedExhibitornames= $scope.deletedExhibitornames.substring(0, $scope.deletedExhibitornames.length - 1);
            if(Response.data.status === 200)
            {
              $scope.displayExhibitor();  
              $scope.ShowDeletedMessage();  
                          
            }
            else
            {
              $scope.showErrorMessage(Response.data.err_msg);
            }

          });
      }
    }
    $scope.showErrorMessage = function(message)
      {
          $scope.errorMessage = message;
          $scope.showeerror = true;
         $timeout(function () {
          $scope.errorMessage = '';
          $scope.showeerror = false;
      }, 3000);
      }

    $scope.ShowDeletedMessage = function(singleDelete)
      {           
        
        if(singleDelete==true)
        {
               $scope.exibitorDeletedShow = true; 
                $timeout(function () {
          $scope.exibitorDeletedShow = false;
         
      }, 3000);
        }
        else
        {
          if($scope.singleItemSelected==true)
            $scope.exibitorSingleSelectDeletedShow=true;
          else
                  $scope.exibitorMultipleDeletedShow=true;

          $timeout(function () {
          $scope.exibitorMultipleDeletedShow = false;
          $scope.exibitorSingleSelectDeletedShow=false;
          }, 3000);
        } 
      }

    $scope.exhibitorCheckedchanged = function()
    {
      var list = $scope.exhibitors.filter(function (obj) {
                    if (obj.checked !== undefined && obj.checked === true) {
                        return obj;
                    }
                });
        if(list.length == 1)
          $scope.noitemsselected = list.length + " item selected";
        else if (list.length > 1)
          $scope.noitemsselected = list.length + " items selected";
        else 
          $scope.noitemsselected = 'no item selected';
    }
    $scope.ExhibitorProfilc = function(exhibitor)
    {     
      localStorage.removeItem("exhibitor"); 
      if(exhibitor!==undefined)
      {
          dataFactory.setEventId(exhibitor.Event_Id);
      }     
      dataFactory.setexhibitor(exhibitor)
      $location.url("exhibitors/addexhibitors");
    }
    
    $scope.ShowMessageAddUpdate = function()
    {
      var exhibitor = dataFactory.getexhibitor();
      if(exhibitor!=null)
      {
      if(exhibitor !== undefined && exhibitor.update !== undefined)
      {
        $scope.deletedExhibitors.push(exhibitor);
        if(exhibitor.update === true)
          $scope.isupdate = true;
        else
          $scope.isadd = true;

        $timeout(function () {
            $scope.isupdate = false;
            $scope.isadd = false;
            $scope.deletedExhibitors =[];
            $scope.deletedExhibitornames="";
        }, 3000);

      }
      }
    }

    $scope.GetFilteredExhibitors = function(searchresult){    
      if((searchresult==null)|| (searchresult=="")){    
                 searchresult = "All Exhibitors";
             }
      if($scope.EvenSelected !=null)
      {
        $scope.EventID=$scope.EvenSelected.Event_Id;
         localStorage.removeItem("allexhibitor");
      }
      else
      {
        $scope.EventID=0;
      }
        //dataFactory.setSelectedEvent($scope.EventID);
      exhibitorService.getFilteredExhibitors(searchresult,$scope.EventID).then(function(data){            
              $scope.exhibitors=data;
              // pagination controls
              $scope.currentPage = 1;
              $scope.totalItems = $scope.exhibitors.length;
              $scope.entryLimit = 10; // items per page
              $scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
              $scope.maxSize = 10; //Number of pager buttons to show

             if( $scope.exhibitors.length == 0){
              $scope.nodata=false;   
              }
              else
              {
                $scope.nodata=true;  
              }

         });
                
     }
        $scope.DownloadExhibitorTemplate = function()
        {
             $scope.fileName = 'ExhibitorTemplate.xlsx';             
             exhibitorService.DownloadExcelTemplate($scope.fileName).then(function (data) {         
               if(data.status == 200){
                var blob = new Blob([data.data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});          
               saveFile( $scope.fileName, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", blob);
               }
            });
         }
         
        function saveFile (name, type, data) {
            if (data != null && navigator.msSaveBlob)
                return navigator.msSaveBlob(new Blob([data], { type: type }), name);
            var a = $("<a style='display: none;'/>");
            var url = window.URL.createObjectURL(new Blob([data], {type: type}));
            a.attr("href", url);
            a.attr("download", name);
            $("body").append(a);
            a[0].click();
            window.URL.revokeObjectURL(url);
            a.remove();
            }


    $scope.displayExhibitor();  
    $scope.ShowMessageAddUpdate();
 })
});