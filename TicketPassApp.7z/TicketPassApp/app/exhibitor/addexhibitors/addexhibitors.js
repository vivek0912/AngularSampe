define(function(require){
	angular.module("app").controller("addexhibitorsCtrl",function($window,exhibitorService,eventService,companyService,apiService,$scope,$location,$state,$rootScope,$timeout,dataFactory,$sce){
		$scope.Exhibitor = dataFactory.getexhibitor();		
		$scope.activeEvents = [];
		$scope.EvenSelected=[];	
		$scope.selectedCompany ={};	
		$scope.companyfilter =[];	
		$scope.isUpdateExhibitor =false;

    $timeout(function() {  
        	
        	$('.Toggleonload').click(function(){                		 
				$(this).find("i").toggleClass("fa-angle-down");
			 });
         
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
             
             $("#menu-toggle").click(function(e) {                          
            e.preventDefault();
            $(".content").toggleClass("toggled");
            });
             
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar").toggleClass("toggled");
            });

        }, 1500);
            
		$scope.addExhibitor = function()
		 {
		 	
		 	$scope.Exhibitor.Company_id = $scope.selectedCompany.Company_Id;
		 	//$scope.Exhibitor.Event_Id = $scope.Exhibitor.EvenSelected.Event_Id;
		 	//$scope.Exhibitor.EventName = $scope.Exhibitor.EvenSelected.Name;
		 	if($scope.Exhibitor.Exhibitor_Id === undefined)
		 	{
			 	exhibitorService.AddExhibitor($scope.Exhibitor).then(function(Response){
			 		
			 			if(Response.status == 200)
						{
							$scope.Exhibitor.update = false;
							dataFactory.setexhibitor($scope.Exhibitor)
							$location.url("/exhibitors");
						}
			 	});
		 	}
		 	else
		 	{
		 		
		 		exhibitorService.UpdateExhibitor($scope.Exhibitor).then(function(Response){
		 			
			 			if(Response.status == 200)
						{
							$scope.Exhibitor.update = true;
							dataFactory.setexhibitor($scope.Exhibitor)
							$location.url("/exhibitors");
						}
			 	});
		 	}
		 		
		 }
		 $scope.cancelExhibitor = function()
		 {
		 	$location.url("/exhibitors");
		 }
		 
		  function suggest_state(term) {
			   var q = term.toLowerCase().trim();
			  return companyService.getCompanybyText(q).then(function(Response){
			 		if(Response.status == 200)
					{
						$scope.companyfilter = Response.data;
						var results =[];
						for (var i = 0; i < $scope.companyfilter.length; i++) {
						     var user = $scope.companyfilter[i];
						     if (user.Company_Name.toLowerCase().indexOf(q) !== -1)
						       results.push({
						         value: user.Company_Name,
						         // Pass the object as well. Can be any property name.
						         obj: user,
						         label: $sce.trustAsHtml(user.Company_Name)
						       });
						   }
						    $timeout(function() {  
						   		$(".ac-container").css("top","");
						   		$(".ac-container").css("left","");
							},200);
					 	return results;
					}
		 		});				
		  }
		  $scope.autocomplete_options = {
		    suggest: suggest_state,
		    on_select: function (selected) {
			    $scope.Exhibitor.Company_Name = selected.obj.Company_Name;
			    $scope.Exhibitor.Company_No = selected.obj.Company_No;
			    $( "#contactPersontxt" ).focus();
			 }
		  };
		 $scope.showExhibitorDetails = function() {
		 	
		 	if($scope.Exhibitor == undefined)
		 		$location.url("/exhibitors");
		 	if($scope.Exhibitor.Exhibitor_Id != undefined)
		 	{
		 		$scope.isUpdateExhibitor =true;
		 		exhibitorService.getExhibitorDetails($scope.Exhibitor.Exhibitor_Id).then(function(Response){
						if(Response.status == 200)
						{
			 	  			$scope.exhibitors=Response.data;
			 	  			eventService.getactiveEvents().then(function(Response){
								if(Response.status == 200)
									{
						 	  			$scope.activeEvents=Response.data;
						 	  			$scope.EvenSelected = $scope.activeEvents.filter(function (obj) {
								              if (obj.Event_Id === $scope.exhibitors.Event_Id) {
								              	$scope.Exhibitor.EvenSelected=obj.Name;
								                  return obj;
								              }
								          })[0];					 	  			
						 	  		}
							});

			 	  		}
			 	 });		 	
		 	}
		 	else if($scope.Exhibitor != undefined){
		 		$scope.isUpdateExhibitor =false;
		 		eventService.getactiveEvents().then(function(Response){
					if(Response.status == 200)
						{
			 	  			$scope.activeEvents=Response.data;
			 	  		}
				});
		 	}
		 				 	
		 }
		 //auto complete for event dropdown
		 function suggest_event(term) {
            
               var q = term.toLowerCase().trim();
                    return eventService.getEventbyText(q).then(function(Response){
                        
                            if(Response.status == 200)
                            {
                                $scope.eventfilter = Response.data;
                                var results =[];
                                for (var i = 0; i < $scope.eventfilter.length; i++) {
                                     var user = $scope.eventfilter[i];
                                     if (user.Name.toLowerCase().indexOf(q) !== -1)
                                       results.push({
                                         value: user.Name,
                                         // Pass the object as well. Can be any property name.
                                         obj: user,
                                         label: $sce.trustAsHtml(user.Name)
                                       });
                                   }
                                    $timeout(function() {  
                                        $(".ac-container").css("top","");
                                        $(".ac-container").css("left","");
                                    },200);
                                return results;
                            }
                    });  
            }           
          
         $scope.autocomplete_optionsForEvent = {
            suggest: suggest_event,
            on_select: function (selected) {               
                 if(selected!=null)
                 {
	                $scope.Exhibitor.Name = selected.obj.Name;
	                $scope.Exhibitor.Event_Id = selected.obj.Event_Id;   
               }
             }
          };		
		 $scope.showExhibitorDetails();
		
 })});