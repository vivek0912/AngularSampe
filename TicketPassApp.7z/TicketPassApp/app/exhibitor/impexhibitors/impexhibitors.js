 define(function(require){
	angular.module("app").controller("impexhibitorsCtrl",function($window,exhibitorService,apiService,$scope,$location,$state,$rootScope,$timeout,dataFactory){
		
		setTimeout(function() {                 
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
             
             $("#menu-toggle").click(function(e) {                          
            e.preventDefault();
            $(".content").toggleClass("toggled");
            });
             
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar").toggleClass("toggled");
            });

        }, 1500);
		    
		$scope.excelFile = null;
        $scope.FileName = '';
        $scope.exhibitorsforImport =[];
        $scope.Exhibitordatatable;
        $scope.isError = false;
        $scope.errorMessage ='';
        $scope.progressVisible = false;
        $scope.progress = 10;
        $scope.Exhibitorimportdatatable;        
        $scope.showProgress = function()
        {
        	$timeout(function() {  
					if($scope.progress != 100)
					{
						$scope.progress += 10;
						$scope.showProgress();
					}
					else
						$scope.progress = 100;
					$scope.$apply();					
	  		  },200);
        }
		$scope.saveExhibitor = function()
		 {	
			dataFactory.setexhibitor({});	
		 	if($scope.exhibitorsforImport.length > 0)
		 	{ 
			 	exhibitorService.addMultiple($scope.exhibitorsforImport).then(function(ResponseMedia){			 		
			 			if(ResponseMedia.status === 200)
			 			{
			 					$location.url("/exhibitors");
			 					$scope.$apply();
			 			}
			 			else
			 			{
			 					$scope.errorMessage = ResponseMedia.err_msg;
			 					$scope.isError = true;
			 					$scope.$apply();
			 					$timeout(function() {  
			 						$scope.errorMessage = '';
			 						$scope.isError = false;
			 						$scope.$apply();
						  		  },3000);

			 			}
		 			});		
	 		}
	 		else
	 		{
	 			$scope.errorMessage="Please upload file";
	 			$scope.isError = true;
	 			$timeout(function() {  
			 						$scope.errorMessage = '';
			 						$scope.isError = false;
			 						$scope.$apply();
						  		  },3000);
	 			//$location.url("/exhibitors");
	 		}     	
		 }	

		 $scope.gotoExhibitor	= function(){
		 	$location.url("/exhibitors");
		 }
		 $scope.$watch('excelFile', function () {
		 	
		 	if($scope.excelFile != null)
		 	{
		 		
		 		$scope.progressVisible = true;
			 	$scope.progress = 10;	
			 	$scope.showProgress();	 
			 	//exhibitorService.uploadExcel($scope.dataURItoBlob($scope.excelFile)).then(function(ResponseMedia){
			 	exhibitorService.uploadExcel($scope.excelFile).then(function(ResponseMedia){
			 						 		
		 			if(ResponseMedia.status === 200)
		 			{
		 					$scope.exhibitorsforImport = ResponseMedia.data;
		 					$scope.progress =100;
		 					$scope.Exhibitorimportdatatable.destroy();
		 					$timeout(function() {  
							  	$scope.Exhibitorimportdatatable =$('#exhibitorImportTable').DataTable( {	
											    "paging":   true,				      
										        "info":     true,
										         "searching": false,
										         "pageLength":10,
										         "lengthMenu": [[10, 20, 30], [10, 20, 30]]
										         	  
											} );
							  		  },0);
		 					$scope.$apply();
		 			}
		 			else
		 			{
		 				   $scope.errorMessage = ResponseMedia.err_msg;		 					
		 					$scope.isError = true;
		 					$scope.progress = 100; 
		 					$scope.progressVisible = false;
		 					$scope.excelFile = null;
        					$scope.FileName = '';
		 					$scope.$apply();
		 					$timeout(function() {  
		 						$scope.errorMessage = '';
		 						$scope.isError = false;
		 						$scope.$apply();
					  		  },4000);

		 			}
	 			});
			 }
		 });	

		 $scope.excleFileChanged=function(evt, type) {
		  	var file=evt.currentTarget.files[0];
		  	var reader = new FileReader();
		  	reader.onload = function (evt) {
		           $scope.$apply(function($scope){	             
		             $scope.excelFile=file;   	              
		           });
		           
		         };
		          reader.readAsDataURL(file);
		  }

		 $scope.uploadFiles=function(files) {
		  	var reader = new FileReader();
		  	reader.onload = function (evt) {
		           $scope.$apply(function($scope){	             
		             $scope.excelFile=files[0];   	              
		           });
		           
		         };
		          reader.readAsDataURL(files[0]);
		  }

		  $scope.dataURItoBlob=function(dataURI) {
			    // convert base64/URLEncoded data component to raw binary data held in a string
			    var byteString;
			    if (dataURI.split(',')[0].indexOf('base64') >= 0)
			        byteString = atob(dataURI.split(',')[1]);
			    else
			        byteString = unescape(dataURI.split(',')[1]);

			    // separate out the mime component
			    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

			    // write the bytes of the string to a typed array
			    var ia = new Uint8Array(byteString.length);
			    for (var i = 0; i < byteString.length; i++) {
			        ia[i] = byteString.charCodeAt(i);
			    }

			    return new Blob([ia], {type:mimeString});
			};

			$timeout(function() {  
					  	$scope.Exhibitorimportdatatable =	 $('#exhibitorImportTable').DataTable( {	
									    "paging":   true,				      
								        "info":     true,
								         "searching": false,
								         "pageLength":10,
								         "lengthMenu": [[10, 20, 30], [10, 20, 30]]
								         	  
									} );
					  		  },200);
 })});