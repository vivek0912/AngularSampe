define(
	function(require)
	{
	angular.module("app").controller("homeCtrl",function($scope,apiService,userService)
		{	
			function redirect(){
				var onSuccess=function(response)
			{"ok"===response.status&&response.path&&(window.location.href=response.path)};

			//return apiService.ajaxPost("account/redirect",{},onSuccess);
			}
			function initialize()
			{redirect()}
			initialize()
		});
	}

	);