define(function(require){
angular.module("app").controller("reportCtrl",function($window,reportService,apiService,$scope,$location,$state,$rootScope,$timeout,dataFactory,$sce,$filter){

     var scope = $scope;
     $scope.events =[];
     $scope.localoverseasvisitortypes=[];
     $scope.selection=[];
     $scope.eventcount='0';
     $scope.countries=[];
     $scope.regionwise=[];
     $scope.countrywise=[];
     $scope.graphdata=[];
     $scope.percentagedata=[];
     $scope.countrydata=[];
     $scope.datetimedata=[];
     $scope.regionDatatable;
     $scope.countryDatatable;
     $scope.timeDatattable;
     $scope.RegionSum;
     $scope.PreRegisteredVisitorSum;
     $scope.OnSiteVisitorSum;
     $scope.TotalVisitorSum;
     $scope.PercentageSum;
     $scope.regiondata={};
     $scope.reportdata={};
     $scope.timereportdata={};
     $scope.posreportdata={};
     $scope.staffreportdata={};
     $scope.eventperiod=[];
     $scope.regionExcelData=[];
     $scope.TimeExcelDate=[];
     $scope.countryExcelData=[];
     $scope.VisitorExcelDate=[];
     $scope.visitordataTable;
     $scope.SurveyDataTable;
     $scope.posgenerationdataTable;
     $scope.posefficiencydataTable;
     $scope.staffefficiencydataTable;
     $scope.staffgenerationdataTable;
     $scope.activetab="";
     $scope.type="";
     $scope.countrycodes='';
     $scope.selectedvisitortype='';
     $scope.eventIds = [];
     $scope.TotalPreRegisteredVisitor=0;
     $scope.TotalOnSiteVisitor=0;
     $scope.TotalVisitors=0;
     $scope.TotalPercentage=0;
     $scope.countriespercentage=[];
     $scope.graphcountries=[];
     $scope.createddate=[];
     $scope.Time=[];
     $scope.Morning=[];
     $scope.localonsite=[];
     $scope.overseasonsite=[];
     $scope.localpreregistered=[];
     $scope.overseaspreregistered=[];
     $scope.SurveyAnswer=[];
     $scope.SurveyLocalCount=[];
     $scope.SurveyOverseasCount=[];
     $scope.EventLength = 0;
     $scope.staffExcelData=[];
     $scope.staffEfficExcelData=[];
     $scope.passGenerationExcelData=[];
     $scope.posEfficExcelData=[];
     $scope.SelectUploadData = "Export DATA";
     $scope.EL;
     //$scope.loading=false;
     $scope.passrebinddata;
     $scope.ReportEvent="";
     $scope.EventPeriodText="";
      $scope.ReportTime={};

       $scope.options = {legend: {display: true,position:"bottom"}};
      localStorage.removeItem("allvisitor"); 
     localStorage.removeItem("alluser") 
     localStorage.removeItem("allexhibitor");
     localStorage.removeItem("eventtype"); 
setTimeout(function() {  

$('[data-toggle=collapse]').click(function(){
            // toggle icon
  $(this).find("i").toggleClass("fa-angle-down");
 });
             
 $("#menu-toggle").click(function(e) {                          
  e.preventDefault();
   $(".content").toggleClass("toggled");
  });
             
 $("#menu-toggle").click(function(e) {
  e.preventDefault();
  $("#sidebar").toggleClass("toggled");
 }); 
  }, 1500);

setTimeout(function() { 
$(".systm-setting a").click(function(e) {
 $(".reportsmenu").addClass("collapsed");
 $(".reports ul").removeClass("in");
 $(".reports .Toggleonload i").removeClass("fa-angle-down"); 
 $(".reports .Toggleonload i").addClass("fa-angle-right"); 
 });

$(".reports a").click(function(e) {
 $(".systm-setting a.first-menu").addClass("collapsed");
 $(".systm-setting ul").removeClass("in");
 $(".systm-setting .Toggleonload i").removeClass("fa-angle-down");
 $(".systm-setting .Toggleonload i").addClass("fa-angle-right"); 
 });

$(".Toggleonload").prev().removeClass("collapsed");
$(".reportsmenu") .toggleClass("collapsed");
$(".reports .submenu").addClass("in");
$(".reports .Toggleonload i").addClass("fa-angle-down"); 

  
}, 200); 

 
 setTimeout(function() {  
 $('.submenu a[href="#countries"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#countries"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#time"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#time"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#pos"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#pos"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#pos"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#pos"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#staff"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#staff"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#survey"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#survey"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#visitors"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#visitors"]').parent('li').addClass('active');
 });
 
 //$('.nav-tabs  a[href="#countries"]').tab('show');

}, 3000);


  $scope.activetab = $(".nav-tabs li.active a").attr("title");  

   $scope.pager = true;    
  if($scope.activetab == "countries"){ 
         $timeout(function() {  
                $scope.countryDataTable = $('#countryTable').DataTable({   
                "paging":   false,              
                "info":     false,
                 "searching": false,
                   "pageLength":10,
                "lengthMenu": [[10, 20, 30], [10, 20, 30]]
                  });
               $('#countryTable').wrap('<div class="responsive-datatable" />');
           },200);   

        $timeout(function() {  
         
               $scope.regionDataTable = $('#regionTable').DataTable({   
               "paging":   false,              
               "info":     false,
               "searching": false,
                 "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],            
         });
         $('#regionTable').wrap('<div class="responsive-datatable" />');
         },2000);  
     }
  



       if($scope.activetab == "pos"){        
         $timeout(function() {  
               $scope.posgenerationdataTable = $('#posgenerationtable').DataTable({   
               "paging":   true,              
               "info":     true,
               "searching": false,
                "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],               
         });
         $('#posgenerationtable').wrap('<div class="responsive-datatable" />');
         },200); 

        $timeout(function() {  
               $scope.posefficiencydataTable = $('#posefficiencyTable').DataTable({   
               "paging":   true,              
               "info":     true,
               "searching": false,
                 "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],           
         });
         $('#posefficiencyTable').wrap('<div class="responsive-datatable" />');
         },500);   
       }

       if($scope.activetab == "staff"){
        $timeout(function() {  
               $scope.staffDataTable = $('#staffgenerationtable').DataTable({   
               "paging":   true,              
               "info":     true,
               "searching": false,
               "pageLength":10,
                "lengthMenu": [[10, 20, 30], [10, 20, 30]],  
                        
         });
                
         $('#staffgenerationtable').wrap('<div class="responsive-datatable" />');
         },200);   

         $timeout(function() {  
               $scope.staffEfficiencydataTable = $('#staffefficiencytable').DataTable({   
               "paging":   true,              
               "info":     true,
               "searching": false,
               "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],  
                        
         });
                   
         $('#staffefficiencytable').wrap('<div class="responsive-datatable" />');
         },200);   


       }


       if($scope.activetab == "visitors"){ 
        /*$timeout(function() {  
               $scope.visitordataTable = $('#visitorTable1').DataTable({   
               "paging":   true,              
               "info":     false,
               "searching": false               
         });
         $('#visitorTable1').wrap('<div class="responsive-datatable" />');
         },200);*/        
       }
 
      $scope.visitorerror =true;
       /* Bind Countires and Visitor type */
      reportService.getEvents().then(function(data){
        $scope.events=data.data;          
      })

      reportService.getCountries().then(function(data){   
         
        $scope.countries=data.data;          
       })


       /* button click */
       $scope.DisplayReport=function(){ 
        
       
        //alert($scope.visitortype);
        if($scope.visitortype==undefined || $scope.visitortype=="" || $scope.visitortype=="Select Visitor Type"){
        $scope.visitorerror =false;        
         $(".visitortypediv .form-control").addClass("has-errorclass");
        return false;
        }

        if($scope.eventIds.length>0){    
         $('.chosen-choices').removeClass('has-error');    
        /* Country Tab */
        if($scope.activetab == "countries"){        
        $scope.pager = true;
        $scope.loading=true;
        $scope.countrycodes=$scope.countrycodes.replace(/^\s+|\s+$/g, '');
        if($scope.countrycodes[$scope.countrycodes.length-1]==","){
        $scope.countrycodes= $scope.countrycodes.substring(0,$scope.countrycodes.length-1);
        }

            
         reportService.getEventPeriodReportData($scope.eventIds.join(",")).then(function(response){        
         $scope.eventperiod=response.data;
        
         $scope.StartDate = $scope.eventperiod[0].StartDate;
         $scope.EndDate =$scope.eventperiod[0].EndDate;
         $scope.regiondata.eventids=$scope.eventIds.join(",");
         $scope.regiondata.startdate = $scope.StartDate;
         $scope.regiondata.enddate = $scope.EndDate; 
         $scope.regiondata.visitortype = $scope.selectedvisitortype;     
         $scope.regiondata.ExcludeCountries = $scope.countrycodes; 
         reportService.getRegionWiseReportDate($scope.regiondata).then(function(response){ 
         
            if(response.status==200){
               $scope.regionwise=response.data;
               $scope.graphdata=response.data;

               if($scope.regionwise.length> 0){


               angular.forEach($scope.regionwise, function(value){
              $scope.TotalPreRegisteredVisitor =$scope.TotalPreRegisteredVisitor + value.PreRegisteredVisitor;
              $scope.TotalOnSiteVisitor =$scope.TotalOnSiteVisitor + value.OnSiteVisitor;
              $scope.TotalVisitors=$scope.TotalVisitors + value.TotalVisitor;
              $scope.TotalPercentage=$scope.TotalPercentage + value.Percentage;
              })

              
               //$scope.RegionSum=$scope.regionwise.length;
               $scope.PreRegisteredVisitorSum =$scope.TotalPreRegisteredVisitor;
               $scope.OnSiteVisitorSum=$scope.TotalOnSiteVisitor;
               $scope.TotalVisitorSum=$scope.TotalVisitors;
               $scope.PercentageSum= $scope.TotalPercentage;

                 $scope.TotalPreRegisteredVisitor=0;
                 $scope.TotalOnSiteVisitor=0;
                 $scope.TotalVisitors=0;
                 $scope.TotalPercentage=0;
               
          
           $scope.regionDataTable.destroy();
            $timeout(function() {  
                  $scope.regionDataTable = $('#regionTable').DataTable({   
                 "paging":   false,              
               "info":     false,
               "searching": false,
                 "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]]              
           });
           $('#regionTable').wrap('<div class="responsive-datatable" />');
           },200); 



            $timeout(function() {  
                 angular.forEach($scope.graphdata, function(value){
                $scope.countriespercentage.push(value.Percentage);
                $scope.graphcountries.push(value.Region);
            });
              
             
                $scope.countrydata = $scope.countriespercentage;
                $scope.countrylabels = $scope.graphcountries;
               
                },1000);
                 //$scope.loading=false;
                $scope.countriespercentage=[];
                $scope.graphcountries=[];
                   
          }          //alert('data');
          else{
               $scope.RegionSum="";
               $scope.PreRegisteredVisitorSum="";
               $scope.OnSiteVisitorSum="";
               $scope.TotalVisitorSum="";
               $scope.PercentageSum="";
               $scope.countrydata=[];
               $scope.countrylabels=[];
          }
        }
         
          
        
        //   if($scope.regionDataTable!=undefined){

        //   if($scope.regionDataTable!=null){
        //     $scope.regionDataTable.destroy();  
        //   }
        // }
          
      });
         

             reportService.getCountryWiseReportDate($scope.regiondata).then(function(response){
               if(response.status==200){
               /*$scope.graphdata=response.data;*/
               $scope.countrywise=response.data;
              
              if($scope.countrywise.length>0){

               
               if($scope.countryDataTable!=null){
                $scope.countryDataTable.destroy();  
                }
               

               $timeout(function() {  
               $scope.countryDataTable = $('#countryTable').DataTable({   
                "paging":   false,              
                "info":     false,
                 "searching": false,
                 "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]], 
                  });
               $('#countryTable').wrap('<div class="responsive-datatable" />');     
              },200);   
              /*$scope.graphdata= $scope.countrywise; */
              $timeout(function(){$scope.loading=false},500);

                }
                
              }
               
            });    
          
        })
           
      }



      /* Time Report */

      else if($scope.activetab == "time"|| $scope.activetab=="By Hour" || $scope.activetab=="By Morning/Afternoon"){
      $scope.pager = true;
      $scope.loading=true;
       reportService.getEventPeriodReportData($scope.eventIds.join(",")).then(function(response){ 
         $scope.eventperiod=response.data;
         $scope.StartDate = $scope.eventperiod[0].StartDate;
         $scope.EndDate =$scope.eventperiod[0].EndDate;
         $scope.timereportdata.eventids=$scope.eventIds.join(",");
         $scope.timereportdata.startdate = $scope.StartDate;
         $scope.timereportdata.enddate = $scope.EndDate; 
         $scope.timereportdata.visitortype = $scope.selectedvisitortype; 
         if($scope.activetab=="By Hour"){
          $scope.timehide=false;
            $scope.timereportdata.Session='byhour';
         }
         else if($scope.activetab=="By Morning/Afternoon"){
           $scope.timehide=false;
            $scope.timereportdata.Session='bymorning';
         }
         else {
           $scope.timehide=true;
          $scope.timereportdata.Session='';
         }
           
         reportService.getTimeReportData($scope.timereportdata).then(function(data){

          if(data.status==200){
             $scope.datetimedata=data.data;

             if($scope.datetimedata.length>0){
               if($scope.timeDataTable!=null){
                 $scope.timeDataTable.destroy();
                     }

           $timeout(function() {  
                $scope.timeDataTable = $('#TimeReportTable').DataTable({   
               "paging":   true,              
               "info":     false,
               "searching": false,
                "pageLength":10,
                "lengthMenu": [[10, 20, 30], [10, 20, 30]]             
         });
         $('#TimeReportTable').wrap('<div class="responsive-datatable" />');
         },200);        
 


          angular.forEach($scope.datetimedata, function(value){

               
                 if($scope.activetab=="By Hour"){
                 $scope.Time.push(value.TimeSession);
               }
                else if($scope.activetab=="By Morning/Afternoon"){
                 $scope.Morning.push(value.TimeSession);
                 }
               else{
                 $scope.createddate.push(value.CreatedDate);
               }
                $scope.localonsite.push(value.OnSiteLocalVisitor); 
                $scope.overseasonsite.push(value.OnSiteOverseasVisitor);
                $scope.localpreregistered.push(value.PreregisteredLocalVisitor);
                $scope.overseaspreregistered.push(value.PreregisteredOverseasVisitor);
            })
           

         
               if($scope.activetab=="By Hour"){
               $scope.timelabels=  $scope.Time;
         }
         else if($scope.activetab=="By Morning/Afternoon"){
          
             $scope.timelabels= $scope.Morning;  
         }
         else {
          $scope.timelabels= $scope.createddate;
         }
    
            
          
       
            
              //$scope.data= $scope.localonsite;
             // $scope.data =  $scope.overseasonsite;
             // $scope.data=$scope.localpreregistered;
             //$scope.data=$scope.overseaspreregistered;
             $scope.timeseries=['Local OnSite', 'Overseas OnSite','Local Preregistered', 'Overseas Preregistered'];

              $scope.timedata = [
                              $scope.localonsite,
                              $scope.overseasonsite,
                              $scope.localpreregistered,
                               $scope.overseaspreregistered
                            ];

                              $scope.createddate=[];
                              $scope.Time=[];
                              $scope.Morning=[];
                              $scope.localonsite=[];
                              $scope.overseasonsite=[];
                              $scope.localpreregistered=[];
                              $scope.overseaspreregistered=[];
                             
     
              $timeout(function(){$scope.loading=false},500);
         }
       }
           
         })            
             
        })

      }

      /* 3rd tab ---- POS */
      else if($scope.activetab == "pos"){
         $scope.pager = true;
         $scope.loading=true;
         reportService.getEventPeriodReportData($scope.eventIds.join(",")).then(function(response){       
         $scope.eventperiod=response.data;
         $scope.StartDate = $scope.eventperiod[0].StartDate;
         $scope.EndDate =$scope.eventperiod[0].EndDate;
         $scope.posreportdata.eventids=$scope.eventIds.join(","); 
         $scope.posreportdata.visitortype = $scope.type;  
         $scope.posreportdata.startdate = $scope.StartDate;
         $scope.posreportdata.enddate = $scope.EndDate; 

       
        

        reportService.getPassReportData($scope.posreportdata).then(function(data){   
        if(data.status==200){
                 
        $scope.passreportdata=data.data; 
        if($scope.passreportdata.length>0) {
      
       
        
        if($scope.posgenerationdataTable!=null){ // && $scope.posgenerationdataTable!=undefined && $scope.posgenerationdataTable!=""){
             $scope.posgenerationdataTable.destroy();  
            }
       
         $timeout(function() {  
              $scope.posgenerationdataTable= $('#posgenerationtable').DataTable({  
                    "paging":   true,             
                      "info":     false,
                       "searching": false,
                        "pageLength":10,
                       "lengthMenu": [[10, 20, 30], [10, 20, 30]],                      
                       
                } );
               $('#posgenerationtable').wrap('<div class="responsive-datatable" />');
                },200);   
                $timeout(function(){$scope.loading=false},2000);
                } 
                }    
         })

       
        reportService.getPOSReportData($scope.posreportdata).then(function(data){     
        if(data.status==200){
                
        $scope.posefficiencydata=data.data;  
        if($scope.posefficiencydata.length>0){
          if($scope.posefficiencydataTable!=null){ // && $scope.posgenerationdataTable!=undefined && $scope.posgenerationdataTable!=""){
             $scope.posefficiencydataTable.destroy();  
            }

         $timeout(function() {    
              $scope.posefficiencydataTable= $('#posefficiencyTable').DataTable({  
                    "paging":   true,             
                      "info":     false,
                       "searching": false,                      
                       "pageLength":10,
                       "lengthMenu": [[10, 20, 30], [10, 20, 30]],                     
                       
                } );
               $('#posefficiencyTable').wrap('<div class="responsive-datatable" />');
                },200);        

             //$timeout(function(){$scope.loading=false},500);
           }
           }
           }) 
          
        })
         
        } 


        //4th Tab
        else if($scope.activetab == "staff"){
         $scope.pager = true;
         $scope.loading=true;
         reportService.getEventPeriodReportData($scope.eventIds.join(",")).then(function(response){  
         $scope.eventperiod=response.data;
         $scope.StartDate = $scope.eventperiod[0].StartDate;
         $scope.EndDate =$scope.eventperiod[0].EndDate;

         $scope.staffreportdata.eventids=$scope.eventIds.join(","); 
         $scope.staffreportdata.visitortype = $scope.type;  
         $scope.staffreportdata.startdate = $scope.StartDate;
         $scope.staffreportdata.enddate = $scope.EndDate; 
         

         reportService.getStaffPassReportData($scope.staffreportdata).then(function(data){
         if(data.status==200){
         
         $scope.staffgeneratedreportdata=data.data; 

          if($scope.staffgeneratedreportdata.length>0){
 
         if($scope.staffDataTable!=null){
           $scope.staffDataTable.destroy();  
         } 
       
         $timeout(function() {  
              $scope.staffDataTable= $('#staffgenerationtable').DataTable({  
                    "paging":   true,             
                      "info":     false,
                       "searching": false,
                       "pageLength":10,
                   "lengthMenu": [[10, 20, 30], [10, 20, 30]],                    
                       
                } );
                
              $('#staffgenerationtable').wrap('<div class="responsive-datatable" />');
                },200);  
         $timeout(function(){$scope.loading=false},2000);
       }
            }      
         })
         
        reportService.getStaffPOSReportData($scope.staffreportdata).then(function(data){  
          if(data.status==200){

        $scope.staffefficiencydata=data.data; 
       
     if($scope.staffEfficiencydataTable!=null){
           $scope.staffEfficiencydataTable.destroy();  
         } 

         $timeout(function() {  
              $scope.staffEfficiencydataTable= $('#staffefficiencytable').DataTable({  
                    "paging":   true,             
                      "info":     false,
                       "searching": false,
                       "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],                      
                       
                } );
                 
                $('#staffefficiencytable').wrap('<div class="responsive-datatable" />');
                },200);
          //$scope.loading=false;
          //$timeout(function(){$scope.loading=false},1000);
        }
         })
             
         })
         
        }

        //5th Tab 
        else if($scope.activetab == "survey"){        
         $scope.pager = true;
        $scope.loading=true;

         reportService.getEventPeriodReportData($scope.eventIds.join(",")).then(function(response){  
         $scope.eventperiod=response.data;
         $scope.StartDate = $scope.eventperiod[0].StartDate;
         $scope.EndDate =$scope.eventperiod[0].EndDate;
         $scope.reportdata.eventids=$scope.eventIds.join(","); 
         $scope.reportdata.visitortype = $scope.selectedvisitortype;  
         $scope.reportdata.startdate = $scope.StartDate;
         $scope.reportdata.enddate = $scope.EndDate; 
         //******************************************************************************************
         //Testing purpose added this function to check for chart data
         //******************************************************************************************
        
        //Test Data For Chart Testing
        $scope.testlabels = ['2013-01-01', '2013-01-02'];
        $scope.testseries = ['Project A'];
        $scope.testdata = [52, 53];

      //init
      $scope.charts = [];
    
      //******************************************************************************************
      //Getting SurveyData
         reportService.getSurveyData($scope.reportdata).then(function(data){ 
        $scope.Surveys=data.data;
         $scope.i=0;
         $scope.Surveyss=[];

         $scope.data=[];
         $scope.text;

         var results=[];
         var answer=[];
         var localcount=[];
         var overseascount=[];
         var percentage=[];
         $scope.j=0;

        $scope.Baroptions = [
         {
            size: {
               height: 200,
               width: 400
            }
         }
       ];
        //$scope.myArray = [];
        //$scope.myArray =  JSON.parse(data.data);

        //$scope.filtereds = [];
        //$scope.prev_items = null;
         // angular.forEach($scope.Surveys, function(value){
         //        $scope.countriespercentage.push(value.Percentage);
         //        $scope.graphcountries.push(value.Region);
         //    })
          
         //var res = alasql('SELECT Answer, PreRegisteredVisitor, OnSiteVisitor FROM ? GROUP BY category ORDER BY bytes DESC',[Surveys]);

         //$scope.groupsss=res;
         angular.forEach($scope.Surveys, function(value){
          //debugger;
                //$scope.SurveyAnswer.push(value.Answer);
                //$scope.SurveyLocalCount.push(value.PreRegisteredVisitor); 
                //$scope.SurveyOverseasCount.push(value.OnSiteVisitor);

                $scope.SurveyAnswer.push(value.Answers[0].Answer);
                $scope.SurveyLocalCount.push(value.Answers[0].PreRegisteredVisitor); 
                $scope.SurveyOverseasCount.push(value.Answers[0].OnSiteVisitor);
                var mquestion=value.Question;
                for(i=0;i<=value.Answers.length-1;i++)
                {
                  //$scope.SurveyAnswer.push(value.Answers[i].Answer);
                  //$scope.SurveyLocalCount.push(value.Answers[i].PreRegisteredVisitor); 
                  //$scope.SurveyOverseasCount.push(value.Answers[i].OnSiteVisitor);

                   answer.push(value.Answers[i].Answer);
                   localcount.push(value.Answers[i].PreRegisteredVisitor); 
                   overseascount.push(value.Answers[i].OnSiteVisitor);
                   percentage.push(value.Answers[i].Percentage);
                }

                $scope.SurveyBarTimeseries=['Local Count', 'Overseas Count','Local Preregistered', 'Overseas Preregistered'];
                //debugger;

                   results[$scope.j] = {
                        question:mquestion,
                        data:  percentage,
                        dataBar:[localcount,overseascount],
                        labelss:[answer],
                        labels:answer,
                        labelBar:answer
                  };
                  $scope.j++;
                
                answer=[];
                localcount=[];
                overseascount=[];
                percentage=[];

            });
            $scope.data=results;
     


         //$scope.surveypiedata=[$scope.SurveyLocalCount,$scope.SurveyOverseasCount];
         $scope.surveypiedata=[$scope.SurveyOverseasCount];
         $scope.surveypielabels= $scope.SurveyAnswer;


         $scope.surveydata=[$scope.SurveyLocalCount,$scope.SurveyOverseasCount];
         $scope.surveylabels= $scope.SurveyAnswer;
         

         if($scope.SurveyDataTable!=null){
           $scope.SurveyDataTable.destroy();  
         } 
         $timeout(function(){$scope.loading=false},500);
         //$scope.loading=false;
        /*$scope.eventIds= [];*/
         $timeout(function() {  
              $scope.SurveyDataTable= $('#SurveyTable').DataTable( {  
                    "paging":   false,             
                      "info":     false,
                       "searching": false,
                       "pageLength":5                      
                       
                } );
              },200);        
         })
         
          
         });
          
         //Getting SurveyData Ends       
        }


        // Visitor Tab

        else if($scope.activetab == "visitors"){ 

         $scope.pager=false;  
         $scope.loading=true;            
         reportService.getEventPeriodReportData($scope.eventIds.join(",")).then(function(response){ 
         $scope.eventperiod=response.data;
         $scope.StartDate = $scope.eventperiod[0].StartDate;
         $scope.EndDate =$scope.eventperiod[0].EndDate;
         $scope.reportdata.eventids=$scope.eventIds.join(","); 
         $scope.reportdata.visitortype = $scope.type;  
         $scope.reportdata.startdate = $scope.StartDate;
         $scope.reportdata.enddate = $scope.EndDate; 
         reportService.getVisitorsData($scope.reportdata).then(function(data){
         $scope.visitors=data.data;  

          if($scope.visitors.length == 0){
              $scope.nodata=false;   
              }
              else{
                $scope.nodata=true;  
              }

          $scope.currentPage = 1;
          $scope.totalItems = $scope.visitors.length;
          $scope.entryLimit = 10; // items per page
          $scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
          $scope.maxSize = 10; //Number of pager buttons to show
          $scope.pager = false;
         /*$scope.eventIds= [];*/
            /*if($scope.visitordataTable!=null){
                $scope.visitordataTable.destroy();  
                }*/
         /*$timeout(function() {  
              $scope.visitordataTable= $('#visitorTable').DataTable( {  
                    "paging":   true,             
                      "info":     false,
                       "searching": false,
                       "pageLength":10                      
                       
                } );
              },200);  */
         })
          $timeout(function(){$scope.loading=false},500);
         })   
        
       }


        }
        else
        {   
           
          $('.chosen-choices').addClass('has-error');
        }

       }

  
        $scope.SelectedVisitorType=function(){
        var Type=$scope.visitortype;
        $scope.type = $scope.visitortype;
        
        if(Type=='Local Visitors'){
            $scope.selectedvisitortype='2';
             $scope.visitorerror =true;
               $(".visitortypediv .form-control").removeClass("has-errorclass");
        }
        else if(Type=='Overseas Visitors'){
          $scope.selectedvisitortype='3'
           $scope.visitorerror =true;
             $(".visitortypediv .form-control").removeClass("has-errorclass");
        }
        else if(Type=="Local and Overseas Visitors")
        {
            $scope.selectedvisitortype='2,3';
            $scope.visitorerror =true;
              $(".visitortypediv .form-control").removeClass("has-errorclass");
        }
        else
        {
           $scope.visitorerror =false;
             $(".visitortypediv .form-control").addClass("has-errorclass");
        }

     
       // if($scope.selectedvisitortype.length >0) {
       // $scope.visitorerror =true;
       // }
       // else{
       //    $scope.visitorerror =false;
       // }
       }




       $scope.ReportTab=function(){

         $timeout(function() {  
               $scope.countryDataTable = $('#countryTable').DataTable({   
                "paging":   false,              
                "info":     false,
                 "searching": false,
                   "pageLength":10,
                "lengthMenu": [[10, 20, 30], [10, 20, 30]]
                  });
               $('#countryTable').wrap('<div class="responsive-datatable" />');
           },200);   

        $timeout(function() {  
         
               $scope.regionDataTable = $('#regionTable').DataTable({   
               "paging":   false,              
               "info":     false,
               "searching": false,
                 "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],            
         });
         $('#regionTable').wrap('<div class="responsive-datatable" />');
         },2000);  

          $timeout(function() {  
               $scope.timeDataTable = $('#TimeReportTable').DataTable({   
               "paging":   false,              
               "info":     false,
               "searching": false               
         });
           
         $('#TimeReportTable').wrap('<div class="responsive-datatable" />');
         },200);

        //$scope.countryDataTable.destroy();
        //$scope.regionDataTable.destroy();
        $scope.countriespercentage=[];
        $scope.graphcountries=[]; 
        //$scope.timeDatattable.destroy();
        $scope.createddate=[];
        $scope.Time=[];
        $scope.Morning=[];
        $scope.localonsite=[];
        $scope.overseasonsite=[];
        $scope.localpreregistered=[];
        $scope.overseaspreregistered=[];


       }


 $scope.DateTimeReport=function(){
   $scope.SelectUploadData = "Export DATA";
  if($scope.eventIds.length > 0){
    $scope.activetab="time";
  $scope.timereportdata.Session='';
  $scope.DisplayReport();
}
 }
  $scope.MorningTimeReport=function(){
     $scope.SelectUploadData = "Export DATA";
    if($scope.eventIds.length > 0){
    $scope.activetab="By Morning/Afternoon";
    $scope.timereportdata.Session='bymorning';
    $scope.DisplayReport();
  }
  }
  $scope.HourTimeReport=function(){
     $scope.SelectUploadData = "Export DATA";
    if($scope.eventIds.length > 0){
    $scope.activetab=="By Hour";
     $scope.timereportdata.Session='byhour';
    $scope.DisplayReport();
  }
  }

    $scope.SelectedPeriodReport=function(){
        var TimePeriod=$scope.TimePeriod;
        if(TimePeriod=='By Morning/Afternoon'){
            $scope.timereportdata.Session='bymorning';
            $scope.DisplayReport();
        }
        else if(TimePeriod=='By Hour'){
         $scope.timereportdata.Session='byhour';
           $scope.DisplayReport();
        }
       
       }


       $scope.UploadReport = function(){       
            if($scope.activetab == "countries"){
              /*alert($scope.SelectUploadData);*/
              
                  if($scope.SelectUploadData=="Excel"){
                    if($scope.regionwise.length>0){
                     
                     angular.forEach($scope.regionwise, function(value){
                      $scope.regionExcelData.push({Region:value.Region,PreRegisteredVisitor:value.PreRegisteredVisitor,
                        OnSiteVisitor:value.OnSiteVisitor,TotalVisitor:value.TotalVisitor,Percentage:value.Percentage         
                      });         
                      })
                    
                     $scope.regionExcelData.push({Region:$scope.RegionSum,PreRegisteredVisitor:$scope.PreRegisteredVisitorSum,OnSiteVisitor:$scope.OnSiteVisitorSum,
                     TotalVisitor:$scope.TotalVisitorSum,Percentage:$scope.PercentageSum
                     })
                   }
                     
                      if($scope.countrywise.length>0){

                      angular.forEach($scope.countrywise, function(value){
                          $scope.countryExcelData.push({CountryCode:value.CountryCode,CountryinChinese:value.Country_Name_Chinese==null?"":value.Country_Name_Chinese,PreRegisteredVisitor:value.PreRegisteredVisitor,
                        OnSiteVisitor:value.OnSiteVisitor,TotalVisitor:value.TotalVisitor,Percentage:value.Percentage
                      });            
                    });
                    }
                   
                      var opts = [{sheetid:'Country',header:true},{sheetid:'Region',header:false}];
                      if($scope.countryExcelData.length!=0 || $scope.regionExcelData.length!=0){
                        if($scope.countryExcelData.length>0 && $scope.regionExcelData.length>0){
                               var res = alasql('SELECT INTO XLSX("CountryReport.xlsx",?) FROM ?',
                             [opts,[$scope.countryExcelData,$scope.regionExcelData]]);
                        }
                        else if($scope.countryExcelData.length>0 && $scope.regionExcelData.length==0){
                             var res = alasql('SELECT INTO XLSX("CountryReport.xlsx",?) FROM ?',
                             [opts,[$scope.countryExcelData]]);
                        }
                        else if($scope.countryExcelData.length==0 && $scope.regionExcelData.length>=0){
                              var res = alasql('SELECT INTO XLSX("CountryReport.xlsx",?) FROM ?',
                             [opts,[$scope.regionExcelData]]);
                        }

                    }
                      $scope.countryExcelData=[];
                      $scope.regionExcelData=[];
                      $scope.SelectUploadData = "Export DATA";

                
                }
                else if($scope.SelectUploadData=="PDF"){ 
                      $scope.loading=true;
                      $scope.SelectUploadData = "Export DATA";
                      angular.forEach($scope.eventIds,function(value){           
                          angular.forEach($scope.events,function(events){
                                  if (events.Event_Id == value ) {
                                   $scope.ReportEvent+=events.Name+",";
                                 }
                              });
                      })        
                     $scope.ReportEvent+="="+$scope.visitortype;
                      var filterStartdate=$filter('date')($scope.StartDate, "dd-MMM-yyyy");
                      var filterEnddate=$filter('date')($scope.EndDate,"dd-MMM-yyyy");
                        $scope.EventPeriodText=filterStartdate+"~"+filterEnddate;
                     var base64ImageData=document.getElementById("countrypiechart").toDataURL("image/jpg");
                     var image = base64ImageData.replace('data:image/png;base64,', '');
                     var regions=$scope.regionwise;
                      if(regions==undefined)
                          regions=null;
                     var countries=$scope.countrywise;
                      if(countries==undefined)
                          countries=null;
         
                      reportService.exportCountryPdf(regions,countries,image,$scope.ReportEvent,$scope.EventPeriodText).then(function(response){
                            if(response.status==200)
                            {  
                                  var file = new Blob([], {type: 'application/pdf'});
                                  //saveData( "Countries.pdf" , "application/pdf", file);
                                  var fileName = "CountrysReports.pdf";
                                  var a = document.createElement("a");
                                  document.body.appendChild(a);
                                  a.style = "display: none";
                                        var file = new Blob([response.data], {type: 'application/pdf'});
                                        var fileURL = window.URL.createObjectURL(file);
                                        a.href = fileURL;
                                        a.download = fileName;
                                        a.click();  
                                        $scope.ReportEvent=""; 
                                        $scope.loading=false;                                       
                          }             
                      }) 
                
             
                }      
 
      }
      else if($scope.activetab == "time" || $scope.activetab == "By Date" || $scope.activetab=="By Hour" || $scope.activetab=="By Morning/Afternoon"){
          if($scope.datetimedata.length>0){
           if($scope.SelectUploadData=="Excel"){


             if($scope.activetab=="By Hour" || $scope.activetab=="By Morning/Afternoon"){

               angular.forEach($scope.datetimedata, function(value){
              $scope.TimeExcelDate.push({CreatedDate:value.CreatedDate,TimeSession:value.TimeSession,OnSiteLocalVisitor:value.OnSiteLocalVisitor,
                PreregisteredLocalVisitor:value.PreregisteredLocalVisitor,TotalLocalVisitor:value.TotalLocalVisitor,OnSiteOverseasVisitor:value.OnSiteOverseasVisitor,
               PreregisteredOverseasVisitor:value.PreregisteredOverseasVisitor,TotalOverseasVisitor:value.TotalOverseasVisitor,TotalVisitor:value.TotalVisitor,Percentage:value.TotalPercentage
              });         
              })

             }

             else{
             
              angular.forEach($scope.datetimedata, function(value){
              $scope.TimeExcelDate.push({CreatedDate:value.CreatedDate,OnSiteLocalVisitor:value.OnSiteLocalVisitor,
                PreregisteredLocalVisitor:value.PreregisteredLocalVisitor,TotalLocalVisitor:value.TotalLocalVisitor,OnSiteOverseasVisitor:value.OnSiteOverseasVisitor,
               PreregisteredOverseasVisitor:value.PreregisteredOverseasVisitor,TotalOverseasVisitor:value.TotalOverseasVisitor,TotalVisitor:value.TotalVisitor,Percentage:value.TotalPercentage
              });         
              })

             }
 
             // angular.forEach($scope.datetimedata, function(value){
             //  $scope.TimeExcelDate.push({CreatedDate:value.CreatedDate,OnSiteLocalVisitor:value.OnSiteLocalVisitor,
             //    PreregisteredLocalVisitor:value.PreregisteredLocalVisitor,TotalLocalVisitor:value.TotalLocalVisitor,OnSiteOverseasVisitor:value.OnSiteOverseasVisitor,
             //   PreregisteredOverseasVisitor:value.PreregisteredOverseasVisitor,TotalOverseasVisitor:value.TotalOverseasVisitor,TotalVisitor:value.TotalVisitor,Percentage:value.TotalPercentage
             //  });         
             //  })

             var opts = [{sheetid:'TimeReport',header:true} ];
              var res = alasql('SELECT INTO XLSX("TimeReport.xlsx",?) FROM ?',
                     [opts,[$scope.TimeExcelDate]]);
              $scope.TimeExcelDate=[];               
              $scope.SelectUploadData = "Export DATA";

       //      reportService.excelExportTime($scope.datetimedata).then(function (data) {
       //    if(data.status == 200){
       //    var blob = new Blob([data.data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});          
       //    var objectUrl = URL.createObjectURL(blob);
       //    window.open(objectUrl);
       //    $scope.SelectUploadData = "Export DATA";
       //  }
       // }); 
      }
      else if($scope.SelectUploadData=="PDF"){
            $scope.loading=true;
            var activeTab=$scope.activetab;
            $scope.SelectUploadData = "Export DATA";
             angular.forEach($scope.eventIds,function(value){           
                angular.forEach($scope.events,function(events){
                        if (events.Event_Id == value ) {
                         $scope.ReportEvent+=events.Name+",";
                       }
                    });
            })        
           $scope.ReportEvent+="="+$scope.visitortype;
             var filterStartdate=$filter('date')($scope.StartDate, "dd-MMM-yyyy");
            var filterEnddate=$filter('date')($scope.EndDate,"dd-MMM-yyyy");
                  $scope.EventPeriodText=filterStartdate+"~"+filterEnddate;
           var base64ImageData=document.getElementById("pie").toDataURL("image/jpg");//getting image 
          var image = base64ImageData.replace('data:image/png;base64,', '');
          var timedata=$scope.datetimedata;//fetching time data
          var activetab=$scope.activetab;
           if($scope.activetab=="")
             $scope.activetab=null;
          reportService.exportTimeReportPdf(timedata,image,$scope.ReportEvent,activetab,$scope.EventPeriodText).then(function(response){
                  if(response.status==200)
                  {  
                        var file = new Blob([], {type: 'application/pdf'});
                         if(activeTab=="time")
                         {
                          activeTab="By Date";
                         }                         
                      
                        var fileName = "TimeReports"+activeTab.replace(/[\s]/g, '')+".pdf";
                        var a = document.createElement("a");
                        document.body.appendChild(a);
                        a.style = "display: none";
                              var file = new Blob([response.data], {type: 'application/pdf'});
                              var fileURL = window.URL.createObjectURL(file);
                              a.href = fileURL;
                              a.download = fileName;
                              a.click();  
                              $scope.ReportEvent=""; 
                              $scope.loading=false;                                       
                }             
            }) 
       

      }

      
    }   
      }
    else if($scope.activetab == "pos"){      
     // if($scope.passreportdata.length>0){
        if($scope.SelectUploadData=="Excel"){
            // reportService.excelExportPOS($scope.passreportdata).then(function (data) {
            //    if(data.status == 200){
            //      var blob = new Blob([data.data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});          
            //      saveFile("PassGenerationSummary", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", blob);
            //      var objectUrl = URL.createObjectURL(blob);
            //      window.open(objectUrl);
            //    }
            //  }); 
        

            if($scope.passreportdata!=undefined){
              $scope.filterdata=$filter('orderBy')($scope.passreportdata,"RegisterDate");
               angular.forEach($scope.filterdata,function(value){
               $scope.passGenerationExcelData.push({RegisterDate:value.RegisterDate,POSDeviceID:value.POSDeviceID==null?"":value.POSDeviceID,
                PassGenerated:value.PassGenerated,OnsiteVisitor:value.OnsiteVisitor,
                VisitorProfileUpdated:value.VisitorProfileUpdated,SurveyResponseUpdated:value.SurveyResponseUpdated});         
              })
             
                         
           
            }
              if($scope.posefficiencydata!=undefined){

               angular.forEach($scope.posefficiencydata, function(value){ 
                  $scope.posEfficExcelData.push({POSDeviceID:value.POSDeviceID==null?"":value.POSDeviceID,ChangePassOnSiteVisitor:value.ChangePass,
                UpdateVisitorProfile:value.UpdatedVisitorProfile,UpdateSurveyResponse:value.UpdatedSurveyResponse});            
            });
            }
             

              var opts = [{sheetid:'PassGenerateReport',header:true},{sheetid:'PosEfficiencyReport',header:false}];



               if($scope.passGenerationExcelData.length!=0 || $scope.posEfficExcelData.length!=0){
                if($scope.passGenerationExcelData.length>0 && $scope.posEfficExcelData.length>0){
                      var res = alasql('SELECT INTO XLSX("PosReports.xlsx",?) FROM ?',
                     [opts,[$scope.passGenerationExcelData,$scope.posEfficExcelData]]);
                }
                else if($scope.passGenerationExcelData.length>0 && $scope.posEfficExcelData.length==0){
                     var res = alasql('SELECT INTO XLSX("PosReports.xlsx",?) FROM ?',
                     [opts,[$scope.passGenerationExcelData]]);
                }
                else if($scope.passGenerationExcelData.length==0 && $scope.posEfficExcelData.length>=0){
                      var res = alasql('SELECT INTO XLSX("PosReports.xlsx",?) FROM ?',
                     [opts,[$scope.posEfficExcelData]]);
                }

            }

              $scope.passGenerationExcelData=[];
              $scope.posEfficExcelData=[];
              $scope.SelectUploadData = "Export DATA";


        }
        else if($scope.SelectUploadData=="PDF"){
                $scope.loading=true;
                $scope.SelectUploadData = "Export DATA";
                angular.forEach($scope.eventIds,function(value){
                      angular.forEach($scope.events,function(events){
                              if (events.Event_Id == value ) {
                               $scope.ReportEvent+=events.Name+",";
                             }
                          });
                });           
                $scope.ReportEvent+="="+$scope.visitortype;
                var filterStartdate=$filter('date')($scope.StartDate, "dd-MMM-yyyy");
                var filterEnddate=$filter('date')($scope.EndDate,"dd-MMM-yyyy");
                  $scope.EventPeriodText=filterStartdate+"~"+filterEnddate;
                var passgenerationdata=$filter('orderBy')($scope.passreportdata,"RegisterDate");
                 if(passgenerationdata==undefined)
                       passgenerationdata=null;  
                var posefficiencydata=$scope.posefficiencydata; 
                 if(posefficiencydata==undefined)
                       posefficiencydata=null;         
                reportService.exportPOSPdf(passgenerationdata,posefficiencydata,$scope.ReportEvent,$scope.EventPeriodText).then(function(response){
                    
                        if(response.status==200)
                        {  
                              var file = new Blob([], {type: 'application/pdf'});
                              var fileName = "POSReports.pdf";
                              var a = document.createElement("a");
                              document.body.appendChild(a);
                              a.style = "display: none";
                                    var file = new Blob([response.data], {type: 'application/pdf'});
                                    var fileURL = window.URL.createObjectURL(file);
                                    a.href = fileURL;
                                    a.download = fileName;
                                    a.click();  
                                    $scope.ReportEvent="";   
                                   $scope.loading=false;
                              
                      }             
                })

        }
    }
    else if($scope.activetab == "staff"){
        
            if($scope.SelectUploadData=="Excel"){
              if($scope.staffgeneratedreportdata!=undefined){
              $scope.stafffilterdata=$filter('orderBy')($scope.staffgeneratedreportdata,"RegisterDate");
              angular.forEach( $scope.stafffilterdata, function(value){
              $scope.staffExcelData.push({RegisterDate:value.RegisterDate,StaffName:value.StaffID,
                PassGenerated:value.PassGenerated,OnsiteVisitor:value.OnsiteVisitor,
                VisitorProfileUpdated:value.VisitorProfileUpdated,SurveyResponseUpdated:value.SurveyResponseUpdated});         
              })
            } 
             
            if($scope.staffefficiencydata!=undefined){
              angular.forEach($scope.staffefficiencydata, function(value){
                  $scope.staffEfficExcelData.push({StaffName:value.StaffID,ChangePassOnSiteVisitor:value.ChangePass,
                UpdateVisitorProfile:value.UpdateVisitorProfile,UpdateSurveyResponse:value.UpdateSurveyResponse});            
            });
            }
              var opts = [{sheetid:'PassGenerateReport',header:true},{sheetid:'StaffEfficiencyReport',header:false}];
              if($scope.staffExcelData.length!=0 || $scope.staffEfficExcelData.length!=0){
                if($scope.staffExcelData.length>0 && $scope.staffEfficExcelData.length>0){
                       var res = alasql('SELECT INTO XLSX("StaffReports.xlsx",?) FROM ?',
                     [opts,[$scope.staffExcelData,$scope.staffEfficExcelData]]);
                }
                else if($scope.staffExcelData.length>0 && $scope.staffEfficExcelData.length==0){
                     var res = alasql('SELECT INTO XLSX("StaffReports.xlsx",?) FROM ?',
                     [opts,[$scope.staffExcelData]]);
                }
                else if($scope.staffExcelData.length==0 && $scope.staffEfficExcelData.length>=0){
                      var res = alasql('SELECT INTO XLSX("StaffReports.xlsx",?) FROM ?',
                     [opts,[$scope.staffEfficExcelData]]);
                }

            } 
              $scope.staffExcelData=[];
              $scope.staffEfficExcelData=[];
              $scope.SelectUploadData = "Export DATA";

             
          }
          else if($scope.SelectUploadData=="PDF"){
                 $scope.loading=true;     
                $scope.SelectUploadData = "Export DATA";
                angular.forEach($scope.eventIds,function(value){
                      angular.forEach($scope.events,function(events){
                              if (events.Event_Id == value ) {
                               $scope.ReportEvent+=events.Name+",";
                             }
                          });
                });           
                $scope.ReportEvent+="="+$scope.visitortype;
                var filterStartdate=$filter('date')($scope.StartDate, "dd-MMM-yyyy");
                var filterEnddate=$filter('date')($scope.EndDate,"dd-MMM-yyyy");
                $scope.EventPeriodText=filterStartdate+"~"+filterEnddate;

                var staffgeneration=$filter('orderBy')($scope.staffgeneratedreportdata,"RegisterDate");
                if(staffgeneration==undefined)
                  staffgeneration=null;
                var staffefficiency=$scope.staffefficiencydata;
                if(staffefficiency===undefined) 
                   staffefficiency=null;       
                reportService.exportStaffPdf(staffgeneration,staffefficiency,$scope.ReportEvent,$scope.EventPeriodText).then(function(response){
                    
                        if(response.status==200)
                        {  
                              var file = new Blob([], {type: 'application/pdf'});
                              var fileName = "StaffReports.pdf";
                              var a = document.createElement("a");
                              document.body.appendChild(a);
                              a.style = "display: none";
                                    var file = new Blob([response.data], {type: 'application/pdf'});
                                    var fileURL = window.URL.createObjectURL(file);
                                    a.href = fileURL;
                                    a.download = fileName;
                                    a.click(); 
                                    $scope.ReportEvent="";
                                    $scope.loading=false;                                                          
                      }             
                })

        }
          
    }

    else if($scope.activetab == "survey"){
      //alert("Survey Export Click");
      
      if($scope.SelectUploadData=="Excel"){
            reportService.excelExportSurvey($scope.Surveys).then(function (data) {
                 var a = document.createElement("a");
                  document.body.appendChild(a);
                  a.style = "display: none";
                var fileName="SurveyReport.xlsx";
                if(data.status == 200){
                  var blob = new Blob([data.data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});  
                  var blob1 = new Blob([data.data], {type: "octet/stream"});      
                  var objectUrl = URL.createObjectURL(blob1);

                  
                  saveData(data.data, fileName);
                   $scope.SelectUploadData = "Export DATA";
                   //a.href = objectUrl;
                   //a.download = fileName;
                   //a.click();
                  //window.URL.revokeObjectURL(objectUrl);
                  //window.open(objectUrl);
                  
                  //window.location.href=objectUrl;
                }
          }); 
      }
      else if($scope.SelectUploadData=="PDF"){
                $scope.loading=true;
                $scope.SelectUploadData = "Export DATA";
                angular.forEach($scope.eventIds,function(value){
                      angular.forEach($scope.events,function(events){
                              if (events.Event_Id == value ) {
                               $scope.ReportEvent+=events.Name+",";
                             }
                          });
                });           
                $scope.ReportEvent+="="+$scope.visitortype;
                 var filterStartdate=$filter('date')($scope.StartDate, "dd-MMM-yyyy");
                var filterEnddate=$filter('date')($scope.EndDate,"dd-MMM-yyyy");
                  $scope.EventPeriodText=filterStartdate+"~"+filterEnddate;
              var surveydata=$scope.Surveys;
             for(var i=0;i<surveydata.length;i++)
             {
                 var piechart=document.getElementById("surveypiechart"+i).toDataURL("image/jpg");//getting image 
                   piechart = piechart.replace('data:image/png;base64,', '');
                  var barchart=document.getElementById("surveybarchart"+i).toDataURL("image/jpg");//getting image 
                 barchart = barchart.replace('data:image/png;base64,', '');
                $scope.Surveys[i].PieImage=piechart
                $scope.Surveys[i].BarIamge=barchart
             }
             var data=$scope.Surveys;
                if(surveydata===undefined) 
                   surveydata=null;  

                reportService.exportSurveyReportPdf(data,$scope.ReportEvent,$scope.EventPeriodText).then(function(response){
                    
                        if(response.status==200)
                        {  
                              var file = new Blob([], {type: 'application/pdf'});
                              var fileName = "SurveyReports.pdf";
                              var a = document.createElement("a");
                              document.body.appendChild(a);
                              a.style = "display: none";
                                    var file = new Blob([response.data], {type: 'application/pdf'});
                                    var fileURL = window.URL.createObjectURL(file);
                                    a.href = fileURL;
                                    a.download = fileName;
                                    a.click(); 
                                    $scope.ReportEvent="";
                                    $scope.loading=false;                                                          
                      }             
                })

      }

    }
    else if($scope.activetab == "visitors"){
      if($scope.visitors.length>0){
       if($scope.SelectUploadData=="Excel"){

          angular.forEach($scope.visitors, function(value){
                      $scope.VisitorExcelDate.push({'Event Code':value.EventCode,'Visitor Name':value.VisitorName,'Visitor Type':value.VisitorType,
                        'Mobile Number':value.MobileNumber==null?"":value.MobileNumber,'Visitor Email':value.Email==null?"":value.Email,
                        'Job Title':value.Title==null?"":value.Title,'Position':value.Position==null?"":value.Position,
                        'Company Name':value.Company_Name,'Company Registration No':value.CompanyNo==null?"":value.CompanyNo,
                        'Website':value.Website==null?"":value.Website,'Company Email':value.Email==null?"":value.Email,
                        'Address':value.Address==null?"":value.Address,'Phone':value.Phone==null?"":value.Phone,'Phone Extension':value.PhoneExtension==null?"":value.PhoneExtension,
                        'Fax':value.Fax,'Country Name':value.Country,'TTS Registration No':value.Tts_Registration_No,
                        'Reporting ID':value.Reporting_Id==null?"":value.Reporting_Id,'Visitor UUID':value.Visitor_UUID==null?"":value.Visitor_UUID,
                         'Last Modify Date':value.LastModifyDate==null?"":value.LastModifyDate,
                       'Senior Visitor':value.IsExclude,'Create On':value.Create_On,'Create By':value.Create_by,'Update On':value.Update_On,'Update By':value.Update_by,
                       'Data Source':value.Source==null?"":value.Source

                      });         
                })

          var opts = [{sheetid:'VisitorReport',header:true} ];
              var res = alasql('SELECT INTO XLSX("VisitorReport.xlsx",?) FROM ?',
                     [opts,[$scope.VisitorExcelDate]]);
              $scope.VisitorExcelDate=[];               
              $scope.SelectUploadData = "Export DATA";

      //   reportService.excelExportVisitor($scope.visitors).then(function (data) {
      //   if(data.status == 200){
      //     var blob = new Blob([data.data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});          
      //     var objectUrl = URL.createObjectURL(blob);
      //     window.open(objectUrl);
      //     $scope.SelectUploadData = "Export DATA";
      //   }
      // }); 

      }
      else if($scope.SelectUploadData=="PDF"){
                    $scope.loading=true;
                    $scope.SelectUploadData = "Export DATA";
                      $scope.ReportTime.EventIds=$scope.eventIds.join(","); 
                      $scope.ReportTime.VisitorType=$scope.visitortype;
                      $scope.ReportTime.StartDate=$scope.StartDate;
                      $scope.ReportTime.EndDate=$scope.EndDate;    
                      reportService.exportVisitorPdf($scope.ReportTime).then(function(response){
                          
                              if(response.status==200)
                              {  
                                    var file = new Blob([], {type: 'application/pdf'});
                                    var fileName = "VisitorReports.pdf";
                                    var a = document.createElement("a");
                                    document.body.appendChild(a);
                                    a.style = "display: none";
                                          var file = new Blob([response.data], {type: 'application/pdf'});
                                          var fileURL = window.URL.createObjectURL(file);
                                          a.href = fileURL;
                                          a.download = fileName;
                                          a.click(); 
                                          $scope.ReportEvent=""; 
                                          $scope.loading=false;                                                      
                              }             
                      })

      }
    }    

    }


  }


   function saveFile (name, type, data) {
            if (data != null && navigator.msSaveBlob)
                return navigator.msSaveBlob(new Blob([data], { type: type }), name);
            var a = $("<a style='display: none;'/>");
            var url = window.URL.createObjectURL(new Blob([data], {type: type}));
            a.attr("href", url);
            a.attr("download", name);
            $("body".append(a));
            a[0].click();
            window.URL.revokeObjectURL(url);
            a.remove();
          }

var saveData = (function () {
    var a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none";
    return function (data, fileName) {
        var json = JSON.stringify(data), 
            blob = new Blob([data], {type: "octet/stream"}),
            url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = fileName;
        a.click();
        window.URL.revokeObjectURL(url);
    };
}());


 


setTimeout(function() { 
 
 $("#menu-toggle").click(function(e) {                          
  e.preventDefault();
   $(".content").toggleClass("toggled");
  });
             
  $("#menu-toggle").click(function(e) {
  e.preventDefault();
   $("#sidebar").toggleClass("toggled");
 }); 

  }, 1500); 

   
   setTimeout(function() { 
   var config = {
 

 }
},200); 



   setTimeout(function() { 
 
  var config = {
                '.chosen-select'           : {},
                '.chosen-select-deselect'  : {allow_single_deselect:true},
                '.chosen-select-no-single' : {disable_search_threshold:10},
                '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
                '.chosen-select-width'     : {width:"95%"}
              }
              for (var selector in config) {
                $(selector).chosen(config[selector]);
              }
  }, 1000);




setTimeout(function() {  
 $('.submenu a[href="#countries"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#countries"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#time"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#time"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#pos"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#pos"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#pos"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#pos"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#staff"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#staff"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#survey"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#survey"]').parent('li').addClass('active');
 });

 $('.submenu a[href="#visitors"]').click(function(){ 
 $('.nav-tabs li').removeClass("active"); 
 $('.nav-tabs li a[href="#visitors"]').parent('li').addClass('active');
 
 }); 

 

$('#ExcludeCountires').on('change', function(evt, params) { 
if(params.deselected!=undefined){
$scope.countrycodes= $scope.countrycodes.replace(params.deselected.split(':')[1]," ");
}
if(params.selected!=undefined){
$scope.countrycodes=$scope.countrycodes + ','+ params.selected.split(':')[1];
}

//$scope.DisplayReport();

});

$(function () {
$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
var target = $(e.target).attr("title")
 $scope.activetab = target;
 
 
 if($scope.activetab == "countries"){ 
   if($scope.countryDataTable!=null){ 
             $scope.countryDataTable.destroy();  
            }
         $timeout(function() {  
                $scope.countryDataTable = $('#countryTable').DataTable({   
                "paging":   false,              
                "info":     false,
                 "searching": false,
                   "pageLength":10,
                "lengthMenu": [[10, 20, 30], [10, 20, 30]]
                  });
               $('#countryTable').wrap('<div class="responsive-datatable" />');
           },200);   


           if($scope.regionDataTable!=null){ 
             $scope.regionDataTable.destroy();  
            }

        $timeout(function() {  
         
               $scope.regionDataTable = $('#regionTable').DataTable({   
               "paging":   false,              
               "info":     false,
               "searching": false,
                 "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],            
         });
         $('#regionTable').wrap('<div class="responsive-datatable" />');
         },2000);  
     }


 if($scope.activetab == "time"){  
 
   $('.sub-tabs li#bydate').addClass('active');
        $timeout(function() {  
         if( $scope.timeDataTable!=null)
               $scope.timeDataTable.destroy();
               $scope.timeDataTable = $('#TimeReportTable').DataTable({   
               "paging":   true,              
               "info":     false,
               "searching": false,
                "pageLength":10,
                "lengthMenu": [[10, 20, 30], [10, 20, 30]]
         });
         $('#TimeReportTable').wrap('<div class="responsive-datatable" />');
         },200);        
 }


     

  if($scope.activetab == "pos"){    
   if($scope.posgenerationdataTable!=null){ 
             $scope.posgenerationdataTable.destroy();  
            }

         $timeout(function() {  
               $scope.posgenerationdataTable = $('#posgenerationtable').DataTable({   
               "paging":   true,              
               "info":     true,
               "searching": false,
                  "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],               
         });
         $('#posgenerationtable').wrap('<div class="responsive-datatable" />');
         },200); 

          if($scope.posefficiencydataTable!=null){ 
             $scope.posefficiencydataTable.destroy();  
            }

        $timeout(function() {  
               $scope.posefficiencydataTable = $('#posefficiencyTable').DataTable({   
               "paging":   true,              
               "info":     true,
               "searching": false,
                 "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],           
         });
         $('#posefficiencyTable').wrap('<div class="responsive-datatable" />');
         },500);   
       }

        if($scope.activetab == "staff"){
        if($scope.staffDataTable!=null){ 
             $scope.staffDataTable.destroy();  
            }

        $timeout(function() {  
               $scope.staffDataTable = $('#staffgenerationtable').DataTable({   
               "paging":   true,              
               "info":     true,
               "searching": false,
               "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],  
                        
         });
                 
         $('#staffgenerationtable').wrap('<div class="responsive-datatable" />');
         },200);   

          if($scope.staffEfficiencydataTable!=null){ 
             $scope.staffEfficiencydataTable.destroy();  
            }

         $timeout(function() {  
               $scope.staffEfficiencydataTable = $('#staffefficiencytable').DataTable({   
               "paging":   true,              
               "info":     true,
               "searching": false,
               "pageLength":10,
                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],  
                        
         });
                
         $('#staffefficiencytable').wrap('<div class="responsive-datatable" />');
         },200);   


       }

       if($scope.activetab == "survey"){ 
          if($scope.Surveys!=null){ 
             $scope.Surveys.destroy();  
            }

         $timeout(function() {  
               $scope.SurveyI = $('#SurveyTable1').DataTable({   
               "paging":   true,              
               "info":     false,
               "searching": false,
                        
         });
         $('#SurveyTable1').wrap('<div class="responsive-datatable" />');
         },200);  

       }


       if($scope.activetab == "visitors"){  
        /*$timeout(function() {  
         if( $scope.visitordataTable!=null)
               $scope.visitordataTable.destroy();
               $scope.visitordataTable = $('#visitorTable1').DataTable({   
               "paging":   true,              
               "info":     false,
               "searching": false               
         });
         $('#visitorTable1').wrap('<div class="responsive-datatable" />');
         },200);  */     
 }
 
});
})
 
//$('.nav-tabs  a[href="#countries"]').tab('show');
 
$('#SelectedEvents').on('change', function(evt, params) { 
  if(params.deselected!=undefined){
     $scope.eventId = params.deselected.split(':')[1];
     $scope.index = $scope.eventIds.indexOf($scope.eventId);
     $scope.eventIds.splice($scope.index, 1);   
  }
  if(params.selected!=undefined){    
    $scope.eventId = params.selected.split(':')[1];
    $scope.eventIds.push($scope.eventId);   
  }
 
  $timeout(function() { 
  $scope.EventLength= $scope.eventIds.length;
  if($scope.EventLength == 1){
  $scope.EventLength = $scope.EventLength;
  }
  else
  {
    $scope.EventLength = $scope.EventLength;
  }
  
}, 500);

  if( $scope.eventIds.length > 0){
     $('.chosen-choices').removeClass('has-error');
     //displaying event dates
 /*reportService.getEventPeriodReportData($scope.eventIds.join(",")).then(function(response){        
         $scope.eventperiod=response.data;        
         $scope.StartDate = $scope.eventperiod[0].StartDate;
         $scope.EndDate = $scope.eventperiod[0].EndDate;

  });*/
  }
  else{
 $('.chosen-choices').addClass('has-error');
      $scope.StartDate = "";
       $scope.EndDate = "";
  }
}); 
 
}, 10);
 
$scope.DisplayTimeReport = function()
{

   
  $scope.activetab = "time";
  setTimeout(function() { 
    $scope.DisplayReport();

    }, 100);
}
setTimeout(function() { 
$('#multiple-label-example').on('change', function(evt, params) { 
  $scope.selected(); 
}); 
}, 10); 

  
 })}
  );
