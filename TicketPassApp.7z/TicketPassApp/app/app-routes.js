define(function(require){
	var app=require("app");
	app.run(["$state","$stateParams","$rootScope",
		function($state,$stateParams,$rootScope,$scope,$on){
			$rootScope.$state=$state,
			$rootScope.$stateParams=$stateParams,
			$rootScope.loading=!0,
			$rootScope.UserDetails = JSON.parse(window.localStorage.getItem("UserDetails")); 
			$rootScope.loginUser = $rootScope.UserDetails;
			$rootScope.$on("$stateChangeStart",function(event,toState,toParams,fromState,fromParams){					
					var redirect = toState.requireLogin;

					if(redirect != false && redirect != undefined)
					{
						var UserDetails = JSON.parse(window.localStorage.getItem("UserDetails")); 
						$rootScope.loginUser = UserDetails;
						if(!UserDetails){
							$state.go('user.login');
							event.preventDefault();
						}
					}
					$rootScope.loading=!0
				}),
	$rootScope.$on("$stateChangeSuccess",function(event,toState,toParams,fromState,fromParams){
		$rootScope.loading=!1
	})  

}]),
	app.config(["$stateProvider","$urlRouterProvider",function($stateProvider,$urlRouterProvider)
		{
			$urlRouterProvider.otherwise("/user/login"),
			$stateProvider
			.state("home",{
				url:"/",
				templateUrl:"app/home/home.tmpl.html",
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad)
				{
				 return $ocLazyLoad.load({files:["app-user-home"]})
				}]}})
			.state("user",{templateUrl:"./app/user/user.tmpl.html"})			
			.state("user.users",{
				url:"/users",
				templateUrl:"./app/user/users/users.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-users"]})}]}})			
			.state("user.login",{
				url:"/user/login",
				templateUrl:"./app/user/login/login.tmpl.html",
				requireLogin: false,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){
					return $ocLazyLoad.load({files:["app-user-login"]})}]}})
			.state("user.register",{
				url:"/user/register",
				templateUrl:"./app/user/register/register.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-user-register"]})}]}})
			.state("user.profilepage",{
				url:"/user/profilepage",
				templateUrl:"./app/user/profilepage/profilepage.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-user-profilepage"]})}]}})	
			.state("user.forgetpassword",{
				url:"/user/forgetpassword",
				templateUrl:"./app/user/forgetpassword/forgetpassword.tmpl.html",
				requireLogin: false,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-user-forgetpassword"]})}]}})	
			.state("user.resetpassword",{
				url:"/user/resetpassword",
				templateUrl:"./app/user/forgetpassword/resetpassword.tmpl.html",
				requireLogin: false,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-user-resetpassword"]})}]}})
			.state("user.adduser",{
				url:"/user/adduser",
				templateUrl:"./app/user/adduser/adduser.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-user-adduser"]})}]}})
			.state("user.userprofile",{
				url:"/user/userprofile",
				templateUrl:"./app/user/userprofile/userprofile.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-user-userprofile"]})}]}})
			.state("user.myprofile",{
				url:"/user/myprofile",
				templateUrl:"./app/user/myprofile/myprofile.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-user-myprofile"]})}]}})		
			.state("event",{templateUrl:"./app/event/event.tmpl.html"})	
			.state("event.events",{
				url:"/events",
				templateUrl:"./app/event/events/events.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-events"]})}]}})	
			.state("event.eventdetails",{
				url:"/event/eventdetails",
				templateUrl:"./app/event/eventdetails/eventdetails.tmpl.html",
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-eventdetails"]})}]}})
			.state("user.dashboard",{
				url:"/dashboard",
				templateUrl:"./app/dashboard/dashboard.tmpl.html",
				requireLogin:true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-dashboard"]})}]}})	
			.state("visitor",{templateUrl:"./app/visitor/visitor.tmpl.html"})
			.state("visitor.visitors",{
				url:"/visitors",
				templateUrl:"./app/visitor/visitors/visitors.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-visitors"]})}]}})
			.state("survey",{templateUrl:"./app/survey/survey.tmpl.html"})
			.state("survey.surveys",{
				url:"/surveys",
				templateUrl:"./app/survey/surveys/surveys.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-surveys"]})}]}})
			.state("survey.addsurvey",{
				url:"/survey/addsurvey",
				templateUrl:"./app/survey/addsurvey/addsurvey.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-addsurvey"]})}]}})
			.state("survey.surveydetail",{
				url:"/survey/surveydetail",
				templateUrl:"./app/survey/surveydetail/surveydetail.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-surveydetail"]})}]}})
			.state("survey.surveypreview",{
				url:"/survey/surveypreview",
				templateUrl:"./app/survey/surveypreview/surveypreview.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-surveypreview"]})}]}})
			.state("survey.surveyresponse",{
				url:"/survey/surveyresponse",
				templateUrl:"./app/survey/surveyresponse/surveyresponse.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-surveyresponse"]})}]}})
			.state("survey.responsedetail",{
				url:"/survey/responsedetail",
				templateUrl:"./app/survey/responsedetail/responsedetail.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-responsedetail"]})}]}})
			.state("survey.visitorprofile",{
				url:"/survey/visitorprofile",
				templateUrl:"./app/survey/visitorprofile/visitorprofile.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-visitorprofile"]})}]}})
			.state("exhibitor",{templateUrl:"./app/exhibitor/exhibitor.tmpl.html"})
			.state("exhibitor.exhibitors",{
				url:"/exhibitors",
				templateUrl:"./app/exhibitor/exhibitors/exhibitors.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-exhibitors"]})}]}})
			.state("exhibitor.addexhibitors",{
				url:"/exhibitors/addexhibitors",
				templateUrl:"./app/exhibitor/addexhibitors/addexhibitors.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-addexhibitors"]})}]}})
			.state("exhibitor.impexhibitors",{
				url:"/exhibitors/impexhibitors",
				templateUrl:"./app/exhibitor/impexhibitors/impexhibitors.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-impexhibitors"]})}]}})
			.state("pos",{templateUrl:"./app/pos/pos.tmpl.html"})
			.state("pos.poss",{
				url:"/poss",
				templateUrl:"./app/pos/poss/poss.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-poss"]})}]}})
			.state("siteservers",{templateUrl:"./app/siteserver/siteserver.tmpl.html"})
			.state("siteservers.siteservers",{
				url:"/siteservers",
				templateUrl:"./app/siteserver/siteservers/siteservers.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-siteservers"]})}]}})
			.state("siteservers.siteserverprofile",{
				url:"/siteserverprofile",
				templateUrl:"./app/siteserver/siteserverprofile/siteserverprofile.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-siteserverprofile"]})}]}})
			.state("company",{templateUrl:"./app/company/company.tmpl.html"})
			.state("company.companies",{
				url:"/companies",
				templateUrl:"./app/company/companies/companies.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-companies"]})}]}})
			.state("company.addcompany",{
				url:"/company/addcompany",
				templateUrl:"./app/company/addcompany/addcompany.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-addcompany"]})}]}})
			.state("company.companyprofile",{
				url:"/company/companyprofile",
				templateUrl:"./app/company/companyprofile/companyprofile.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){
					return $ocLazyLoad.load({files:["app-companyprofile"]})}]}})			
			.state("country",{templateUrl:"./app/country/country.tmpl.html"})
			.state("country.countries",{
				url:"/countries",
				templateUrl:"./app/country/countries/countries.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-countries"]})}]}})
			.state("location",{templateUrl:"./app/locations/locations.tmpl.html"})
			.state("location.locations",{
				url:"/locations",
				templateUrl:"./app/locations/location/location.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-locations"]})}]}})
.state("reports",{templateUrl:"./app/reports/reports.tmpl.html"})
			.state("reports.reports",{
				url:"/reports",
				templateUrl:"./app/reports/reports/reports.tmpl.html",
				requireLogin:true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-reports"]})}]}})
			.state("integration",{templateUrl:"./app/integration/integration.tmpl.html"})
			.state("integration.integrations",{
				url:"/integrations",
				templateUrl:"./app/integration/integrations/integrations.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){return $ocLazyLoad.load({files:["app-integration"]})}]}})													
			.state("user.verify",{
				url:"/user/verify/:key",
				templateUrl:"./app/user/verify/verify.tmpl.html",
				requireLogin: true,
				resolve:{loginMdl:["$ocLazyLoad",
				function($ocLazyLoad){
					return $ocLazyLoad.load({files:["app-user-verify"]})}]}})	
		}])		
});