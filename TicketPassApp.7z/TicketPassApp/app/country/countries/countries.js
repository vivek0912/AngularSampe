	define(function(require){
	angular.module("app").controller("countryCtrl",function($window,$uibModal,countryService,apiService,$scope,$location,$timeout,$state,$rootScope,$translate,$timeout){
			$scope.sucessmessage=true;
			$scope.SuccessMessage='';
			$scope.hideSuccess=true;
			$scope.count=0;
         	$scope.selection=[];
 			$scope.newCountry = {};
 			$scope.action='';
          	$scope.errorMessage ='';
          	$scope.showeerror = false;
          	$scope.selectedItem = 'no item selected';	
          	$scope.countrydatatable;
            $scope.regions = [];
         	localStorage.removeItem("allvisitor"); 
 			localStorage.removeItem("alluser") 
 			localStorage.removeItem("allexhibitor");
 			localStorage.removeItem("eventtype"); 
			setTimeout(function() {                  
		           $('[data-toggle=collapse]').click(function(){
		            // toggle icon
		            $(this).find("i").toggleClass("fa-angle-down");
		            });
		             
		             $("#menu-toggle").click(function(e) {                          
		            e.preventDefault();
		            $(".content").toggleClass("toggled");
		            });
		             
		            $("#menu-toggle").click(function(e) {
		            e.preventDefault();
		            $("#sidebar").toggleClass("toggled");
		            });

		    }, 1500);
 

		    $timeout(function() {  
				 $(".systm-setting .submenu").addClass("in");
				 $(".systm-setting .Toggleonload").removeClass("collapsed");
				  $(".systm-setting .Toggleonload i").addClass("fa-angle-down");   
					
					},200);
		    $scope.closeCountry=function(){
	  		$scope.myDialog.close();
	  		}
	  		
	  		var noitemfounds = "";
	  		var searchtext = "";

        	 $translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
           	});

        	 $translate(['searchcountry']).then(function (translations) {
                      searchtext = translations.searchcountry;                      
         });
        	 
		  	//get countries
		 	countryService.getCountries().then(function(response){		 		  
		  			$scope.countries=response.data.data;
		  			$timeout(function() {  
                     $scope.countrydatatable =	$('#countryTable').DataTable( { 
                     		"paging":   true,             
                          	"info":     true,
                          	"searching": true,
                          	"pageLength":10,
                          	"lengthMenu": [[10, 20, 30], [10, 20, 30]],
                           	language: {
                           		emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                    	searchPlaceholder: searchtext,
                                    	search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                    	infoFiltered: " "
                                     }       
                    	});

                     $('#countryTable').wrap('<div class="responsive-datatable" />');
               		},200);
		  	})
         
		  countryService.GetRegions().then(function(response){			       		  
				$scope.regions=response.data;
				  			
		  })

		    $scope.closeCountry = function	(){
	  			$scope.myDialog.close();
	  		}

	  		$scope.Reloadcountry = function(){
	  			$scope.countrydatatable.destroy();
	  			$timeout(function() {  
                     $scope.countrydatatable =	$('#countryTable').DataTable( { 
                     		"paging":   true,             
                          	"info":     true,
                          	"searching": true,
                          	"pageLength":10,
                          	"lengthMenu": [[10, 20, 30], [10, 20, 30]],
                           	language: {
                           		emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                    	searchPlaceholder: searchtext,
                                    	search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                     }       
                    	});
                      $('#countryTable').wrap('<div class="responsive-datatable" />');
               		},0);
	  		}
		  	$scope.addCountry=function(){
		  		
 					if($scope.title=='Add Country')
 					{ 						
 						$scope.selectedRegion = $scope.regions.filter(function(e) { return e.Name === $scope.newCountry.Name; });
 						$scope.newCountry.RegionId = $scope.selectedRegion[0].RegionId;
 						$scope.hideSuccess=false;
		   		 		$scope.newCountry.Create_On = new Date();
		  		 		$scope.newCountry.Update_On = new Date();
				 		countryService.saveCountry($scope.newCountry).then(function (response) {
				 			
							if(response.status==200){
								$scope.SuccessMessage=$scope.newCountry.Country_Name;
								$scope.myDialog.close();
								$scope.action='is created'
								$timeout(function () { $scope.hideSuccess = true; }, 2000); 
							}  
								countryService.getCountries().then(function(response){		 		  
		  							$scope.countries=response.data.data;
		  							$scope.Reloadcountry();		  									  							
		  						});
	             		});
					}
					else
					{
						$scope.selectedRegion = $scope.regions.filter(function(e) { return e.Name === $scope.newCountry.Name; });
 						$scope.newCountry.RegionId = $scope.selectedRegion[0].RegionId;
						$scope.hideSuccess=false;
						$scope.newCountry.Create_On = new Date();
		  		 		$scope.newCountry.Update_On = new Date();
						countryService.updateCountry($scope.newCountry).success(function (response){
						
							if(response.data==1){
								
								$scope.SuccessMessage=$scope.newCountry.Country_Name;
								 $scope.myDialog.close();
								$scope.action='is updated'
								$timeout(function () { $scope.hideSuccess = true; }, 2000);
							}
	                		countryService.getCountries().then(function(response){
	                     	$scope.countries=response.data.data;
	                     	    $scope.Reloadcountry();
	                  		});
	                });
					}
			}

	        //delete country
				$scope.deleteCountry=function(country){
					$scope.action="is deleted";
              		var countryName=country.Country_Name;
				 	countryService.deleteCountryData(country.Country_Code).success(function (response){
				 		
				 		if(response.status ==200)
                  		{
						 		$scope.hideSuccess=false;
		                    	$scope.SuccessMessage=countryName;
		                    	$timeout(function () { $scope.hideSuccess = true; }, 2000);
			                	countryService.getCountries().then(function(response){
			                     	$scope.countries=response.data.data;
			                     	$scope.Reloadcountry();            
			                  	});
	                	}
	                	else{
	                		$scope.showErrorMessage(countryName);
	                	}
	                });
		 	}
          		//multiple deletion..
          		$scope.deleteMultipleCompany = function()
            	{
                 var noOfCountry='';
              		//selecting all checked row
          			var list = $scope.countries.filter(function (obj) {
			              if (obj.checked !== undefined && obj.checked === true) {
			                  return obj;
			              }
			         });
                 if(list.length!==0)
                 {
                         if(list.length==1){
                              $scope.action="is deleted";
                             noOfCountry=list.length+" "+"country";
                        }
                    if(list.length>1){
                                $scope.action="are deleted";
                             noOfCountry=list.length+" "+"countries";
                        }        
                        countryService.deleteMultipleCountry(list).then(function (response){

                              if(response.data.status === 200)
                              {
                                    if(response.data.data==true){
                                      $scope.selectedItem = 'no'; 
                                     
                                    }
                                    $scope.hideSuccess=false;
                                    $scope.SuccessMessage=noOfCountry;
                                    
                                   $timeout(function () { $scope.hideSuccess = true; }, 2000);
                  					countryService.getCountries().then(function(response){
                 			 			$scope.countries=response.data.data;   
                 			 			$scope.Reloadcountry();         
                 		 			});      
                              }
                              else
                              {
                                  $scope.showErrorMessage(response.data.err_msg);
                              }
                          });
                    }
                    else
                    {
                        $scope.selectedItem = 'no item selected';
                    }
            }
             $scope.countryCheckedchanged = function()
            {
               var list = $scope.countries.filter(function (obj) {
			              if (obj.checked !== undefined && obj.checked === true) {
			                  return obj;
			              }
			         });
                  if(list.length == 1)
                      $scope.selectedItem = list.length;
                  else if (list.length > 1)
                      $scope.selectedItem = list.length;
                  else 
                      $scope.selectedItem = 'no item selected';
                    
            }
            $scope.showErrorMessage = function(message)
              {
                  $scope.errorMessage = message;
                  $scope.hideSuccess=true;
                  $scope.showeerror = true;
                   $timeout(function () { $scope.errorMessage = ''; $scope.showeerror = false;}, 2000);
              }
		 	//bind country data with modal for edit 
		 		$scope.bindCountryData=function(countryCode){
		 			if(countryCode!==undefined)
		 			{
		 				$scope.disabled=true;
		 					countryService.getCountry(countryCode).then(function (response){
                     			$scope.newCountry=response.data.data;  
                     			$scope.title = "Edit Country";
                     			$scope.selectedRegion = $scope.regions.filter(function(e) { return e.RegionId === $scope.newCountry.RegionId; });
 						        $scope.newCountry.Name = $scope.selectedRegion[0].Name;
                     			$scope.buttonValue='Update'
	             	 			$scope.myDialog = $uibModal.open({
	             	 				scope: $scope,
	             	 				animation: $scope.animationsEnabled,
	                				templateUrl: 'app/country/countries/country.popup.html'		                	 	
	             				});
	             	 		$scope.myDialog.result.then( function( modalResult ){
        						$scope.newCountry = {};
					        	$scope.$apply();}).finally(function(){
        						$scopemyDialog.$destroy(); 
    							});
	             			});

					}
					else
					{
							$scope.disabled=false;                    		 
                     		$scope.title = "Add Country";
                     		$scope.buttonValue='Add'
	             	 		$scope.myDialog = $uibModal.open({
	             	 			scope: $scope,
	             	 			animation: $scope.animationsEnabled,
	                			templateUrl: 'app/country/countries/country.popup.html'		
	                				                
	                	 	
	             			});
	             	 		$scope.myDialog.result.then( function( modalResult ){
	             	 			
        						$scope.newCountry = {};
					        	$scope.$apply();}).finally(function(){
        						$scopemyDialog.$destroy(); 
        					
    							});
	             	 		
	             	
					}
					
		 }
		

	 })});