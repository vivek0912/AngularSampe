require.config(
	{waitSeconds:300,urlArgs:"v="+(new Date).getTime(),
	paths:{
		angular:"../bower_components/angular/angular.min",
		"angular-ui-router":"../bower_components/angular-ui-router/release/angular-ui-router.min",
		'angular-async-loader':	"../bower_components/angular-async-loader/angular-async-loader.min",
		"angular-ui-bootstrap":	"../bower_components/angular-bootstrap/ui-bootstrap-tpls.min",			
		"angular-animate":"../bower_components/angular-animate/angular-animate.min",
		"angular-route":"../bower_components/angular-route/angular-route.min",
		"angular-translate":"../bower_components/angular-translate/angular-translate.min",
		"angular-translate-loader-static-files":"../bower_components/angular-translate-loader-static-files/angular-translate-loader-static-files.min",
		"angular-sanitize":"../bower_components/angular-sanitize/angular-sanitize.min",
		"ocLazyLoad-require":"../bower_components/oclazyload/dist/ocLazyLoad.require.min",
		"angular-utils-pagination":"../static/scripts/plugins/angular-utils-pagination/dirPagination",
		"angular-validation":"../bower_components/angular-validation/dist/angular-validation.min",
		"angular-validation-rule":"../bower_components/angular-validation/dist/angular-validation-rule.min",
		"angular-chart":"../bower_components/angular-chart.js/dist/angular-chart.min",
		"chart":"../bower_components/chart.js/dist/Chart.min",	
		"angular-massautocomplete":"../bower_components/angular-mass-autocomplete/massautocomplete.min",
		jquery:"../bower_components/jquery/dist/jquery.min",
		chosenmin:"../static/scripts/chosen.jquery.min",
		prism:"../static/scripts/prism",
		jqueryUI:"../bower_components/jquery-ui/jquery-ui.min",
		bootstrapui:"../bower_components/angular-bootstrap/ui-bootstrap.min",
		bootstrap:"../bower_components/bootstrap/dist/js/bootstrap.min",
		"bootstrap-ui-tpls":"../static/scripts/ui-bootstrap-tpls-0.10.0",
        datatables:"../bower_components/datatables.net/js/jquery.dataTables.min",        
        "angular-datatables":"../bower_components/angular-datatables/dist/angular-datatables",
        "angular-datatables-bootstrap":"../bower_components/angular-datatables/dist/plugins/bootstrap/angular-datatables.bootstrap.min",
        "angular-datatables-colreorder":"../bower_components/angular-datatables/dist/plugins/colreorder/angular-datatables.colreorder.min",
        "angular-datatables-columnfilter":"../bower_components/angular-datatables/dist/plugins/columnfilter/angular-datatables.columnfilter.min",
        "angular-datatables-light-columnfilter":"../bower_components/angular-datatables/dist/plugins/light-columnfilter/angular-datatables.light-columnfilter.min",
        "angular-datatables-colvis":"../bower_components/angular-datatables/dist/plugins/colvis/angular-datatables.colvis.min",
        "angular-datatables-fixedcolumns":"../bower_components/angular-datatables/dist/plugins/fixedcolumns/angular-datatables.fixedcolumns.min",
        "angular-datatables-fixedheader":"../bower_components/angular-datatables/dist/plugins/fixedheader/angular-datatables.fixedheader.min",
        "angular-datatables-scroller":"../bower_components/angular-datatables/dist/plugins/scroller/angular-datatables.scroller.min",
        "angular-datatables-tabletools":"../bower_components/angular-datatables/dist/plugins/tabletools/angular-datatables.tabletools.min",
        "angular-datatables-buttons":"../bower_components/angular-datatables/dist/plugins/buttons/angular-datatables.buttons.min",
        "angular-datatables-select":"../bower_components/angular-datatables/dist/plugins/select/angular-datatables.select.min",
        "angular-elastic":"../bower_components/angular-elastic/elastic",
        "Sortable":"../bower_components/Sortable/Sortable.min",
        "angular-legacy-sortable":"../bower_components/angular-surveys/vendor/angular-legacy-sortable",
        "form-utils":"../bower_components/angular-surveys/dist/form-utils.min",
        "form-builder":"../bower_components/angular-surveys/dist/form-builder.min",
        "form-builder-bootstrap-tpls":"../bower_components/angular-surveys/dist/form-builder-bootstrap-tpls.min",
        "form-viewer":"../bower_components/angular-surveys/dist/form-viewer.min",
        "form-viewer-bootstrap-tpls":"../bower_components/angular-surveys/dist/form-viewer-bootstrap-tpls.min",
        FileUploader:"../bower_components/ng-file-upload/ng-file-upload.min",
        FileUploadershim:"../bower_components/ng-file-upload/ng-file-upload-shim.min",
        imagecrop:"../bower_components/ng-img-crop/compile/minified/ng-img-crop",
        Qr_Code:"../bower_components/angular-qrcode/qrcode",
        Qrcode_UTF8:"../bower_components/angular-qrcode/qrcode_UTF8",
        "angular-qrcode":"../bower_components/angular-qrcode/angular-qrcode",
        //multiselect:"../static/scripts/multiselect/bootstrap-multiselect",
         
		highcharts:"../static/scripts/plugins/highcharts/highcharts",
		"oi-select":"../static/scripts/plugins/oi.select/select-tpls.min",		
		moment:"../bower_components/moment/min/moment.min",
		"angular-moment":"../bower_components/angular-moment/angular-moment.min",
		daterangepicker:"../static/scripts/plugins/bootstrap-daterangepicker/daterangepicker.min",
		"angular-drag-to-reorder":"../static/scripts/plugins/angular-drag-to-reorder/angular-drag-to-reorder.min",
		"ng-tags-input":"../bower_components/ng-tags-input/ng-tags-input.min",
		sprintf:"../static/scripts/plugins/sprintf-js/sprintf.min",
		"angular-sprintf":"../static/scripts/plugins/sprintf-js/angular-sprintf.min",
		"ng-file-upload":"../static/scripts/plugins/ng-file-upload/ng-file-upload.min",
		"ng-file-upload-shim":"../static/scripts/plugins/ng-file-upload/ng-file-upload-shim.min",
		"ng-xeditable":"../bower_components/angular-xeditable/dist/js/xeditable.min",
		xls:"../static/scripts/plugins/js-xls/xls.min",
		xlsx:"../static/scripts/plugins/js-xlsx/xlsx.core.min",
		es6promise:"../static/scripts/plugins/es6-promise/promise.min",
		"angular-ui-tree":"../bower_components/angular-ui-tree/dist/angular-ui-tree.min",
		"file-saver":"../static/scripts/plugins/file-saver/FileSaver.min",
		"app-utils":"../app/common/app-utils",
		"app-directive":"../app/common/app-directive",
		"app-locationdirective":"../app/common/app-locationdirective",
		"app-api-service":"../app/common/app-api.svc",
		"app-store":"../app/common/app-store",
		userService:"../app/common/app-user.svc",
		posService:"../app/common/app-pos.svc",
		companyService:"../app/common/app-company.svc",
		countryService:"../app/common/app-country.svc",
		eventService:"../app/common/app-event.svc",
		authInterceptor:"../app/common/app-authInterceptor.svc",
		authService:"../app/common/app-authentication.svc",
		visitorService:"../app/common/app-visitor.svc",
		exhibitorService:"../app/common/app-exhibitor.svc",
		locationService:"../app/common/app-location.svc",
		siteServerService:"../app/common/app-siteserver.svc",
		integrationService:"../app/common/app-integration.svc",
		surveyService:"../app/common/app-survey.svc",
		dashboardService:"../app/common/app-dashboard.svc",
	    reportService:"../app/common/app-report.svc",
		session:"../app/common/app-session.svc",
		"app-config":"../app/common/app-config",
		"app-list":"../app/common/app-list.svc",
		"app-user-home":"../app/home/homeCtrl",
		"app-company-quotation-acceptance":"../app/company/quotation/quotationReview.all",
		"app-user-ssologin":"../app/user/sso_login/ssologin",		
		"app-users":"../app/user/users/users",
		"app-user-login":"../app/user/login/login",
		"app-user-register":"../app/user/register/register",
		"app-user-forgetpassword":"../app/user/forgetpassword/forgetpassword",
		"app-user-resetpassword":"../app/user/forgetpassword/resetpassword",
		"app-user-adduser":"../app/user/adduser/adduser",
		"app-user-myprofile":"../app/user/myprofile/myprofile",
		"app-user-userprofile":"../app/user/userprofile/userprofile",			 
		"app-events":"../app/event/events/events",
		"app-eventdetails":"../app/event/eventdetails/eventdetails",		
		"app-visitors":"../app/visitor/visitors/visitors",
		"app-surveys":"../app/survey/surveys/surveys",
		"app-dashboard":"../app/dashboard/dashboard", 	
		"app-addsurvey":"../app/survey/addsurvey/addsurvey",
		"app-surveydetail":"../app/survey/surveydetail/surveydetail",
		"app-surveypreview":"../app/survey/surveypreview/surveypreview",
		"app-surveyresponse":"../app/survey/surveyresponse/surveyresponse",
		"app-responsedetail":"../app/survey/responsedetail/responsedetail",
		"app-visitorprofile":"../app/survey/visitorprofile/visitorprofile",				  			
		"app-exhibitors":"../app/exhibitor/exhibitors/exhibitors",
		"app-addexhibitors":"../app/exhibitor/addexhibitors/addexhibitors",	
		"app-impexhibitors":"../app/exhibitor/impexhibitors/impexhibitors",		
		"app-poss":"../app/pos/poss/poss",	
		"app-siteservers":"../app/siteserver/siteservers/siteservers",
		//"app-survey":"../app/survey/surveys/survey",
		"app-siteserverprofile":"../app/siteserver/siteserverprofile/siteserverprofile",
		"app-companies":"../app/company/companies/companies",
		"app-addcompany":"../app/company/addcompany/addcompany",
		"app-companyprofile":"../app/company/companyprofile/companyprofile",		
		"app-countries":"../app/country/countries/countries",
		"app-locations":"../app/locations/location/location",	
		"app-integration":"../app/integration/integrations/integrations",
		"app-reports":"../app/reports/reports/reports",						
		"app-user-profilepage":"../app/user/profilepage/profilepage",		
		"app-user-verify":"../app/user/verify/verify"},
	waitSeconds: 200,
	shim:{
	angular:{exports:"angular"},
	session:{deps:["app-config","app-api-service"]},	 
	"angular-ui-router":{deps:["angular"]},
	"angular-ui-bootstrap":{deps:["angular","bootstrap","bootstrapui"]},
	"bootstrap-ui-tpls":{deps:["angular","bootstrap"]},
	"ng-dialog":{deps:["angular"]},
	"angular-animate":{deps:["angular"]},
	"angular-busy":{deps:["angular"]},
	"angular-route":{deps:["angular"]},
	"angular-translate":{deps:["angular"]},
	"angular-translate-loader-static-files":{deps:["angular","angular-translate"]},
	"angular-sanitize":{deps:["angular"]},
	"ocLazyLoad-require":{deps:["angular"]},
	"angular-utils-pagination":{deps:["angular"]},
	"date-range":{deps:["angular","angular-ui-bootstrap"]},
	"angular-validation":{deps:["angular","angular-validation-rule"]},
	"angular-validation-rule":{deps:["angular"]},
	"angular-chart":{deps:["angular","chart"]},
	"chart":{deps:["angular"]},
	"angular-massautocomplete":{deps:["angular"]},
	"angular-elastic":{deps:["angular"]},
	"Sortable":{deps:["angular"]},
	"angular-legacy-sortable":{deps:["angular","Sortable"]},
	"form-utils":{deps:["angular","angular-ui-bootstrap" ,"Sortable"]},
    "form-builder":{deps:["angular","form-utils","angular-sanitize","Sortable","angular-legacy-sortable"]},
    "form-builder-bootstrap-tpls":{deps:["angular","form-builder"]},
    "form-viewer":{deps:["angular","form-utils","angular-sanitize","Sortable"]},
    "form-viewer-bootstrap-tpls":{deps:["angular","form-viewer","Sortable"]},
	"oi-select":{deps:["angular"]},
	"angular-moment":{deps:["angular","moment"]},
	Qrcode:{deps:["angular"]},
	Qr_Code:{deps:["angular"]},
	Qrcode_UTF8:{deps:["angular","Qr_Code"]},
	"angular-qrcode":{deps:["angular","Qr_Code"]},
	jqueryUI:{deps:["jquery"]},
	chosenmin:{deps:["jquery"]},
	prism:{deps:["jquery","chosenmin"]},
	bootstrap:{deps:["jquery"]},
	daterangepicker:{deps:["jquery"]},
	bootstrapui:{deps:["jquery"]},
	"angular-drag-to-reorder":{deps:["angular"]},
	"angular-ui-tinymce":{deps:["tinymce"]},
	userService:{deps:["app-config","app-api-service","app-utils"]},
	posService:{deps:["app-config","app-api-service","app-utils"]},
	siteServerService:{deps:["app-config","app-api-service","app-utils","eventService"]},
	companyService:{deps:["app-config","app-api-service","app-utils","countryService"]},
	countryService:{deps:["app-config","app-api-service","app-utils"]},
	eventService:{deps:["app-config","app-api-service","app-utils"]},
	authInterceptor:{deps:["app-config","app-api-service","session"]},
	authService:{deps:["app-config","app-api-service","app-utils"]},
	visitorService:{deps:["app-config","app-api-service","app-utils"]},	
	exhibitorService:{deps:["app-config","app-api-service","app-utils"]},	
	locationService:{deps:["app-config","app-api-service","app-utils"]},
	integrationService:{deps:["app-config","app-api-service","app-utils"]},
	surveyService :{deps:["app-config","app-api-service","app-utils"]},
	dashboardService:{deps:["app-config","app-api-service","app-utils"]},
    reportService:{deps:["app-config","app-api-service","app-utils"]},

	//surveyresponseService : {deps:["app-config","app-api-service","app-utils"]},
	FileUploader:{deps:["angular"]},
	FileUploadershim:{deps:["angular"]},
	imagecrop:{deps:["angular"]},
	"app-utils":{deps:["angular"]},
	"app-directive":{deps:["angular"]},
    "app-locationdirective":{deps:["angular"]},
	"app-store":{deps:["angular"]},
	"angular-sprintf":{deps:["angular","sprintf"]},
	highcharts:{deps:["angular"]},
	datatables:{deps:["angular"]},
    "angular-datatables":{deps:["angular"]},
    "angular-datatables-bootstrap":{deps:["angular"]},
    "angular-datatables-colreorder":{deps:["angular"]},
    "angular-datatables-columnfilter":{deps:["angular"]},
    "angular-datatables-colvis":{deps:["angular"]},
    "angular-datatables-fixedcolumns":{deps:["angular"]},
    "angular-datatables-fixedheader":{deps:["angular"]},
    "angular-datatables-scroller":{deps:["angular"]},
    "angular-datatables-tabletools":{deps:["angular"]},
    "angular-datatables-buttons":{deps:["angular"]},
    "angular-datatables-select":{deps:["angular"]},
	"ng-file-upload":{deps:["angular","ng-file-upload-shim"]},
	"app-api-service":{deps:["angular","app-config"]},
	"ng-xeditable":{deps:["angular"]},
	"app-excel":{deps:["angular"]},
	"app-list":{deps:["angular"]},
	"angular-ui-tree":{deps:["angular"]},
	"file-saver":{deps:["jquery"]},
	"app-user-home":{deps:["angular","userService","app-api-service"]},	
	"app-users":{deps:["angular","userService","app-api-service"]},
	"app-user-login":{deps:["angular","authService","app-api-service","session"]},
	"app-user-forgetpassword":{deps:["angular","authService","app-api-service"]},
	"app-user-resetpassword":{deps:["angular","authService","app-user-forgetpassword","app-api-service"]},
	"app-user-adduser":{deps:["angular","userService","app-api-service","Qr_Code","angular-qrcode","Qrcode_UTF8"]},
	"app-user-myprofile":{deps:["angular","userService","app-api-service"]},
	"app-user-userprofile":{deps:["angular","userService","app-api-service","Qr_Code","angular-qrcode","Qrcode_UTF8"]},
	"app-user-addposuser":{deps:["angular","userService","app-api-service"]},
	"app-user-posuserprofile":{deps:["angular","userService","app-api-service"]},	 
	"app-events":{deps:["angular","eventService","app-api-service","session"]},
	"app-eventdetails":{deps:["angular","eventService","app-api-service","session"]},
	"app-visitors":{deps:["angular","visitorService","eventService","app-api-service","app-utils","bootstrap-ui-tpls"]},
	"app-dashboard":{deps:["angular","dashboardService","app-api-service"]},		
	 //"app-surveys":{deps:["angular","userService","app-api-service"]},
	"app-surveys":{deps:["angular","surveyService","app-api-service","eventService","session"]},
	"app-addsurvey":{deps:["angular","surveyService","eventService","app-utils","app-api-service","form-builder"]},	
	"app-surveydetail":{deps:["angular","surveyService","app-api-service","eventService","app-utils","form-builder"]},
	"app-surveypreview":{deps:["angular","surveyService","app-api-service"]},
	"app-surveyresponse":{deps:["angular","surveyService","userService","app-api-service"]},
	"app-responsedetail":{deps:["angular","surveyService","app-api-service"]},
	"app-visitorprofile":{deps:["angular","userService","posService","visitorService","countryService","companyService","app-api-service"]},	 	
	"app-exhibitors":{deps:["angular","exhibitorService","eventService","app-api-service","app-utils","bootstrap-ui-tpls"]},
	"app-addexhibitors":{deps:["angular","exhibitorService","eventService","companyService","app-api-service"]},	
	"app-impexhibitors":{deps:["angular","exhibitorService","app-api-service"]},	
	"app-poss":{deps:["angular","posService","app-api-service"]},
    "app-siteservers":{deps:["angular","siteServerService","app-api-service","session"]},    
	"app-siteserverprofile":{deps:["angular","siteServerService","app-api-service"]},
	"app-companies":{deps:["angular","companyService","app-api-service"]},
	"app-addcompany":{deps:["angular","companyService","app-api-service"]},
	"app-companyprofile":{deps:["angular","companyService","app-api-service"]},		
	"app-countries":{deps:["angular","countryService","app-api-service","angular-ui-bootstrap"]},	
	"app-locations":{deps:["angular","locationService","app-api-service","angular-ui-bootstrap"]},
	"app-integration":{deps:["angular","integrationService","app-api-service"]},			
	"app-user-profilepage":{deps:["angular","userService","app-api-service"]},
    //"app-reports":{deps:["angular","reportService","eventService","countryService","app-api-service"]},
     "app-reports":{deps:["angular","reportService","app-api-service","bootstrap-ui-tpls"]},	
    // "app-reports":{deps:["angular","userService","eventService","countryService","app-api-service"]},
	"app-user-ssologin":{deps:["angular","userService"]},
	"app-user-register":{deps:["angular","userService","app-api-service"]},
	"app-user-verify":{deps:["angular","app-utils","userService"]}}
}),
    require(["angular","./app-routes"],
	function(angular){
		 angular.element(document).ready(function () {		    
		        angular.element(document).find('html').addClass('ng-app');
		        var pathFromApp = require.toUrl("../bower_components/bootstrap/dist/css/bootstrap.min.css");		       
		        var css1 = document.createElement('link');
	            css1.rel = 'stylesheet';
	            css1.href = pathFromApp;	 
	            document.head.appendChild(css1);

	            angularcsp = require.toUrl("../bower_components/angular/angular-csp.css");
                var csp = document.createElement('link');
                csp.rel = 'stylesheet';
                csp.href = angularcsp;     
                document.head.appendChild(csp);

		        pathFromApp = require.toUrl("../static/styles/font-awesome/css/font-awesome.min.css");
		        var css2 = document.createElement('link');
	            css2.rel = 'stylesheet';
	            css2.href = pathFromApp;	 
	            document.head.appendChild(css2);

	            pathFromApp = require.toUrl("../bower_components/ng-img-crop/compile/minified/ng-img-crop.css");
                var css8 = document.createElement('link');
                css8.rel = 'stylesheet';
                css8.href = pathFromApp;     
                document.head.appendChild(css8);

                pathFromApp = require.toUrl("../bower_components/angular-mass-autocomplete/massautocomplete.theme.css");
                var css9 = document.createElement('link');
                css9.rel = 'stylesheet';
                css9.href = pathFromApp;     
                document.head.appendChild(css9);

                formboot = require.toUrl("../bower_components/angular-surveys/dist/form-builder-bootstrap.min.css");
                var fbb = document.createElement('link');
                fbb.rel = 'stylesheet';
                fbb.href = formboot;     
                document.head.appendChild(fbb);

                formview = require.toUrl("../bower_components/angular-surveys/dist/form-viewer.min.css");
                var fvm = document.createElement('link');
                fvm.rel = 'stylesheet';
                fvm.href = formview;     
                document.head.appendChild(fvm);

		        
		        pathFromApp = require.toUrl("../static/styles/custom.css");
		        var css4 = document.createElement('link');
	            css4.rel = 'stylesheet';
	            css4.href = pathFromApp;	 
	            document.head.appendChild(css4);
	          

				pathFromApp = require.toUrl("../bower_components/angular-datatables/dist/css/angular-datatables.min.css");
                var css5 = document.createElement('link');
                css5.rel = 'stylesheet';
                css5.href = pathFromApp;     
                document.head.appendChild(css5);

                pathFromApp = require.toUrl("../bower_components/angular-datatables/dist/css/angular-datatables.min.css");
                var css6 = document.createElement('link');
                css6.rel = 'stylesheet';
                css6.href = pathFromApp;     
                document.head.appendChild(css6);

                pathFromApp = require.toUrl("../bower_components/datatables.net/css/jquery.dataTables.min.css");
                var css7 = document.createElement('link');
                css7.rel = 'stylesheet';
                css7.href = pathFromApp;     
                document.head.appendChild(css7);

                pathFromApp = require.toUrl("../static/styles/chosen.css");
		        var chosen = document.createElement('link');
	            chosen.rel = 'stylesheet';
	            chosen.href = pathFromApp;	 
	            document.head.appendChild(chosen);

                pathFromApp = require.toUrl("../static/styles/style.css");
		        var css3 = document.createElement('link');
	            css3.rel = 'stylesheet';
	            css3.href = pathFromApp;	 
	            document.head.appendChild(css3);

	         //     pathFromApp = require.toUrl("../static/styles/multiselect/bootstrap-multiselect.css");
		        // var css3 = document.createElement('link');
	         //    css3.rel = 'stylesheet';
	         //    css3.href = pathFromApp;	 
	         //    document.head.appendChild(css3);

      			angular.bootstrap(document, ['app'], ['modules']);
		    });
	}

	

	);