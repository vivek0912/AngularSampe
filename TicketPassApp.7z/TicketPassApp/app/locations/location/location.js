define(function(require){
	angular.module("app").controller("locationCtrl",function($window,$uibModal,$filter,locationService,$timeout,apiService,$scope,$location,$translate,$state,$rootScope){
		$scope.hideSuccess = true;
		$scope.newLocation={};
		$scope.selection=[];
		$scope.count=0;
		$scope.SuccessMessage='';
		$scope.actionName='';
		$scope.LocationSelected =[];
		$scope.SuccessMessage='';
          $scope.action='';
          $scope.errorMessage ='';
          $scope.showeerror = false;
          $scope.selectedItem = 'no item selected';	
          $scope.locationDatatable;
    localStorage.removeItem("allvisitor"); 
    localStorage.removeItem("alluser") 
    localStorage.removeItem("allexhibitor");
    localStorage.removeItem("eventtype"); 
		$scope.newlocation = function()
		 {
		// $location.url("/company/addcompany");
		 }
    		 
    		 setTimeout(function() { 
                 
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
             
             $("#menu-toggle").click(function(e) {                          
            e.preventDefault();
            $(".content").toggleClass("toggled");
            });
             
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar").toggleClass("toggled");
            });             

        }, 1500);

          var noitemfounds = "";
          var searchtext = "";
         $translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
                    });
         $translate(['searchlocations']).then(function (translations) {
                      searchtext = translations.searchlocations;                      
         });

 
   			$timeout(function() { 	  	 
				   $(".systm-setting .submenu").addClass("in");
         $(".systm-setting .Toggleonload").removeClass("collapsed");
          $(".systm-setting .Toggleonload i").addClass("fa-angle-down");   
				
				},300);
   			//multiple selection...
          		$scope.multipleSelection = function multipleSelection(locationId) {            
                		var id = $scope.selection.indexOf(locationId);           
                			if (id > -1) {
                        			$scope.selection.splice(id, 1);
                        			$scope.count--;
                			}
                			else {
                    			$scope.selection.push(locationId);
                    			$scope.count++;

               				}
          		};

	  			$scope.closeLocation=function(){
	  				$scope.myDialog.close();
	  			}
	  		//getting list of location
	  			locationService.getLocations().then(function(response){
	  		
	  		  	  $scope.locations=response.data.data;
	  		  	  	$timeout(function() {  
                     	$scope.locationDatatable = $('#locationTable').DataTable( { 
                          "paging":   true,             
                          "info":     true,
                          "searching": true,
                          "pageLength":10,
                          "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                           language: {
                            emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                    	searchPlaceholder: searchtext,
                                    	search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                      infoFiltered: " "
                                     }     
                      	});

                      $('#locationTable').wrap('<div class="responsive-datatable" />');
                	},200);
	  			});
	  			$scope.ReloadLocations = function(){
	  				$scope.locationDatatable.destroy();
	  				$timeout(function() {  
                     	$scope.locationDatatable = $('#locationTable').DataTable( { 
                          "paging":   true,             
                          "info":     true,
                          "searching": true,
                          "pageLength":10,
                          "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                           language: {
                            emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                    	searchPlaceholder: searchtext,
                                    	search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                     }     
                      	});
                      $('#locationTable').wrap('<div class="responsive-datatable" />');
                	},0);
	  			}
	  			$scope.closeLocation = function	(){
	  				$scope.myDialog.close();
	  			}
	  		//add/edit location
	  			$scope.addLocation=function(){
	  		
 					if($scope.title=='Add Location')
 					{
 						
 						$scope.action='is created';
				 		locationService.saveLocation($scope.newLocation).then(function (response) { 
				 				$scope.hideSuccess = false;
				 				
								$scope.SuccessMessage=response.data.data.Location_Name;
								$scope.myDialog.close();
								$timeout(function () { $scope.hideSuccess = true; }, 2000);   
								locationService.getLocations().then(function(response){		 		  
		  							$scope.locations=response.data.data;
		  							$scope.ReloadLocations();
		  							
		  						});
	             		});
					}
					else
					{
						$scope.action='is updated';
						locationService.updateLocation($scope.newLocation).success(function (response){
						
							$scope.hideSuccess = false;
							$scope.SuccessMessage=$scope.newLocation.Location_Name;
							$scope.myDialog.close();
							$timeout(function () { $scope.hideSuccess = true; }, 2000); 
	                		locationService.getLocations().then(function(response){
	                     		$scope.locations=response.data.data;
	                     		$scope.ReloadLocations();
	                     	            
	                  		});
	                });
					}
			}

	  		//delete location
	  			$scope.deleteLocation=function(location){
           
	  				$scope.action="is deleted";
              		var locationName=location.Location_Name;
	  				locationService.deleteLocationData(location.Location_Id).then(function(response){
            
              if(response.data.status==200)
              {
      	  					$scope.hideSuccess=false;
                    $scope.SuccessMessage=locationName;
                    $timeout(function () { $scope.hideSuccess = true; }, 2000);
      	  					locationService.getLocations().then(function(response){	
      	  							$scope.locations=response.data.data;
      	  							$scope.ReloadLocations();
      	  					});
            }
            else{
               $scope.showErrorMessage(locationName);
            }
	  				});
	  			}
	  			//multiple deletion..
          		$scope.deleteMultipleLocation = function()
            	{
                 var noOfLocation='';
              		//selecting all checked row
          			var list = $scope.locations.filter(function (obj) {
			              if (obj.checked !== undefined && obj.checked === true) {
			                  return obj;
			              }
			         });
                 if(list.length!==0)
                 {
                         if(list.length==1){
                              $scope.action="is deleted";
                             noOfLocation=list.length+" "+"location";
                        }
                    if(list.length>1){
                                $scope.action="are deleted";
                             noOfLocation=list.length+" "+"locations";
                        }        
                        locationService.deleteMultipleLocation(list).then(function (response){

                              if(response.data.status === 200)
                              {
                                    if(response.data.data==true){
                                      $scope.selectedItem = 'no'; 
                                     
                                    }
                                    $scope.hideSuccess=false;
                                    $scope.SuccessMessage=noOfLocation;
                                    
                                   $timeout(function () { $scope.hideSuccess = true; }, 2000);
                  					locationService.getLocations().then(function(response){
                 			 			$scope.locations=response.data.data;
                 			 			$scope.ReloadLocations();            
                 		 			});      
                              }
                              else
                              {
                                  $scope.showErrorMessage(response.data.err_msg);
                              }
                          });
                    }
                    else
                    {
                        $scope.selectedItem = 'no item selected';
                    }
            }
             $scope.locationCheckedchanged = function()
            {
               var list = $scope.locations.filter(function (obj) {
			              if (obj.checked !== undefined && obj.checked === true) {
			                  return obj;
			              }
			         });
                  if(list.length == 1)
                      $scope.selectedItem = list.length;
                  else if (list.length > 1)
                      $scope.selectedItem = list.length;
                  else 
                      $scope.selectedItem = 'no item selected';
                    
            }
            $scope.showErrorMessage = function(message)
              {
                  $scope.errorMessage = message;
                  $scope.hideSuccess=true;
                  $scope.showeerror = true;
                   $timeout(function () { $scope.errorMessage = ''; $scope.showeerror = false;}, 2000);
              }
	  		//bind location data with modal for add or edit
		 	$scope.bindLocationData=function(locationId){
		 		if(locationId!==undefined)
		 		{
		 			$scope.disabled=true;
		 			locationService.getLocation(locationId).then(function (response){
		 				
                     		$scope.newLocation=response.data.data;  
                     		$scope.title = "Edit Location";
                     		$scope.buttonValue='Update'
	             	 		$scope.myDialog = $uibModal.open({
	             	 			scope: $scope,
	             	 			animation: $scope.animationsEnabled,
	                			templateUrl: 'app/locations/location/location.popup.html',			
	                			                	                	 	
	             		});
	             	 		$scope.myDialog.result.then( function( modalResult ){
	             	 			
        						$scope.newLocation = {};
					        	$scope.$apply();}).finally(function(){
        						$scopemyDialog.$destroy(); 
        					
    							});
	             	});

				}
				else
				{
							$scope.disabled=false;                    		 
                     		$scope.title = "Add Location";
                     		$scope.buttonValue='Add'
	             	 		$scope.myDialog = $uibModal.open({
	             	 			scope: $scope,
	             	 			animation: $scope.animationsEnabled,
	                			templateUrl: 'app/locations/location/location.popup.html',			
	                			                
	                	 	
	             		});
	             	 		$scope.myDialog.result.then( function( modalResult ){
	             	 			
        						$scope.newLocation = {};
					        	$scope.$apply();}).finally(function(){
        						$scopemyDialog.$destroy(); 
        					
    							});
	             	
				}
							
						
		 	
		 	}
 	});
});