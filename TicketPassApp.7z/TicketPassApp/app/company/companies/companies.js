 define(function(require){
    angular.module("app").controller("companiesCtrl",function($window,$uibModal,$filter,companyService,apiService,$scope,$location,$state,$translate,$rootScope,$timeout,dataFactory){
          $scope.hideSuccess=true;
          $scope.SuccessMessage='';
          $scope.action='';
          $scope.errorMessage ='';
          $scope.importerrorMessage='';
          $scope.showeerror = false;
          $scope.selectedItem = 'no item selected';
          $scope.count=0;
          $scope.selection=[];
          $scope.pageSize=['10','20','30'];
          $scope.selectedSize= $scope.pageSize[0];
          $scope.groupedItems = [];
          $scope.itemsPerPage = 10;
          $scope.pagedItems = [];
          $scope.currentPage = 0;
          $scope.companyexcelFile = null;
          $scope.newFileName = '';
          $scope.progressVisible = false;
          $scope.companyprogress = 10; 
          $scope.CompanydataTabel;
          $scope.Incluedtime = Date.now();
          $scope.includeGrid = "<div ></div>";
          $scope.showimporteerror = false; 
             localStorage.removeItem("allvisitor"); 
             localStorage.removeItem("alluser") 
             localStorage.removeItem("allexhibitor");
             localStorage.removeItem("eventtype"); 
        var noitemfounds = "";
        var searchtext = "";
         $translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
                    });
         $translate(['searchcompanies']).then(function (translations) {
                      searchtext = translations.searchcompanies;                      
         });


            companyService.getCompanies().then(function(data){      
                    $scope.companies=data.data.data;  
                    //document.getElementById("GridDiv").innerHTML = $scope.includeGrid;
                    $timeout(function() {  
                    $scope.CompanydataTabel =   $('#companyTable').DataTable( { 
                          "paging":   true,             
                          "info":     true,
                          "searching": true,
                          "pageLength":10,
                          "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                          language: {
                            emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                    searchPlaceholder:  searchtext,
                                    search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                    infoFiltered: " "
                          }      
                        });
                     $('#companyTable').wrap('<div class="responsive-datatable" />');
                     },200);          
              });
      
          $scope.gotocompany = function()
          {
            $location.url("/company/addcompany");
          }

          setTimeout(function() { 
                 
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
             
             $("#menu-toggle").click(function(e) {                          
            e.preventDefault();
            $(".content").toggleClass("toggled");
            });
             
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar").toggleClass("toggled");
            });

        }, 1500);
          
             $timeout(function() {  
          $(".systm-setting .submenu").addClass("in");
         $(".systm-setting .Toggleonload").removeClass("collapsed");
          $(".systm-setting .Toggleonload i").addClass("fa-angle-down");  
          },200);
          //show success message and hide auto
          if($location.search().createCompany)
          {
              $scope.action="is created";
              $scope.hideSuccess=false;
              var data=$location.search().createCompany;
              $scope.SuccessMessage=data;
              $timeout(function () { $scope.hideSuccess = true; }, 3000);

              $location.search({}); 
          }
          else if($location.search().updateCompany)
          {
              $scope.action="is updated";
              $scope.hideSuccess=false;
              var data=$location.search().updateCompany;
              $scope.SuccessMessage=data;
              $timeout(function () { $scope.hideSuccess = true; }, 3000);
              $location.search({}); 
          }
          else if($location.search().deleteCompanyProfile)
          {
              $scope.action="is deleted";
              $scope.hideSuccess=false;
              var data=$location.search().deleteCompanyProfile;
              $scope.SuccessMessage=data;
              $timeout(function () { $scope.hideSuccess = true; }, 3000);
              $location.search({}); 
          }

          //link to addComapny
          $scope.addCompany = function(){
               $location.url("/company/addcompany");
          }
        
          $scope.viewCompany = function (companyId) {
               dataFactory.setCompanyId(companyId);
               $location.url("/company/companyprofile");
          }
          //delete company
          $scope.deleteCompany=function(CompanyId){
           
            $scope.company
              $scope.action="is deleted";
              var companyName=this.company.Company_Name;
              companyService.deleteCompanyData(CompanyId).then(function (response){
                 if(response.data.status==200)
                  {
                        $scope.hideSuccess=false;
                        $scope.SuccessMessage=companyName;
                        $timeout(function () { $scope.hideSuccess = true; }, 3000);
        
                        companyService.getCompanies().then(function(data){
                            $scope.companies=data.data.data;   
                            $scope.CompanydataTabel.destroy();
                                 $timeout(function(){
                                    $scope.CompanydataTabel =   $('#companyTable').DataTable( { 
                                      "paging":   true,             
                                      "info":     true,
                                      "searching": true,
                                      "pageLength":10,
                                      "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                                      language: {
                                        emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                                searchPlaceholder:  searchtext,
                                                search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                      }      
                                    });
                                    $('#companyTable').wrap('<div class="responsive-datatable" />'); 
                                 },0);

                                                         
                        });
                      }
                      else
                      {
                        $scope.showErrorMessage(companyName);
                      }
                  
              });            
          }

            $scope.deleteMultipleCompany = function()
            {
              
                 var noOfCompany='';
                var list = $scope.companies.filter(function (obj) {
                          if (obj.checked !== undefined && obj.checked === true) {
                              return obj;
                          }
                      });

                 if(list.length!==0)
                 {
                         if(list.length==1){
                              $scope.action="is deleted";
                             noOfCompany=list.length+" "+"company";
                        }
                    if(list.length>1){
                                $scope.action="are deleted";
                             noOfCompany=list.length+" "+"companies";
                        }        
                        companyService.deleteMultipleCompany(list).then(function(response){
                        
                              if(response.data.status === 200)
                              {
                                    if(response.data.data==true){
                                      $scope.selectedItem = 'no'; 
                                     
                                    }
                                    $scope.hideSuccess=false;
                                    $scope.SuccessMessage=noOfCompany;
                                    
                                   $timeout(function () { $scope.hideSuccess = true; }, 3000);
                                   companyService.getCompanies().then(function(response){
                                        if(response.status == 200)
                                        {
                                               $scope.companies=response.data.data;                                               
                                               $scope.CompanydataTabel.destroy();
                                               $timeout(function(){
                                                  $scope.CompanydataTabel =   $('#companyTable').DataTable( { 
                                                    "paging":   true,             
                                                    "info":     true,
                                                    "searching": true,
                                                    "pageLength":10,
                                                    "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                                                    language: {
                                                      emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                                              searchPlaceholder:  searchtext,
                                                              search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                                    }      
                                                  });
                                                   $('#companyTable').wrap('<div class="responsive-datatable" />');
                                               },0);
                                               
                                        }
                       
                                    });
                                        
                              }
                              else
                              {
                                  $scope.showErrorMessage(response.data.err_msg);
                              }
                          });
                    }
                    else
                    {
                        $scope.selectedItem = 'no item selected';
                    }
            }
           $scope.companyCheckedchanged = function(company,index)
            {
                company.currIndex = index;
                var list = $scope.companies.filter(function (obj) {                          
                          if (obj.checked !== undefined && obj.checked === true) {
                              return obj;
                          }
                      });
                  if(list.length == 1)
                      $scope.selectedItem = list.length;
                  else if (list.length > 1)
                      $scope.selectedItem = list.length;
                  else 
                      $scope.selectedItem = 'no item selected';
                    
            }
            $scope.showErrorMessage = function(message)
              {
                  $scope.errorMessage = message;
                  $scope.hideSuccess=true;
                  $scope.showeerror = true;
                   $timeout(function () { $scope.errorMessage = ''; $scope.showeerror = false;}, 3000);
              }

            $scope.importCompany = function(){
              $scope.progressVisible = false;
              $scope.companyprogress = 10;  
              $scope.companyexcelFile = null;  
              $('#companyexcelfileInput').val('');           
              $scope.myDialog = $uibModal.open({
                      scope: $scope,
                      animation: $scope.animationsEnabled,
                        templateUrl: 'app/company/companies/companiesImport.popup.html',      
                                                              
                  });
                    $scope.myDialog.result.then( function( modalResult ){
                    }).finally(function(){
                    $scopemyDialog.$destroy();                   
                  });
            }
            $scope.CompanyexcleFileChanged=function(evt, type) {   
              var file=evt.currentTarget.files[0];
              var reader = new FileReader();
              reader.onload = function (evt) {
                     $scope.$apply(function($scope){               
                       $scope.companyexcelFile=evt.target.result;                  
                     });
                     
                   };
                    reader.readAsDataURL(file);
            }
             $scope.$on('file-dropzone-drop-event', function(event, data) {                
                $scope.$apply(function($scope){               
                       $scope.companyexcelFile = data.file;                 
                     });
            });
            $scope.$watch('companyexcelFile', function () {
                if($scope.companyexcelFile != null)
                {
                  $scope.progressVisible = true;
                  $scope.companyprogress = 10; 
                  $scope.showProgress();  
                  companyService.UploadCompany($scope.dataURItoBlob($scope.companyexcelFile)).then(function(response){
                    if(response.status === 200)
                      {
                        $scope.companies = response.data;
                        $scope.companyprogress = 100;
                        $scope.myDialog.close();
                        $scope.CompanydataTabel.destroy();
                        $timeout(function(){
                        $scope.CompanydataTabel =   $('#companyTable').DataTable( { 
                            "paging":   true,             
                            "info":     true,
                            "searching": true,
                            "pageLength":10,
                            "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                            language: {
                              emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                      searchPlaceholder:  searchtext,
                                      search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                            }      
                          });
                         $('#companyTable').wrap('<div class="responsive-datatable" />');
                       },0);
                        
                        $scope.$apply();                 
                      }
                      else
                      {
                           $scope.companyprogress = 100;
                           $scope.myDialog.close();
                           
                           $scope.showimporteerror = true;
                           $timeout(function() {  
                              $scope.errorMessage = '';
                              $scope.showimporteerror = false;
                              $scope.$apply();
                           },4000);

                      }                   
                  });

                }
            });
            $scope.showProgress = function()
              {
                $timeout(function() {  
                if($scope.companyprogress != 100)
                {
                  $scope.companyprogress += 10;
                  $scope.showProgress();
                }
                else
                  $scope.companyprogress = 100;
                $scope.$apply();          
                },200);
              }
            $scope.dataURItoBlob=function(dataURI) {
                // convert base64/URLEncoded data component to raw binary data held in a string
                var byteString;
                if (dataURI.split(',')[0].indexOf('base64') >= 0)
                    byteString = atob(dataURI.split(',')[1]);
                else
                    byteString = unescape(dataURI.split(',')[1]);

                // separate out the mime component
                var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

                // write the bytes of the string to a typed array
                var ia = new Uint8Array(byteString.length);
                for (var i = 0; i < byteString.length; i++) {
                    ia[i] = byteString.charCodeAt(i);
                }

                return new Blob([ia], {type:mimeString});
            };
            $scope.closeCompanyImport=function(){
                $scope.myDialog.close();
            }

    });//End Controller
});//End define