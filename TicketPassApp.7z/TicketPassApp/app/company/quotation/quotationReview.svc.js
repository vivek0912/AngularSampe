angular.module('app').service('quotationReviewService', function(apiService, dashboardStore, $rootScope, $filter, $stateParams) {

    var onFail = null,
        onError = null;

    var getQuotationDetail = function(){

        var params = {
            public_key:$stateParams.id
        };

        var onSuccess = function(respones){
            $rootScope.$broadcast('pdfUrl', respones.data.quotation.pdf);
            $rootScope.$broadcast('companyName', respones.data.company.name);
        };

        return apiService.ajaxPost('acceptance/quotationDetail', params, onSuccess);
    };


    var acceptQuotation = function (){

        var approve_user = $stateParams.approve_user? 0 : $stateParams.approve_user;

        var params = {
            public_key:$stateParams.id,
            approve:1,
            approve_user:approve_user
        };

        var onSuccess = function(respones){
            if(respones.status === "ok"){
                $rootScope.alerts = [
                    { show:1, type:'info', title:'Success', text:$filter('translate')('Thank you'), dismissTimeout:5000 }
                ];
            }
        };

        var onError = function(respones){
            $rootScope.alerts = [
                { show:1, type:'danger', title:'Error', text:respones.reason, dismissTimeout:5000 }
            ];
        };

        return apiService.ajaxPost('acceptance/quotationDetail', params, onSuccess, onFail, onError);
    };

    var rejectQuotation = function(reason){

        var approve_user = $stateParams.approve_user? 0 : $stateParams.approve_user;

        var params = {
            public_key:$stateParams.id,
            approve:0,
            reason:reason,
            approve_user:approve_user
        };

        var onSuccess = function(respones){
            if(respones === 'ok'){
                $rootScope.alerts = [
                    { show:1, type:'danger', title:'Reject', text:$filter('translate')('reject-the-quotation'), dismissTimeout:5000 }
                ];
            }
        };

        var onError = function(respones){
            $rootScope.alerts = [
                { show:1, type:'danger', title:'Error', text:respones.reason, dismissTimeout : 5000 }
            ];
        }

        return apiService.ajaxPost('acceptance/quotationDetail', params, onSuccess, onFail, onError);
    };



    return{
        acceptQuotation:acceptQuotation,
        rejectQuotation:rejectQuotation,
        getQuotationDetail:getQuotationDetail
    };

});
