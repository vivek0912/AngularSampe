angular.module('app', []).controller('quotationReviewCtrl', function($scope, $state, $rootScope, $filter, quotationReviewService, dashboardStore, $uibModal, $stateParams) { 
		

		function init(){
			quotationReviewService.getQuotationDetail();
		};

		init();

		$rootScope.$on('pdfUrl', function(event, pdfUrl){
			$scope.pdfUrl = pdfUrl;
		});

		$rootScope.$on('companyName', function(event, companyName){
			$scope.companyName = companyName;
		});



		$scope.accept = function(){
			var modalInstance = $uibModal.open({
      			animation: true,
      			backdrop: 'static',
      			templateUrl: 'acceptModal.html',
      			controller: 'acceptCtrl',
      			resolve: {
      				settings: function(){
	      				return {
		        			'confirmQuotation':function(){
		        				return quotationReviewService.acceptQuotation();
		        			}
		        		}
		        	}
     			}
    		});
		};

		$scope.reject = function(){
			var modalInstance = $uibModal.open({
      			animation: true,
      			backdrop: 'static',
      			templateUrl: 'acceptanceModal.html',
      			controller: 'rejectCtrl',
      			resolve: {
        			settings: function () {
          				return{
          					'rejectQuotation':function(reason){
          						return quotationReviewService.rejectQuotation(reason);
          					}
          				};
        			}
     			}
    		});
		};

}).filter('trustAsResourceUrl', ['$sce', function($sce){
	return function(val){
		return $sce.trustAsResourceUrl(val);
	};
}]);

angular.module('app').controller('acceptCtrl', function($scope, $uibModalInstance, settings, $rootScope, $filter){
	
	$scope.settings = settings;

	$scope.confirm = function(){
		settings.confirmQuotation();
		$scope.cancel();
	};

	$scope.cancel = function(){
		 $uibModalInstance.dismiss('cancel');
	};

});

angular.module('app').controller('rejectCtrl', function($scope, $uibModalInstance, settings, $rootScope, $filter, dashboardStore){
	
	$scope.settings = settings;

	$scope.reject = function(){

		settings.rejectQuotation($scope.reason);
		$scope.cancel();

	};

	$scope.cancel = function (){
		$uibModalInstance.dismiss('cancel');
	};
});
