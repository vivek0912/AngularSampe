angular.module('app', []).controller('quotationReviewCtrl', function($scope, $state, $rootScope, $filter, quotationReviewService, dashboardStore, $uibModal, $stateParams) { 
		

		function init(){
			quotationReviewService.getQuotationDetail();
		};

		init();

		$rootScope.$on('pdfUrl', function(event, pdfUrl){
			$scope.pdfUrl = pdfUrl;
		});

		$rootScope.$on('companyName', function(event, companyName){
			$scope.companyName = companyName;
		});



		$scope.accept = function(){
			var modalInstance = $uibModal.open({
      			animation: true,
      			backdrop: 'static',
      			templateUrl: 'acceptModal.html',
      			controller: 'acceptCtrl',
      			resolve: {
      				settings: function(){
	      				return {
		        			'confirmQuotation':function(){
		        				return quotationReviewService.acceptQuotation();
		        			}
		        		}
		        	}
     			}
    		});
		};

		$scope.reject = function(){
			var modalInstance = $uibModal.open({
      			animation: true,
      			backdrop: 'static',
      			templateUrl: 'acceptanceModal.html',
      			controller: 'rejectCtrl',
      			resolve: {
        			settings: function () {
          				return{
          					'rejectQuotation':function(reason){
          						return quotationReviewService.rejectQuotation(reason);
          					}
          				};
        			}
     			}
    		});
		};

}).filter('trustAsResourceUrl', ['$sce', function($sce){
	return function(val){
		return $sce.trustAsResourceUrl(val);
	};
}]);

angular.module('app').controller('acceptCtrl', function($scope, $uibModalInstance, settings, $rootScope, $filter){
	
	$scope.settings = settings;

	$scope.confirm = function(){
		settings.confirmQuotation();
		$scope.cancel();
	};

	$scope.cancel = function(){
		 $uibModalInstance.dismiss('cancel');
	};

});

angular.module('app').controller('rejectCtrl', function($scope, $uibModalInstance, settings, $rootScope, $filter, dashboardStore){
	
	$scope.settings = settings;

	$scope.reject = function(){

		settings.rejectQuotation($scope.reason);
		$scope.cancel();

	};

	$scope.cancel = function (){
		$uibModalInstance.dismiss('cancel');
	};
});

angular.module('app').service('quotationReviewService', function(apiService, dashboardStore, $rootScope, $filter, $stateParams) {

    var onFail = null,
        onError = null;

    var getQuotationDetail = function(){

        var params = {
            public_key:$stateParams.id
        };

        var onSuccess = function(respones){
            $rootScope.$broadcast('pdfUrl', respones.data.quotation.pdf);
            $rootScope.$broadcast('companyName', respones.data.company.name);
        };

        return apiService.ajaxPost('acceptance/quotationDetail', params, onSuccess);
    };


    var acceptQuotation = function (){

        var approve_user = $stateParams.approve_user? 0 : $stateParams.approve_user;

        var params = {
            public_key:$stateParams.id,
            approve:1,
            approve_user:approve_user
        };

        var onSuccess = function(respones){
            if(respones.status === "ok"){
                $rootScope.alerts = [
                    { show:1, type:'info', title:'Success', text:$filter('translate')('Thank you'), dismissTimeout:5000 }
                ];
            }
        };

        var onError = function(respones){
            $rootScope.alerts = [
                { show:1, type:'danger', title:'Error', text:respones.reason, dismissTimeout:5000 }
            ];
        };

        return apiService.ajaxPost('acceptance/quotationDetail', params, onSuccess, onFail, onError);
    };

    var rejectQuotation = function(reason){

        var approve_user = $stateParams.approve_user? 0 : $stateParams.approve_user;

        var params = {
            public_key:$stateParams.id,
            approve:0,
            reason:reason,
            approve_user:approve_user
        };

        var onSuccess = function(respones){
            if(respones === 'ok'){
                $rootScope.alerts = [
                    { show:1, type:'danger', title:'Reject', text:$filter('translate')('reject-the-quotation'), dismissTimeout:5000 }
                ];
            }
        };

        var onError = function(respones){
            $rootScope.alerts = [
                { show:1, type:'danger', title:'Error', text:respones.reason, dismissTimeout : 5000 }
            ];
        }

        return apiService.ajaxPost('acceptance/quotationDetail', params, onSuccess, onFail, onError);
    };



    return{
        acceptQuotation:acceptQuotation,
        rejectQuotation:rejectQuotation,
        getQuotationDetail:getQuotationDetail
    };

});
