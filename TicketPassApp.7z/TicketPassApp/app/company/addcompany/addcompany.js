  define(function(require){
  	angular.module("app").controller("addcompanyCtrl",function($window,companyService,countryService,apiService,$scope,$location,$state,$rootScope){
       
          $scope.activeTab = 1;  
          $scope.newUser={};
          $scope.newCompany={};
          $location.search({});
          $scope.setActiveTab = function(tabToSet) {      
            $scope.activeTab = tabToSet;
          }
          // function to submit the form after all validation has occurred            
            $scope.cancelCompany = function() {
              
            };
          setTimeout(function() {  
  				   $(".systm-setting .submenu").addClass("in");
         $(".systm-setting .Toggleonload").removeClass("collapsed");
          $(".systm-setting .Toggleonload i").addClass("fa-angle-down");   
  				},200);
          //cancel add form
            setTimeout(function() { 
                 
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
             
             $("#menu-toggle").click(function(e) {                          
            e.preventDefault();
            $(".content").toggleClass("toggled");
            });
             
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar").toggleClass("toggled");
            });

        }, 1500);
            
          $scope.gotocompany=function(){;
            $location.url("/companies");
          }
          //create company
          $scope.company = function()
      	  {  
            companyService.saveCompany($scope.newCompany).then(function (response) {
                   $location.url('/companies?createCompany='+response.data.data.Company_Name);
                   }); 			
          }
          //get countries for bind country dropdown list
            countryService.getCountries().then(function(response){        
                  $scope.countries=response.data.data;
            
            })

   })
  });