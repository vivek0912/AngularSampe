define(function(require){
	angular.module("app").controller("acompanyprofileCtrl",function($window,companyService,countryService,apiService,$scope,$location,$state,$rootScope,dataFactory){
     
       $scope.activeTab = 1; 
       $scope.companyProfile={}; 
        var companyId=dataFactory.getCompanyId();
        if(companyId === undefined)
          $location.url("/companies");
      
        $scope.setActiveTab = function(tabToSet) {      
          $scope.activeTab = tabToSet;
        }

        setTimeout(function() {  
				   $(".systm-setting .submenu").addClass("in");
         $(".systm-setting .Toggleonload").removeClass("collapsed");
          $(".systm-setting .Toggleonload i").addClass("fa-angle-down");   
				
				},200);
         $scope.gotocompany = function()
         {
             if(dataFactory.getVisitorName()=="visitor") 
              {
                 dataFactory.setVisitorName("");
                 $location.url('/visitors');
              }
              else
              {
                $location.url("/companies");
              }
         }

         //calling getCompany to bind control for edit
         companyService.getCompany(companyId).then(function(data){
                 $scope.companyProfile=data.data.data;
                 $scope.companyProfile.Phone=parseInt($scope.companyProfile.Phone);
                 $scope.companyProfile.Fax=parseInt($scope.companyProfile.Fax);
                 
             })
         //update company profile
         $scope.updateCompanyProfile = function(){
              $scope.companyProfile.Create_On = new Date();
              $scope.companyProfile.Update_On = new Date();
              companyService.updateCompany($scope.companyProfile) .then(function (data) { 
              if(dataFactory.getVisitorName()=="visitor") 
              {
                 dataFactory.setVisitorName("");
                 $location.url('/visitors');
              }
              else{
                 $location.url('/companies?updateCompany='+data.config.data.Company_Name)
               }
                // $location.path('/companies').search({updateCompany:data.config.data}); 
              });
          }
          $scope.deleteCompanyProfile=function(companyProfile){
          
              companyService.deleteCompanyData(companyProfile.Company_Id).success(function (data){
               
                 $location.url('/companies?deleteCompanyProfile='+companyProfile.Company_Name);        
              });
                      
          }
          //get countries for bind country dropdown list
            countryService.getCountries().then(function(response){        
                  $scope.countries=response.data.data;
            
            })


 })});