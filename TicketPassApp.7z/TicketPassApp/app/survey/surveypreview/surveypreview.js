 
define(function(require){
angular.module("app").controller("surveypreviewCtrl",function($window,$q,apiService,surveyService,mwFormResponseUtils,dataFactory,$scope,$location,$state,$rootScope){
	$scope.formViewer =surveyService.getSurveyFormDetails($scope.FormID).then(function (data) {
	 		$scope.serveyDetails = data.data;
	 		$scope.formData = JSON.parse($scope.serveyDetails.Data_Fields);
	 		return JSON.parse($scope.serveyDetails.Data_Fields);
	 	});;
 	$scope.viewerReadOnly = false;     
    $scope.FormID = dataFactory.getsurveyformId();
    $scope.serveyDetails = {};
	$scope.formOptions = {
        autoStart: true
    };
    $scope.formStatus= {};
    $scope.responseData ={};
    $scope.formData = dataFactory.getsurveyformdata();

 	$scope.GetSurveyDetails = function()
	 {
	 	surveyService.getSurveyFormDetails($scope.FormID).then(function (data) {
	 		$scope.serveyDetails = data.data;
	 		//$scope.formData = JSON.parse($scope.serveyDetails.Data_Fields);
	 		//return JSON.parse($scope.serveyDetails.Data_Fields);
	 	});
	 }
	 $scope.saveSurveyResponse = function()
	 {	
	 	var responseobj =  	JSON.stringify($scope.responseData);
	 	console.log(responseobj);
       return $location.url("/survey/surveydetail"); 
	 }
	 //   
	 $scope.backtosurvey = function()
	 {
	 	$location.url("/survey/surveydetail");
	 }
	 $scope.GetSurveyDetails();
 })
});