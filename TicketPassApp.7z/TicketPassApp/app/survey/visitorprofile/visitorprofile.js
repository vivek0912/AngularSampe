	define(function(require){
	angular.module("app").controller("visitorprofileCtrl",function($http,$window,apiService,visitorService,posService,countryService,companyService,dataFactory,$scope,$location,$state,$timeout,$rootScope,Upload,$sce){
   		
   		$scope.activeTab = 1; 		
        $scope.visitorProfile = [];
        $scope.visitorProfileCompany = [];
        $scope.countryfilter =[];
        $scope.companyfilter =[];	
        $scope.FileUpload = null;
        $scope.NewFileUpload = null;
        $scope.imageCropResult = null;
        $scope.showImageCropper = true;
        $scope.imageCropStep=1;
        $scope.visitorProfileCompanyext ='';
        $scope.ResponseMsg="";
         $scope.VisitorUUIDMsg="";
         $scope.POSS={};
         $scope.Pass={};
         $scope.PagetoRedirect = dataFactory.getPreviousPageName();
         localStorage.removeItem("pagename"); 

        dataFactory.setvisitor(undefined);
        $scope.phoneNumbr = /^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/; 
        $scope.oneMb = 1048576;

        $scope.visitorId = dataFactory.getvisitorId();
        $scope.companyId= dataFactory.getCompanyId(); 
        $scope.visitor= dataFactory.getvisitorObject(); 
       
        $scope.cancelVisitor=function(){
        	localStorage.removeItem("visitorId");
	    	localStorage.removeItem("companyId"); 
	    	 if($scope.PagetoRedirect == "SurveyResponse")
	    	 {
	    	 	$location.url("/survey/surveyresponse");
	    	 }
	    	 else if($scope.PagetoRedirect =="SurveyResponseDetails")
	    	 {
	    	 	 $location.url("/survey/responsedetail");
	    	 }
	    	else
	    	{
		    	dataFactory.setPreviousPageName("visitorpage");
	        	$location.url("/visitors")
        	}
        }

        setTimeout(function() {                  
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });

            $("#menu-toggle").click(function(e) {                        
            $(".content").toggleClass("toggled");
            e.preventDefault();
            });
             
            $("#menu-toggle").click(function(e) {            
            $("#sidebar").toggleClass("toggled");
            e.preventDefault();
            }); 

        }, 1500);

        
        if($scope.visitorId!=undefined)
        {
        	
	        visitorService.getVisitorDetails($scope.visitorId).then(function(Response){	        	
	    		$scope.visitorProfile = Response; 
	    		if($scope.visitorProfile.Visitor_UUID==null&&$scope.visitorProfile.Visitor_UUID==undefined)
	    		{	    			
	    			 $scope.VisitorUUIDMsg=true;
	    			 $scope.PassMsg=true;
	    		}
	    		else{
	    			$scope.VisitorUUIDMsg=false;

	    				posService.getVisitorPass($scope.visitorProfile.Visitor_UUID).then(function(passdata){   	    					
    						if(passdata!==undefined)
    						{
    							$scope.Pass=passdata;
    							$scope.PassMsg=false;
    						}
    						else{
    							$scope.PassMsg=true;
    						}
    						
	    				});

	    				visitorService.getVisitorSurveyResponse($scope.visitor.Visitor_UUID).then(function(response){
	    					
					    			if(response.data.status==200)
					    			{
					    			   $scope.SurveyResponseMsg="";
					    			   $scope.SurveyResponse=response.data.data;
					    			   $scope.SurveyResponse.Visitor_Id=$scope.visitorProfile.Visitor_Id;
					    			   $scope.SurveyResponse.VisitorName=$scope.visitorProfile.Name;
					    			   $scope.SurveyResponse.UpdatedName=$scope.visitorProfile.Update_by;
					    			}
					    			else{
					    				$scope.SurveyResponse="No data is available.";
					    			}
		    			});
	    		}

	    		if($scope.visitor.SurevyResponseId==null &&$scope.visitor.SurevyResponseId==undefined)
	    			$scope.ResponseMsg=true;
	    		else
	    			$scope.ResponseMsg=false;

	    		  		
	    		 if(Response.VisitorNameCard != null)
	    		  {
	    			$scope.FileUpload = "data:image/JPEG;base64,"+Response.VisitorNameCard;
	    		  }
	    		  else
	    		  {
	    		  	$scope.FileUpload = "static/images/nameoncard.jpg";
	    		  }
	    		


	        });
         }
        if($scope.companyId!=undefined)
        { 	
	        visitorService.getVisitorDetails($scope.companyId).then(function(response){
	        	
	        	$scope.visitorProfile = response;
	        	$('#visitorcompany').focus();

	        })
        }
        $scope.setActiveTab = function(tabToSet) {      
          $scope.activeTab = tabToSet;
        }

         function suggest_country(term) {
			   var q = term.toLowerCase().trim();
			  return countryService.getSearchCountries(q).then(function(Response){
			 		if(Response.status == 200)
					{
						$scope.countryfilter = Response.data;
						var results =[];
						for (var i = 0; i < $scope.countryfilter.length; i++) {
						     var country = $scope.countryfilter[i];
						     if (country.Country_Name.toLowerCase().indexOf(q) !== -1)
						       results.push({
						         value: country.Country_Name,
						         // Pass the object as well. Can be any property name.
						         obj: country,
						         label: $sce.trustAsHtml(country.Country_Name)
						       });
						   }
						    $timeout(function() {  
						   		$(".ac-container").css("top","");
						   		$(".ac-container").css("left","");
							},200);
					 	return results;
					}
		 		});				
		  }
		  $scope.country_options = {
		    suggest: suggest_country,
		    on_select: function (selected) {
		    $scope.visitorProfile.Country_Code = selected.obj.Country_Name;
		  }
		  };
		   function suggest_company(term) {
			   var q = term.toLowerCase().trim();
			  return companyService.getCompanybyText(q).then(function(Response){
			 		if(Response.status == 200)
					{
						$scope.companyfilter = Response.data;
						var results =[];
						for (var i = 0; i < $scope.companyfilter.length; i++) {
						     var user = $scope.companyfilter[i];
						     if (user.Company_Name.toLowerCase().indexOf(q) !== -1)
						       results.push({
						         value: user.Company_Name,
						         // Pass the object as well. Can be any property name.
						         obj: user,
						         label: $sce.trustAsHtml(user.Company_Name)
						       });
						   }
						    $timeout(function() {  
						   		$(".ac-container").css("top","");
						   		$(".ac-container").css("left","");
							},200);
					 	return results;
					}
		 		});				
		  }
		  $scope.company_options = {
		    suggest: suggest_company,
		    on_select: function (selected) {
		    	var company  = selected.obj;
		   	$scope.visitorProfile.Company_No = company.Company_No;
		   	$scope.visitorProfile.Address = company.Address;
		   	$scope.visitorProfile.Phone = company.Phone;
		   	$scope.visitorProfile.Phone_Ext = company.Phone_Ext;
		   	$scope.visitorProfile.Fax = company.Fax;
		   	$scope.visitorProfile.Website = company.Website;
		   	$scope.visitorProfile.Email = company.Email;
		   	$scope.visitorProfile.Company_Id = company.Company_Id;
		  }
		  };
        $scope.gotovisitors= function()
		 {			 	
			 	visitorService.UpdateVisitor($scope.visitorProfile).then(function(Response){
				 		if(Response.data.status === 200)
				 		{				 		
				 			if($scope.NewFileUpload != null)
				 			{
						 		visitorService.updateMedia($scope.visitorProfile.Visitor_Id , $scope.dataURItoBlob($scope.FileUpload)).then(function(ResponseMedia){	
						 			if(ResponseMedia.status === 200)
						 			{
							 			$scope.visitorProfile.isupdated = true;	
							 			$scope.visitorProfile.profilestatus="iscreated";						 			
							 			dataFactory.setvisitorProfile($scope.visitorProfile);							 			
							 			$location.url("/visitors");
							 			$scope.$apply();
						 			}
					 			});
					 		}
				 			else
				 			{
				 				$scope.visitorProfile.isupdated = true;
				 				$scope.visitorProfile.profilestatus="iscreated";
							 	dataFactory.setvisitorProfile($scope.visitorProfile);
				 				$location.url("/visitors");
				 			}
				 		}
			 		});
		 }
		 //$location.url("/visitors");
		 $scope.deleteVisitor= function(){
		 	visitorService.deleteVisitor($scope.visitorProfile.Visitor_Id).then(function(Response){
		 		if(Response.data.status == 200)
		 		{
		 			$scope.visitorProfile.isupdated = false;
		 			$scope.visitorProfile.profilestatus="isdeleted";
		 			dataFactory.setvisitorProfile($scope.visitorProfile);
		 			$location.url("/visitors");
		 		}

		 	});
		 }

		  $scope.fileNameChanged=function(evt, type) {   
		  	var file=evt.currentTarget.files[0];
		  	if(file.size <= $scope.oneMb)
		  	{
			  	var reader = new FileReader();		  	
			  	reader.onload = function (evt) {
			           $scope.$apply(function($scope){        
			             $scope.FileUpload=evt.target.result;   
			             $scope.NewFileUpload=evt.target.result; 		              
			           });
			           
			         };
			          reader.readAsDataURL(file);
		    }
		    else
		    {
		    	alert("Image size should not be more then 1mb.");
		    }
		  }

		  $scope.dataURItoBlob=function(dataURI) {
			    // convert base64/URLEncoded data component to raw binary data held in a string
			    var byteString;
			    if (dataURI.split(',')[0].indexOf('base64') >= 0)
			        byteString = atob(dataURI.split(',')[1]);
			    else
			        byteString = unescape(dataURI.split(',')[1]);

			    // separate out the mime component
			    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

			    // write the bytes of the string to a typed array
			    var ia = new Uint8Array(byteString.length);
			    for (var i = 0; i < byteString.length; i++) {
			        ia[i] = byteString.charCodeAt(i);
			    }

			    return new Blob([ia], {type:mimeString});
			};

				 $scope.SurveyResoponsesDetail=function(survey){
				 				            
			            dataFactory.setsurveyresponsedata(survey);
	                    dataFactory.setSurveyPage("visitorprofile");  
						$location.url("/survey/responsedetail");   
			    }			
	  
 })}
	);