define(function(require){
	angular.module("app").controller("surveydetailCtrl",function($window,$q,apiService,$sce,eventService,surveyService,$scope,$location,mwFormResponseUtils,$state,$rootScope,dataFactory,$timeout){
   		$scope.activeTab = 1;
        $scope.formBuilder={};    
        $scope.FormID = dataFactory.getsurveyformId();
        $scope.serveyDetails = {};
        $scope.errorMessage = '';
        $scope.PageName=dataFactory.getSurveyPage();
        $scope.survaydetailssuccessmessage = false;
          $scope.surveyStatus = [
              { "SurveyTypeID": 1, "Name": "Draft" },
              { "SurveyTypeID": 2, "Name": "Online" },
              { "SurveyTypeID": 3, "Name": "Offline" },
              { "SurveyTypeID": 4, "Name": "Closed" },
     ];
        $scope.optionsBuilder={
            /*elementButtons:   [{title: 'My title tooltip', icon: 'fa fa-database', text: '', callback: ctrl.callback, filter: ctrl.filter, showInOpen: true}],
            customQuestionSelects:  [
                {key:"category", label: 'Category', options: [{key:"1", label:"Uno"},{key:"2", label:"dos"},{key:"3", label:"tres"},{key:"4", label:"4"}], required: false},
                {key:"category2", label: 'Category2', options: [{key:"1", label:"Uno"},{key:"2", label:"dos"},{key:"3", label:"tres"},{key:"4", label:"4"}]}
            ],*/
            elementTypes: ['question'],
            questionTypes:['text','textarea','radio','checkbox','select']
        };

        setTimeout(function() {                  
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
            $("#menu-toggle").click(function(e) {                        
            $(".content").toggleClass("toggled");
            e.preventDefault();
            });             
            $("#menu-toggle").click(function(e) {            
            $("#sidebar").toggleClass("toggled");
            e.preventDefault();
            });          

        }, 3000);
        $scope.formData = {};

		$scope.formStatus= {};
		$scope.builderReadOnly = false;
        $scope.setActiveTab = function(tabToSet) {

          $scope.activeTab = tabToSet;
        }

        $scope.backtosurvey = function()
    		 {
           if($scope.PageName=="survey")
           {
            $location.url("/surveys");
           }        		 	      
            else if($scope.PageName=="surveyres")
            {
                $location.url("/survey/surveyresponse");
            }  
             else if($scope.PageName=="surveyresponsedetail")
             {
                $location.url("/survey/responsedetail")
             }
    		 }

		 $scope.SaveSurvey = function()
		 {
		 	
		 	$scope.formData.name = $scope.serveyDetails.Survey_Name;
		 	$scope.formData.pages[0].pageFlow.nextPage = false;		
		 	$scope.formData.pages[0].pageFlow.label ='mwForm.pageFlow.submitForm';
		 	$scope.serveyDetails.Data_Fields =  JSON.stringify($scope.formData);
		 	surveyService.updateSurvey($scope.serveyDetails).then(function (data) {
		 		
		 		if(data.status == 200)
		 		{
		 			$scope.survaydetailssuccessmessage = true;
	 			}
		 		else
		 			$scope.errorMessage = data.err_msg;

		 		$timeout(function(){
		 				$scope.survaydetailssuccessmessage = false;
		 				$scope.errorMessage ='';
		 		},5000);

		 	});
		 }
		 $scope.GetSurveyDetails = function()
		 {
		 	surveyService.getSurveyFormDetails($scope.FormID).then(function (data) {
		 		$scope.serveyDetails = data.data;
		 		$scope.serveyDetails.EvenSelected=$scope.serveyDetails.EventName;
		 		if($scope.serveyDetails.Data_Fields != null)
		 			$scope.formData = JSON.parse($scope.serveyDetails.Data_Fields);
		 	});
		 }

		 $scope.surveypreview = function()
		 {
		 	$scope.formData.name = $scope.serveyDetails.Survey_Name;
		 	$scope.formData.pages[0].pageFlow.nextPage = false;		
		 	$scope.formData.pages[0].pageFlow.label ='mwForm.pageFlow.submitForm';
		 	$scope.serveyDetails.Data_Fields =  JSON.stringify($scope.formData);
		 	dataFactory.setsurveyformdata($scope.formData);
		 	surveyService.updateSurvey($scope.serveyDetails).then(function (data) {
		 		if(data.status == 200){
		 			/*$location.url("/survey/surveypreview");*/
		 		    var SurveyPreviewURL = '#' + '/survey/surveypreview';
		 			window.open(SurveyPreviewURL,'_blank');
		 		}
		 		else{
		 			$scope.errorMessage = data.err_msg;
		 		}

		 	});		 			 
		 }
		 function suggest_event(term) {
               var q = term.toLowerCase().trim();
                    return eventService.getEventbyText(q).then(function(Response){
                            if(Response.status == 200)
                            {
                                $scope.eventfilter = Response.data;
                                var results =[];
                                for (var i = 0; i < $scope.eventfilter.length; i++) {
                                     var user = $scope.eventfilter[i];
                                     if (user.Name.toLowerCase().indexOf(q) !== -1 || user.Event_Code.toLowerCase().indexOf(q)!==-1)
                                       results.push({
                                        value: user.Event_Code + "-"+ user.Name,
                                          
                                         // Pass the object as well. Can be any property name.
                                         obj: user,
                                         label: $sce.trustAsHtml(user.Event_Code + "-"+ user.Name)
                                       });
                                   }
                                    $timeout(function() {  
                                        $(".ac-container").css("top","");
                                        $(".ac-container").css("left","");
                                    },200);
                                return results;
                            }
                    });  
            }           
          
         $scope.autocomplete_options = {
            suggest: suggest_event,
            on_select: function (selected) {
                $scope.serveyDetails.Name = selected.obj.Name;
                $scope.serveyDetails.Event_Id = selected.obj.Event_Id;
                $( "#surveyName" ).focus();
             }
          };
		 $scope.GetSurveyDetails();
	  
 })}
	);