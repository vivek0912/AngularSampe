define(function(require){
	angular.module("app").controller("addsurveyCtrl",function($window,$q,UtilsService,apiService,eventService,$sce,surveyService,$scope,$location,mwFormResponseUtils,$state,$rootScope,dataFactory,$timeout){
   		$scope.activeTab = 1;
        $scope.formBuilder={};    
        $scope.FormID = dataFactory.getsurveyformId();
        $scope.serveyDetails ={}; 
        $scope.serveyDetails.Status  = 1;
        $scope.EvenSelected;
        $scope.SurvayPublicLink =UtilsService.SurveyPublicURl	
        $scope.serveyDetails.SurveyLink = UtilsService.SurveyPublicURl;
         $scope.eventfilter={};
          $scope.surveyStatus = [
              { "SurveyTypeID": 1, "Name": "Draft" },
              { "SurveyTypeID": 2, "Name": "Online" },
              { "SurveyTypeID": 3, "Name": "Offline" },
              { "SurveyTypeID": 4, "Name": "Closed" },
     ];
        
        $scope.ActiveEvents ={};
        eventService.getEvents().then(function(data){	
        	 if(data.status == 200)
	  			$scope.ActiveEvents = data.data;
	  		 else 
	  		 	$scope.ActiveEvents = {};
	  	  });
        $scope.errorMessage = '';
        $scope.survaydetailssuccessmessage = false;
        $scope.optionsBuilder={
            /*elementButtons:   [{title: 'My title tooltip', icon: 'fa fa-database', text: '', callback: ctrl.callback, filter: ctrl.filter, showInOpen: true}],
            customQuestionSelects:  [
                {key:"category", label: 'Category', options: [{key:"1", label:"Uno"},{key:"2", label:"dos"},{key:"3", label:"tres"},{key:"4", label:"4"}], required: false},
                {key:"category2", label: 'Category2', options: [{key:"1", label:"Uno"},{key:"2", label:"dos"},{key:"3", label:"tres"},{key:"4", label:"4"}]}
            ],*/
            elementTypes: ['question'],
            questionTypes:['text','textarea','radio','checkbox','select']
        };
        
        $scope.formData = {};

		$scope.formStatus= {};
		$scope.builderReadOnly = false;
        $timeout(function(){
            $scope.formData.pages[0].pageFlow.nextPage = false;     
            $scope.formData.pages[0].pageFlow.label ='mwForm.pageFlow.submitForm';
        },3000);

        $scope.eventSelected = function(){         
        	if($scope.EvenSelected.Event_Code != undefined)
        	{
        		$scope.serveyDetails.Event_Id = $scope.EvenSelected.Event_Id;
        		$scope.serveyDetails.SurveyLinkID = $scope.EvenSelected.Event_Code;
        		$scope.SurvayPublicLink = $scope.serveyDetails.SurveyLink + $scope.EvenSelected.Event_Code; 
        	}
        	
        }

        $scope.setActiveTab = function(tabToSet) {  
          $scope.activeTab = tabToSet;
        }

        $scope.backtosurvey = function()
		 {
			$location.url("/surveys");
		 }		

		$scope.SaveSurvey = function()
		{     
			$scope.formData.name = $scope.serveyDetails.Survey_Name;            
            $scope.formData.pages[0].pageFlow.nextPage = false;     
            $scope.formData.pages[0].pageFlow.label ='mwForm.pageFlow.submitForm';
			$scope.serveyDetails.Data_Fields =  JSON.stringify($scope.formData);		
			surveyService.AddSurvey($scope.serveyDetails).then(function (data) {
        
	        	if(data.status == 200)
	        	{
              localStorage.removeItem("surveyFormObj");
              $scope.serveyDetails.surveyStatus="addsurvey";
              dataFactory.setsurveyformObj($scope.serveyDetails)
	        		$location.url("/surveys");
	        	}
	        	else
  	    		{
  	    			$location.url("/surveys");
  	    		}
	        });
		}
          function suggest_event(term) {
            
               var q = term.toLowerCase().trim();
                    return eventService.getEventbyText(q).then(function(Response){
                       
                            if(Response.status == 200)
                            {
                              
                                $scope.eventfilter = Response.data;
                                var results =[];                                
                                for (var i = 0; i < $scope.eventfilter.length; i++) {

                                     var user = $scope.eventfilter[i];
                                     //if(user.Name.toLowerCase().indexOf(q) !== -1)
                                      
                                       results.push({
                                         value: user.Name,
                                          
                                         // Pass the object as well. Can be any property name.
                                         obj: user,

                                         label: $sce.trustAsHtml(user.Event_Code + "-"+ user.Name)                                        

                                       });
                                   }
                                    $timeout(function() {  
                                        $(".ac-container").css("top","");
                                        $(".ac-container").css("left","");
                                    },200);
                                return results;
                            }
                    });  
            }           
          
         $scope.autocomplete_options = {
            suggest: suggest_event,
            on_select: function (selected) {
              
                $scope.serveyDetails.Name = selected.obj.Name;
                $scope.serveyDetails.Event_Id = selected.obj.Event_Id;
                $( "#surveyName" ).focus();
             }
          };

 })
});