define(function(require){
angular.module("app").controller("surveyresponseCtrl",function($window,surveyService,$scope,$location,$state,$rootScope,$timeout,dataFactory,$translate){

          $scope.SurveyFormObj=dataFactory.getsurveyformObj();
          

             localStorage.removeItem("pagename"); 

            $scope.addsurvey = function()
            {
              $location.url("/survey/addsurvey");
            }

            $scope.gotocompany = function()
            {
             $location.url("/company/addcompany");
            }

            $scope.backtosurvey = function()
            {
               
               $location.url("/surveys");
            }

            $scope.ExporttoExcel = function(){           
              if($scope.surveyresponses.length > 0) {
                surveyService.excelExportresponse($scope.SurveyFormObj.Form_Id).then(function (data) {
                  if(data.status == 200)
                  {                   
                    var blob = new Blob([data.data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});  
                    saveFile( $scope.SurveyFormObj.Survey_Name, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", blob);
                    //var objectUrl = URL.createObjectURL(blob);                   
                    //window.open(objectUrl);
                  }
                });
              }              
            }

            function saveFile (name, type, data) {
            if (data != null && navigator.msSaveBlob)
                return navigator.msSaveBlob(new Blob([data], { type: type }), name);
            var a = $("<a style='display: none;'/>");
            var url = window.URL.createObjectURL(new Blob([data], {type: type}));
            a.attr("href", url);
            /*a.attr("download", name);*/
            a.attr("download", name +".xlsx");
            $("body").append(a);
            a[0].click();
            window.URL.revokeObjectURL(url);
            a.remove();
            }

         $scope.VisitorProfilc = function(Visitor_Id)
              {        
                dataFactory.setPreviousPageName("SurveyResponse");
                dataFactory.setvisitorId(Visitor_Id);
                $location.url("/survey/visitorprofile");
              }
         var noitemfounds = "";
         var searchtext = "";

                 $translate(['itemnotfound']).then(function (translations) {
                              noitemfounds = translations.itemnotfound;                      
                            });
                  $translate(['searchsurveyresponse']).then(function (translations) {
                              searchtext = translations.searchsurveyresponse;                      
                 });
                 
         $scope.GetSurveyResponseDetails = function(){   
                surveyService.getSurveyResponse($scope.SurveyFormObj.Form_Id).then(function (data) {

                  if(data.status==200)
                  {
                        $scope.surveyresponses = data.data;  
                         $timeout(function() {  
                                   $scope.surveyresponseDatatable = $('#surveyresponseTable').DataTable( {   
                                        "paging":   true,              
                                        "info":     true,
                                        "searching": true,
                                        "pageLength":10,
                                        "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                                         language: {
                                          emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                              searchPlaceholder: searchtext,
                                              search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                              infoFiltered: " "
                                          }       
                                    } );
                                      $('#surveyresponseTable').wrap('<div class="responsive-datatable" />');

                          },200); 
                   }   
               

                })

                //$scope.GetUserDetail();
          }


            $scope.GetUserDetail=function(){
            //$scope.Updated_By
             surveyService.getUser($scope.Updated_By).then(function(data){            
              $scope.user=data.data.data;
                    })
              }

          
          $scope.viewResponseDetail = function (surveyresponse) {
            
                dataFactory.setsurveyresponsedata(surveyresponse);
                 dataFactory.setSurveyPage("responsedetail");
                $location.url("/survey/responsedetail");
            }

            $scope.gotosurveydetail=function(formId){
              //alert($scope.formId);
               dataFactory.setsurveyformId(formId);
               dataFactory.setSurveyPage("surveyrespage");
              $location.url("/survey/surveydetail");
            }
            $scope.gotoUserProfile=function(surveyresponse){
                if(surveyresponse.Updated_By !== undefined && surveyresponse.Updated_By!=null)
                {
                    var userid=parseInt(surveyresponse.Updated_By);
                    localStorage.removeItem("pagename");   
                     dataFactory.setPreviousPageName("SurveyResponse");
                    dataFactory.setUserId(userid);
                    $location.url("/user/userprofile"); 
                }
            }

           $scope.GetSurveyResponseDetails();   
	  
 })}
);