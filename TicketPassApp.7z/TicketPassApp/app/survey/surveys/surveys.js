define(function(require){
angular.module("app").controller("surveysCtrl",function($window,surveyService,eventService,apiService,$sce,$scope,$location,$state,$rootScope,$timeout,$translate,session,dataFactory){
          $scope.surveyResult=[];
          $scope.count='no item selected';
          $scope.surveydeleted = false;
          $scope.deletedsurveys =[];
          $scope.surveymessageshow = false;
          $scope.pausemessageshow=false;
          $scope.errorDeleteMessage =='';
          $scope.showeerror = false;
           $scope.surveycreated=false;
          $scope.confirmdelete=[];
          $scope.action='';
          $scope.IsPause=true;
          $scope.filtered=[];
          $scope.Events={};
          $scope.EventResult=[];
          $scope.surveyFromObj=dataFactory.getsurveyformObj()
          localStorage.removeItem("allvisitor"); 
          localStorage.removeItem("alluser")
          localStorage.removeItem("allexhibitor");
          localStorage.removeItem("eventtype"); 

          if($scope.surveyFromObj!==undefined && $scope.surveyFromObj!=null)
          {
              if($scope.surveyFromObj.surveyStatus=="addsurvey")
              {
                    $scope.surveycreated=true;
                    $scope.EventName=$scope.surveyFromObj.Name;
                    $scope.SuyveyName=$scope.surveyFromObj.Survey_Name;
                     $timeout(function () { $scope.surveycreated=false;dataFactory.setsurveyformObj(null)}, 3000);
              }
          }
          
          var Pause=false;
            $scope.eventStatus = [
              { "EventTypeID": "open", "Name": "Open"},
              { "EventTypeID": "all", "Name": "All"},
              { "EventTypeID": 1, "Name": "Draft" },
              { "EventTypeID": 2, "Name": "Online" },
              { "EventTypeID": 3, "Name": "Offline" },
              { "EventTypeID": 4, "Name": "Closed" },
     ];

	 $scope.addsurvey = function()
	 {
	     $location.url("/survey/addsurvey");
	 }

    var noitemfounds = "";
    var searchtext = "";
         $translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
                    });
            $translate(['searchsurvey']).then(function (translations) {
                      searchtext = translations.searchsurvey;                      
                   });

 $scope.gotocompany = function()
 {
 $location.url("/company/addcompany");
 }
    setTimeout(function() {                  
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });

            $("#menu-toggle").click(function(e) {                        
            $(".content").toggleClass("toggled");
            e.preventDefault();
            });
             
            $("#menu-toggle").click(function(e) {            
            $("#sidebar").toggleClass("toggled");
            e.preventDefault();
            });
             

        }, 1500);
           
              eventService.getactiveEvents().then(function(response){
                $scope.Events=response.data;
              })
            

            $scope.GetSurveyDetails = function(){   
                  
                surveyService.getSurveys().then(function (data) {
                $scope.surveys = data.data;  
                $scope.surveyResult=$scope.surveys; 
                localStorage.setItem("surveyobj", JSON.stringify($scope.surveys)); 
                $scope.EventSelected="open";  
                $scope.SearchByEvent( $scope.EventSelected); 
                if(!$scope.surveydeleted)
                {
                  if($scope.pausemessageshow)
                  {
                    $scope.count = "no item selected";               
                if($scope.surveyDatatable!=null && $scope.surveyDatatable!=undefined && $scope.surveyDatatable!=""){
                       $scope.surveyDatatable.destroy();  
                    }

                   /*$timeout(function() {  
                   $scope.surveyDatatable = $('#surveyTable').DataTable( {   
                   "paging":   true,              
                        "info":     true,
                         "searching": true,
                         "pageLength":10,
                         "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                         language: {
                          emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                            searchPlaceholder: searchtext,
                            search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                            infoFiltered: " "
                          }       
                } );

                   },0);*/
                  }
                  else
                  {
                    /*$timeout(function() {  
                   $scope.surveyDatatable = $('#surveyTable').DataTable( {   
                   "paging":   true,              
                        "info":     true,
                         "searching": true,
                         "pageLength":10,
                         "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                         language: {
                          emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                              searchPlaceholder: searchtext,
                              search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                              infoFiltered: " "
                          }       
                } );

                   },200);  */  
                  }
                  
                   
                }
                else
                {
                  $scope.count = "no item selected";
                
                  if($scope.surveyDatatable!=null && $scope.surveyDatatable!=undefined && $scope.surveyDatatable!=""){
                       $scope.surveyDatatable.destroy();  
                    }

                   $timeout(function() {  
                   $scope.surveyDatatable = $('#surveyTable').DataTable( {   
                       "paging":   true,        
                       "info":     true,      
                         "searching": true,
                         "pageLength":10,
                         "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                         language: {
                          sInfo: 'Showing _END_ Sources.',
                          emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                            searchPlaceholder: searchtext,
                            search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                            infoFiltered: " "
                          }       
                } );

                   },0);    
                }
                $scope.surveydeleted = false;
                })
          }


              $scope.ReloadSurveyTable = function(){
                         
                            if($scope.surveyDatatable!=null && $scope.surveyDatatable!=undefined && $scope.surveyDatatable!=""){
                              $scope.surveyDatatable.destroy();  
                            }

                            $timeout(function() { 
                                 $scope.surveyDatatable = $('#surveyTable').DataTable( {  
                                    "paging":   true,             
                                    "info":     true,
                                    "searching": true,
                                    "pageLength":10,
                                    "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                                    language: {
                                      sInfo: 'Showing _END_ Sources.',
                                      emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                        searchPlaceholder: searchtext,
                                              search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                              infoFiltered: " "
                                    }                                 
                                });
                            },0); 
                        }
                   

            $scope.GetSurveyDetails();
            //$scope.ShowUpdateMessage();

              $scope.deleteMultipleSurvey=function(){
                
                        var list = $scope.surveyResult.filter(function (obj) {
                            if (obj.checked !== undefined && obj.checked === true) {
                                return obj;
                            }
                        });
                        if(list.length==1)
                          $scope.singleItemSelected=true;
                        else
                          $scope.singleItemSelected=false;
                  if(list.length > 0)
                  {
                      surveyService.deletemMultipleSurvey(list).then(function(Response){
                      $scope.deletedsurveys ="";

                      angular.forEach(list, function(value){
                        
                        $scope.deletedsurveys += value.Survey_Name+',';
                        if(list.length==1)
                           $scope.EventName=value.EventName;
                      });
                      $scope.deletedsurveys= $scope.deletedsurveys.substring(0, $scope.deletedsurveys.length - 1);

                      if(Response.data.status === 200)
                      {
                        surveyService.getSurveys().then(function (data) {    
                                    $scope.surveyResult=data.data; 
                                     $scope.ReloadSurveyTable();
                                }); 
                        //$scope.GetSurveyDetails();
                        $scope.ShowDeletedMessage();              
                      }
                      else
                      {
                        $scope.showErrorMessage(Response.data.err_msg);
                      }


                    });
                 }

            }

              
              $scope.deleteSurvey=function(surveyfordelete){  
               $scope.confirmdelete = surveyfordelete;
                  $('#confirmModal').modal('show');  
                  }

                     
              $scope.deleteconfirmSurvey=function() 
               {
                
                      $('#confirmModal').modal('hide');  
                      $scope.deletedsurvey=$scope.confirmdelete.Survey_Name;
                      $scope.EventName=$scope.confirmdelete.EventName;
                      //alert($scope.confirmdelete.Form_Id);
                      surveyService.deleteSurvey($scope.confirmdelete.Form_Id).then(function(Response){
                       if(Response.data.status === 200)
                         {      
                           //alert('deleted');
                             surveyService.getSurveys().then(function (data) {    
                                  $scope.surveyResult=data.data; 
                                   $scope.ReloadSurveyTable();
                              }); 
                              //$scope.GetSurveyDetails();   
                              $scope.surveymessageshow = true; 
                              $timeout(function () {$scope.surveymessageshow = false; }, 3000);                       
                         }
                         else
                         {
                           $scope.showErrorMessage(Response.data.err_msg);
                         }
                      });
                     }


                  //   $scope.deleteSurvey = function(surveyfordelete){
                  //        var isConfirmed = confirm("Are you sure to delete this record ?");
                  //        if(isConfirmed){
                  //           
                  //           $scope.deletedsurveys.push(surveyfordelete);
                  //        surveyService.deleteSurvey(surveyfordelete.Form_Id).then(function(Response){
                  //       if(Response.data.status === 200)
                  //       {      
                  //          //alert('deleted');
                  //           $scope.GetSurveyDetails();   
                  //           $scope.ShowDeletedMessage();                            
                  //       }
                  //       else
                  //       {
                  //         //alert('error occured ');
                  //           $scope.showErrorMessage(Response.data.err_msg);
                  //       }

                  //   });
                  //        }
                  //        else
                  //        {
                  //           return false;
                  //        }

                     
                  // }


                $scope.surveyCheckedchanged = function(){
                 var list = $scope.surveyResult.filter(function (obj) {
                            if (obj.checked !== undefined && obj.checked === true) {
                                return obj;
                            }
                        });
                if(list.length == 1)
                  $scope.count = list.length + " item selected";
                else if (list.length > 1)
                  $scope.count = list.length + " items selected";
                else 
                  $scope.count = 'no item selected';
              }


            $scope.ShowDeletedMessage = function(){
              
                  if($scope.singleItemSelected==true)
                    $scope.deletedSingleVisitor=true;
                  else
                    $scope.deletedMultiple=true;
               
                $timeout(function () {
                  $scope.deletedSingleVisitor=false;
                  $scope.deletedMultiple=false;
              }, 3000);
              }

              $scope.showErrorMessage = function(message){
                  $scope.errorDeleteMessage = message;
                  $scope.showeerror = true;
                 $timeout(function () {
                  $scope.errorDeleteMessage = '';
                  $scope.showeerror = false;
              }, 3000);
              }

   

            $scope.viewSurveyProfile = function (formId) {                 
                 dataFactory.setsurveyformId(formId);
                 dataFactory.setSurveyPage("survey");
                 $location.url("/survey/surveydetail");
            }

            $scope.surveyresponse = function(form)
             {
               localStorage.removeItem("surveyFormObj");
                dataFactory.setsurveyformObj(form);
                $location.url("/survey/surveyresponse");
              }

              //pausing survey...
                $scope.pauseSurvey=function(survey){
                     
                        var surveyName=survey.Survey_Name;
                        if(survey.IsPause==true)
                        {
                            survey.IsPause=false;
                            $scope.action= surveyName + " is played";
                        }
                        else{
                            survey.IsPause=true;
                            $scope.action= surveyName + " is paused";
                        }
                        
                        //alert(surveyName);
                        surveyService.updateSurvey(survey).then(function (response){
                             if(response.status === 200)
                              {
                                    $scope.pausemessageshow=true;                                    
                                    //$scope.hideSuccess=false;
                                     //$scope.pausemessageshow=true;
                                    //$scope.SuccessMessage=  userName;
                                    surveyService.getSurveys().then(function (data) {    
                                        $scope.surveyResult=data.data; 
                                         $scope.ReloadSurveyTable();
                                    }); 
                                    $timeout(function () { $scope.pausemessageshow = false; }, 4000);
                                     
                              }
                              else
                              {
                                  $scope.showErrorMessage(response.data.err_msg);
                              }
                                                          
                        });
                }
                $scope.SearchByEvent = function(selected)
                {
                   $scope.surveys=JSON.parse(localStorage.getItem("surveyobj"));  
                    if(selected!=undefined)
                      $scope.EventSelected=selected;
                   
                    if($scope.EventSelected != null)
                    {
                      if($scope.EventSelected=="open")
                      {
                       
                        $scope.surveyResult = $scope.surveys.filter(function (obj) {
                                if (obj.Status ==2) {
                                    return obj;
                                }
                            });
                      }
                      else if($scope.EventSelected=="all"){
                        $scope.surveyResult = $scope.surveys.filter(function (obj) {
                          
                                    return obj;
                                
                            });
                      }
                      else
                      {
                        $scope.surveyResult = $scope.surveys.filter(function (obj) {
                          
                                if (obj.Status === $scope.EventSelected) {
                                    return obj;
                                }
                            });
                      }

                        
                    }
                    else 
                    {
                        $scope.surveyResult = $scope.surveys;
                    }                      

                     if($scope.surveyDatatable!=null && $scope.surveyDatatable!=undefined && $scope.surveyDatatable!=""){
                              $scope.surveyDatatable.destroy();  
                            }

                           $timeout(function() {  
                           $scope.surveyDatatable = $('#surveyTable').DataTable( {   
                           "paging":   true,              
                                "info":     true,
                                 "searching": true,
                                 "pageLength":10,
                                 "lengthMenu": [[10, 20, 30], [10, 20, 30]],
                                 language: {
                                  emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
                                    searchPlaceholder: searchtext,
                                    search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
                                    infoFiltered: " "
                                  }       
                        } );

                           },0);

                  }

             
 })}
	);