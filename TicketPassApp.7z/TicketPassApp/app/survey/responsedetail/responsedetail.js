define(function(require){
	angular.module("app").controller("responsedetailCtrl",function($window,apiService,$scope,$timeout,$location,$state,$rootScope,surveyService,dataFactory,mwFormResponseUtils,$q){
   $scope.activeTab = 1;  
    $scope.responseDetails = dataFactory.getsurveyresponsedata();
    $scope.viewerReadOnly = true;   
    $scope.formViewer ={};
    $scope.updatedsucess = false;
    $scope.updatederror = false;
    $scope.errorMessage='';
	$scope.formOptions = {
	    autoStart: true
	};
	$scope.formStatus= {};

	$scope.responseData =JSON.parse($scope.responseDetails.Response);
	$scope.formData = JSON.parse($scope.responseDetails.SurveyFormData);
	$scope.VisiterId = $scope.responseDetails.Visitor_Id;
	$scope.saveSurveyResponse = function()
	 {	
	 	$scope.responseDetails.Response = JSON.stringify($scope.responseData);

	 	return surveyService.saveSurveyResponse($scope.responseDetails).then(function (data) {                
	 	 	if(data.status == 200)
	 	 	{
	 	 		$scope.updatedsucess = true;	 	 			 	 		
	 	 	}
	 	 	else
	 	 	{
	 	 		$scope.updatederror = true;	 	
	 	 		$scope.errorMessage = data.err_msg; 		
	 	 	}
	 	 	$timeout(function(){
	 	 		$scope.updatedsucess = false;
	 	 		$scope.updatederror = false;	 	 
	 	 	},3000);
	 	 	return true;
	 	 	
         })
       	
	 }
    $scope.setActiveTab = function(tabToSet) {      
      $scope.activeTab = tabToSet;
    }

    $scope.backtosurvey = function()
	 {
	 	var page=dataFactory.getSurveyPage(); 
	 	if(page=="visitorprofile")
	 		$location.url("/survey/visitorprofile");
	 	if(page=="surveyrespage")
	 		$location.url("/survey/surveyresponse");
	 	if(page=="responsedetail")
	 		$location.url("/survey/surveyresponse");
	 }

	 $scope.VisiterDetails = function()
	 {
	 	dataFactory.setPreviousPageName("SurveyResponseDetails");
	 	dataFactory.setvisitorId($scope.VisiterId);
	 	$location.url("/survey/visitorprofile");
	 }
	     $scope.gotosurveydetail=function(responseDetails){
           dataFactory.setsurveyformId(responseDetails.Form_Id);
           dataFactory.setSurveyPage("surveyresponsedetail");
          $location.url("/survey/surveydetail");
        }
	  
 })}
	);