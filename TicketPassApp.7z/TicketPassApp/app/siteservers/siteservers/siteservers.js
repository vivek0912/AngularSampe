define(function(require){
angular.module("app").controller("siteserversCtrl",function($window,usersService,apiService,$scope,$location,$state,$rootScope){
$scope.sucessmessage=false;

$scope.gotocompany = function()
 {
 $location.url("/company/addcompany");
 }

    setTimeout(function() { 
                 
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
             
             $("#menu-toggle").click(function(e) {                          
            e.preventDefault();
            $(".content").toggleClass("toggled");
            });
             
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar").toggleClass("toggled");
            });

        }, 3000);
            
	  setTimeout(function() {  
				  $(".submenu").addClass("in");
				  $(".Toggleonload").removeClass("collapsed");
				  $(".Toggleonload i").addClass("fa-angle-down");   
				
	 },200);
 })}
	);