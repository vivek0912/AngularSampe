define(function(require){
angular.module("app").controller("siteserverprofileCtrl",function($window,usersService,apiService,$scope,$location,$state,$rootScope,dataFactory){

	    
 
$scope.gotocompany = function()
 {
 $location.url("/company/addcompany");
 }
	  setTimeout(function() {  
				  $(".submenu").addClass("in");
				  $(".Toggleonload").removeClass("collapsed");
				  $(".Toggleonload i").addClass("fa-angle-down");   
				
				},200);
 })}
	);