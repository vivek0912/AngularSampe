define(function(require){
	angular.module("app").controller("integrationsCtrl",function($window,integrationService,apiService,$scope,$location,$state,$rootScope,$timeout){
	
			$scope.sucessmessage=false;
			$scope.gotocompany = function()
 			{
 				$location.url("/companies");
 			}
 			localStorage.removeItem("allvisitor"); 
     		localStorage.removeItem("alluser") 
     		localStorage.removeItem("allexhibitor");
     		localStorage.removeItem("eventtype"); 
    		setTimeout(function(){              
		           $('[data-toggle=collapse]').click(function(){
		            // toggle icon
		            $(this).find("i").toggleClass("fa-angle-down");
		            });
		             
		             $("#menu-toggle").click(function(e) {                          
		            e.preventDefault();
		            $(".content").toggleClass("toggled");
		            });
		             
		            $("#menu-toggle").click(function(e) {
		            e.preventDefault();
		            $("#sidebar").toggleClass("toggled");
		            });

		    }, 1500);
 
	  		setTimeout(function() {  
				  $(".systm-setting .submenu").addClass("in");
				 $(".systm-setting .Toggleonload").removeClass("collapsed");
				  $(".systm-setting .Toggleonload i").addClass("fa-angle-down");  
				
			},200);
			$('.numbers').keypress(validateNumber);

			function validateNumber(event) {
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46) {
        return true;
    } else if ( key < 48 || key > 57 ) {
        return false;
    } else {
    	return true;
    }
};

			//get integration data and bind input
			integrationService.getIntegration(1).then(function (data){
				$scope.integration=data.data.data;
			});
			$scope.saveIntegration=function(){
				integrationService.updateIntegration($scope.integration).then(function (data){
					if(data.status == 200){
						$scope.messageshow=true;
                        /*$scope.integrationmessage = "Integration is Saved Successfully"; */
					}
					$timeout(function () { $scope.messageshow = false;}, 3000);
				});
			}
 })}
	);