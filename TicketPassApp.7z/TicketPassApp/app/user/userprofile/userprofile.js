define(function(require){
angular.module("app").controller("userprofileCtrl",function($window,userService,apiService,$scope,$location, $rootScope,$timeout,dataFactory){
					$rootScope.islogin = false;
					$scope.hideSuccess=false;
					$scope.SuccessMessage='';
					$scope.currentPwd=false;
					$scope.checkPwd={};
					$scope.user={};
					$scope.show = true;
					$scope.hideNewPwd=false;
		            $scope.ShowNewPwd=false;
		            $scope.hidePwd=true;
		            $scope.ShowPwd=false;
		            $scope.hideCnfPwd=true;
		            $scope.ShowCnfPwd=false;
		            $scope.newPwd=false 
		            //$scope.validEmail={};
                    $scope.checkEmail=false;
                  $scope.downloadstatus=false;  
                  $scope.previousPageName=dataFactory.getPreviousPageName();      
					$scope.userid=dataFactory.getUserId();
					
					$scope.roleTypes = [
			              { "RoleTypeID": 1, "Name": "Admin" },
			              { "RoleTypeID": 2, "Name": "Normal User" },
			              { "RoleTypeID": 3, "Name": "POS User" },
			              { "RoleTypeID": 4, "Name": "POS Admin" },
		      		];
		      		$scope.userStatus = [
			              { "StatusId": 1, "Name": "Active" },
			              { "StatusId": 0, "Name": "In-Active" }
		      		];
				   	if($location.search().createUser)
				      {
				      	 
				          var data=$location.search().createUser;
				          $scope.SuccessMessage=data;
				          $timeout(function () { $scope.hideSuccess = true; }, 3000);

				          $location.search({}); 
				      }
					$scope.show = true;

		setTimeout(function() {                  
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
            $("#menu-toggle").click(function(e) {                        
            $(".content").toggleClass("toggled");
            e.preventDefault();
            });             
            $("#menu-toggle").click(function(e) {            
            $("#sidebar").toggleClass("toggled");
            e.preventDefault();
            }); 
        }, 1500);


					$timeout(function() {  
								  $(".submenu").addClass("in");
								  $(".Toggleonload").removeClass("collapsed");
								  $(".Toggleonload i").addClass("fa-angle-down");   
								
								},200);
					 
					


					userService.getUser($scope.userid).then(function (response) {					
									
					    	$scope.user = response.data.data;
					    	$scope.user.QRCode=parseInt($scope.user.QRCode);
					    	if(isNaN($scope.user.QRCode))
					    		$scope.user.QRCode=undefined;

					    	$scope.user.Mobile_Phone=parseInt($scope.user.Mobile_Phone);
					    	if(isNaN($scope.user.Mobile_Phone))
					    		$scope.user.Mobile_Phone=undefined;
					    		
					    	if(($scope.user.QRCode + '').length >= 6)
	                			$scope.QRCodeStatus = false;
	                			$scope.validEmail = false;
					    	$scope.ddlRoleId=response.data.data.Role;
                            $scope.user.Password =undefined; 
                            $scope.generadeQRCode($scope.user);     
			      	 }); 
					$scope.backToUser=function(){	
						if($scope.previousPageName=="SurveyResponse"){
							$location.url("/survey/surveyresponse");
						}        						
          				if($scope.previousPageName=="User"){	
          					$location.url("users");
          				}
					}
					
					//edit user profile
					$scope.updateUserProfile=function(user){							
						//check admin password field
 					if(user.Role==1 ||user.Role==2)
                    {
						if(($scope.user.AdminPassword!==undefined && $scope.user.AdminPassword!="" )|| ($scope.user.newPassword !==undefined 
							&& $scope.user.newPassword!="")|| ($scope.user.cnfPassword!==undefined && $scope.user.cnfPassword!=""))
						{
							if(!$scope.validEmail)
							{
								if($scope.adminPwdValid==true)
								{
									if($scope.user.newPassword===$scope.user.cnfPassword)
									{
										$scope.user.Password = $scope.user.newPassword;
										$scope.UpdateUser(user);
									}
									else{
										return false;
									}
								}
							}
							
						}
						else
						{
							if(!$scope.validEmail)
							{								
								$scope.UpdateUser(user);
							}
						}
					}
					else
					{
						 if(!$scope.QRCodeStatus && !$scope.validEmail)
                          {
                             
                              dataFactory.setRole($scope.user.RoleName);           
                              userService.saveUser($scope.user).then(function(response){
                              	
                              		if(response.data.status==200)
                              		{
                              $location.url('/users?edituser='+user.Name);
                          }
                              		else{
                              			$location.url('/users?IsMatchedData='+response.data.err_msg);
                              		}
                              		
                              });
					}
					}
						
					}

					$scope.UpdateUser=function(user){
						
						userService.saveUser(user).then(function(response){
							
							dataFactory.setRole($scope.user.RoleName);
							 if(response.data.status==200)
                              		{
							 $location.url('/users?edituser='+user.Name);
                              		}
                              		else{
                              			$location.url('/users?IsMatchedData='+response.data.err_msg);
                              		}
						})
					}
					
				
			    	$scope.deleteThisUser=function(user){
			    	    	      
			              userService.deleteUser(user.User_Id).then(function (data){
			              	
			                    if(data.data.status===200)
			                    {
			                    	dataFactory.setRole($scope.user.RoleName);
			                    	$location.url("/users?deleteUser="+user.Name);
			                    }
			                    else{
			                    	dataFactory.setRole($scope.user.Role);
			                    	$location.url("/users?notdeleteUser="+user.Name);
			                    }  
			                  
			              });            
			          }

			           $scope.viewUser = function (userId) {           	    	  
			           	   dataFactory.setUserId(userId);
			               $location.path("/user/userprofile");
			          }

					
					$scope.Adduser = function()
					 {
					 		$location.url("/user/adduser");
					 }

					 $scope.CheckPassword=function(user){

	                 				if($scope.user.AdminPassword===undefined)
	                 				{
	                 					$scope.hidePwd=false;
		                              	$scope.ShowPwd=true;
	                 				}
	                 				else
	                 				{
	                 					$scope.hidePwd=true;
		                              	$scope.ShowPwd=false;
	                 				}
		                          	$scope.checkPwd.User_Id= $rootScope.loginUser.User_id;
		                          	$scope.checkPwd.Password=$scope.user.AdminPassword;
		                          	userService.isValidPassword($scope.checkPwd).then(function(response){

		                            	if(response.data.data ===true)
		                            	{
		                            		$scope.adminPwdValid=true;
		                              		$scope.currentPwd=false;
		                              		$scope.hidePwd=false;
		                              		$scope.ShowPwd=false;

		                            	}
		                            	else{
		                                	$scope.currentPwd=true;
		                                	$scope.ShowPwd=true;
		                                	$scope.hidePwd=true;
		                            	}
		                      		});
		                   
	                               		
	             	}
	             	$scope.newPassword=function(){
	             	 
	             		var passPattern=/^[A-Za-z0-9 ]{7,18}$/;
	             		if($scope.user.newPassword!= undefined && passPattern.test($scope.user.newPassword))
	                 				{
	                 					$scope.hideNewPwd=false;
		                              	$scope.ShowNewPwd=true;
		            			if($scope.user.cnfPassword!= undefined)
								{ 
									$scope.hideCnfPwd=false;
				            		$scope.ShowCnfPwd=false;
								}
	                 				}
	                 				else
	                 				{
							if($scope.user.newPassword=="")
								$scope.hideNewPwd=false;
							else
	                 					$scope.hideNewPwd=true;
		                              	$scope.ShowNewPwd=false;
	                 				}
	             	}
	             	 $scope.cnfPassword=function(){
	             	 
	             		
	             		if($scope.user.cnfPassword!= undefined)
						{ 
							$scope.hideCnfPwd=false;
		            		$scope.ShowCnfPwd=false;
						}
						else
						{
							if($scope.user.cnfPassword=="" || $scope.user.cnfPassword===undefined)
							{
								$scope.hideCnfPwd=true;
								$scope.ShowCnfPwd=false;
							}
							else
								$scope.ShowCnfPwd=true;
		            		
						}
	             	}
	             	     //email validate
                    $scope.CheckEmail=function(){                    	
                    	var mobileRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

                          if($scope.user.Email!==undefined && mobileRegex.test($scope.user.Email))
                          {     

                                //$scope.validEmail.Email=$scope.user.Email;
                                userService.isExistEmail($scope.user).then(function(response){
                              	
                                    if(response.data.status==200)
                                    {
                                     $scope.validEmail=response.data.data;

                                    }
                                    
                              });
                          }
                          else
                          {
                            $scope.validEmail=false;
                          }

                    }  
                    $scope.IsRoleSelected=function(){                     
                      $scope.ddlRoleId=$scope.user.Role;                
                    }              
                    
                    $scope.ReloadQRCode=function(){
                        $scope.qrCodeString ='empty qr code'; 
                        $scope.size = 135;
                        $scope.version = '1';
                    }
                    $scope.generadeQRCode=function(user){           
                      if( user.QRCode!==undefined &&  user.QRCode!="")
                      {    
                        $scope.qrCodeString = user.QRCode.toString();            
                      $scope.size = 130;
                      $scope.correctionLevel = 'M';
                      $scope.version = '5';
                      $scope.status=false;
                    }
                        else
                        {
                          $scope.ReloadQRCode()
                        }

                    }
                  $scope.downloadQrCode=function(){
                    var url=$('.qrcode-link').attr('href');
                     var qrcodename=$scope.user.Name;
                    if(qrcodename===undefined)
                        var qrcodename='qrcode';
                    $(".qrcode").prop("href", url);
                    $(".qrcode").prop("download", qrcodename);
                  } 

                  $scope.IsValidQRCode = function(){    
                    if($scope.user.QRCode != undefined &&($scope.user.QRCode + '').length >= 6)
                    {
                        userService.IsValidQRCode($scope.user).then(function(data){
                          if(data.status == 200)
                          {
                            $scope.QRCodeStatus=data.data;
                          }
                        });
                    }
                  } 
                   $scope.FocusOut=function(user) {
		                $scope.generadeQRCode(user);
		   };
		   $scope.ReloadQRCode();      
           
                   
	                

    });	   	 
 })



