define(function(require){
angular.module("app").controller("usersCtrl",function($window,userService,apiService,$scope,$location,$rootScope,$translate,$timeout,dataFactory){
				$rootScope.islogin = false;
				$scope.hideSuccess=true;
				$scope.SuccessMessage='';
			    $scope.action='';
			    $scope.errorMessage ='';
	          	$scope.showeerror = false;
	          	$scope.matchedError=false;
	          	$scope.IsPause=true;
	          	$scope.UserResult=[];
	          	$scope.IsonLoad = false;
	          	localStorage.removeItem("eventtype"); 
	          	$scope.UserFilterType = [
		              { "RoleTypeId": "alluser", "Name": "All Users" },
		              { "RoleTypeId": "allposuser", "Name": "All POS related Users" },
		              { "RoleTypeId": 1, "Name": "Master Server Admin" },
		              { "RoleTypeId": 2, "Name": "Master Server Usres" },
		              { "RoleTypeId": 4, "Name": "POS Admin" },
		              { "RoleTypeId": 3, "Name": "POS User" },
     			];
     				

			   	if($location.search().createUser)
			    {	
			    	$scope.role=dataFactory.getRole(); 
			      	 $scope.action="is created";
			      	  $scope.hideSuccess=false;
			          var data=$location.search().createUser;
			          $scope.SuccessMessage=data;
			          $timeout(function () { $scope.hideSuccess = true; }, 3000)

			          $location.search({}); 
			    }
			    if($location.search().edituser)
			    {
			    	$scope.role=dataFactory.getRole();
			          $scope.action="is updated";
			          $scope.hideSuccess=false;
			          var data=$location.search().edituser;
			          $scope.SuccessMessage=data;
			          $timeout(function () { $scope.hideSuccess = true; }, 3000);
			          $location.search({}); 
			    }
			    if($location.search().deleteUser)
			    {
			    	$scope.role=dataFactory.getRole();
			          $scope.action="is deleted";
			          $scope.hideSuccess=false;
			          var data=$location.search().deleteUser;
			          $scope.SuccessMessage=data;
			          $timeout(function () { $scope.hideSuccess = true; }, 3000);
			          $location.search({}); 
			    }
			    if($location.search().notdeleteUser)
			    {
			      	var data=$location.search().notdeleteUser;
			         showErrorMessage(data);
			          $location.search({}); 
			    }
			    if($location.search().IsMatchedData)
				{
				      	var data=$location.search().IsMatchedData;
				        $scope.errorMessage = data;
		             	$scope.hideSuccess=true;
		             	$scope.matchedError = true;
		             	$timeout(function () { $scope.errorMessage = ''; $scope.matchedError = false;}, 3000);
				          $location.search({}); 
				}
			    var noitemfounds = "";
			    var searchtext = "";

         			$translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
                    });

                    $translate(['searchusers']).then(function (translations) {
                      searchtext = translations.searchusers;                      
        			 });


		        $scope.ReloadUsertable = function(){	
		         if($scope.userdatatable!=null && $scope.userdatatable!=undefined){
                     $scope.userdatatable.destroy();  
                    }

		          	$timeout(function() { 
		              	 $scope.userdatatable = $('#userTable').DataTable( {  
		                  	"paging":   true,             
		                    "info":     true,
		                    "searching": true,
		                    "pageLength":10,
		                    "lengthMenu": [[10, 20, 30], [10, 20, 30]],
		                    language: {
		                    	emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
		                        searchPlaceholder: searchtext,
							          search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
							           infoFiltered: " "
		                    }                                 
		              	});
		            },200); 
		            $('#userTable').wrap('<div class="responsive-datatable" />');
        		}

				$scope.show = true;
		 setTimeout(function() {  
				 $(".systm-setting .submenu").addClass("in");
				 $(".systm-setting .Toggleonload").removeClass("collapsed");
				 $(".systm-setting .Toggleonload i").addClass("fa-angle-down");
		 },200);
				
		 setTimeout(function() {                  
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
            $("#menu-toggle").click(function(e) {                        
            $(".content").toggleClass("toggled");
            e.preventDefault();
            });             
            $("#menu-toggle").click(function(e) {            
            $("#sidebar").toggleClass("toggled");
            e.preventDefault();
            }); 
        }, 1500);

				userService.getUsers().then(function (data) {
					    $scope.users = data.data;
					    localStorage.setItem("userobj", JSON.stringify($scope.users));

					    if((dataFactory.getAllUser()===undefined || dataFactory.getAllUser()==null) && 
					    	(dataFactory.getUserRole()===undefined ||dataFactory.getUserRole()==null)){
					    	$scope.UserSelected="alluser";
					    }
					    else{
					    	$scope.UserSelected=dataFactory.getAllUser();
					    }	

					   $scope.IsonLoad == true;
					    $scope.SearchByEvent($scope.UserSelected);
					    if( $scope.IsonLoad == true) {
					    	localStorage.removeItem("userrole");
							   setTimeout(function() {  
									$scope.userdatatable = $('#userTable').DataTable( {	
										    "paging":   true,				      
									        "info":     true,
									         "searching": true,
									         "pageLength":10,
									         "lengthMenu": [[10, 20, 30], [10, 20, 30]],
									           language: {
									           	emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
											        searchPlaceholder: searchtext,
											          search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
											          infoFiltered: " "
											    }
									         	  
										});
									
									 $('#userTable').wrap('<div class="responsive-datatable" />'); 

							           },200);    
					    }  
			     });  
			        
		    	$scope.deleteUser=function(user){
		              userService.deleteUser(user.User_Id).then(function (data){
		              
		              	if(data.data.status===200)
		                    {

		                    	$scope.action="is deleted";
		                    	$scope.hideSuccess=false;
			                    $scope.SuccessMessage=user.Name;
			                    $scope.role=user.RoleName;
			                    $timeout(function () { $scope.hideSuccess = true; }, 3000);
		                    	userService.getUsers().then(function(data){
	                  			$scope.UserResult=data.data;
	                  			$scope.ReloadUsertable();   
	                  			});
		                    }
		                    else
		                    {
		                    	showErrorMessage(user.Name);
		                    } 
		                  
		              });            
		          }

		        $scope.viewUserProfile = function (user) {
		               	localStorage.removeItem("pagename"); 
 						dataFactory.setUserRole(user.Role);
		           	   dataFactory.setUserId(user.User_Id);
		           	    dataFactory.setPreviousPageName("User");
		               $location.url("/user/userprofile");
		        }
		       
	             //pausing user...
              	$scope.pauseUser=function(user){
		                var userName=user.Name;
		                if(user.IsPause==true)
		                {
		                  	user.IsPause=false;
		                  	$scope.action="is paused";
		                }
		                else{
		                  	user.IsPause=true;
		                  	$scope.action="is played";
		                }
		                userService.saveUser(user).then(function (response){
		                
		                     if(response.status === 200)
                              {
                                  	$scope.hideSuccess=false;
                                  	$scope.SuccessMessage=  userName;
                                  	$timeout(function () { $scope.hideSuccess = true; }, 3000);                                  
                              }
                              else
                              {
                                  $scope.showErrorMessage(response.data.err_msg);
                              }
                               		                      
		                });
              	}
              	function showErrorMessage(message)
	            {
	             $scope.errorMessage = message;
	             $scope.hideSuccess=true;
	             $scope.showeerror = true;
	             $timeout(function () { $scope.errorMessage = ''; $scope.showeerror = false;}, 3000);
	            } 
			 
				$scope.Adduser = function(){
				 $location.url("/user/adduser");
				}

				$scope.SearchByEvent = function(selected)
		  		{		  			
		  		   $scope.users=JSON.parse(localStorage.getItem("userobj"));		
		  			if(selected!==undefined && selected!=null)
		  			{	
		  				localStorage.removeItem("alluser");	  			  							
		  				$scope.UserSelected=selected;  
		  				if(selected!="alluser"){
		  					$scope.IsonLoad = false; 
		  			    }
		  			}
		  			else{
		  				if(dataFactory.getUserRole()!==undefined && dataFactory.getUserRole()!=null)
				  		{
				  			$scope.UserSelected=parseInt(dataFactory.getUserRole());
				  		}
		  				localStorage.removeItem("alluser");	  			
		  			}

				  	if($scope.UserSelected != null && $scope.UserSelected !== undefined && $scope.UserSelected != "")
				  	{
				  		if($scope.UserSelected=="allposuser")
				  		{
				  			dataFactory.setAllUser("allposuser");
				  			$scope.IsonLoad = false;				  			
				  			$scope.UserResult = $scope.users.filter(function (obj) {
				  				
					              if (obj.Role ==3 || obj.Role ==4) {
					                  return obj;
					              }
					          });
				  		}
				  		else if($scope.UserSelected=="alluser"){
				  			dataFactory.setAllUser("alluser");
				  			$scope.UserResult = $scope.users.filter(function (obj) {				  				
					                  return obj;				              
					          });
				  		}
				  		else
				  		{
				  			$scope.UserResult = $scope.users.filter(function (obj) {
				  				$scope.IsonLoad = false;
					              if (obj.Role === $scope.UserSelected) {
					                  return obj;
					              }
					          });
				  		}

				  			
				  	}
				  	else 
				  	{
				  		$scope.UserResult = $scope.users;
				  	}	
				  	
				 if($scope.userdatatable!=null && $scope.userdatatable!=undefined){
                     $scope.userdatatable.destroy();  
                    }	
                       if($scope.IsonLoad !== true)	{ 
                       	localStorage.removeItem("userrole"); 		
					  	setTimeout(function() {  
							$scope.userdatatable = $('#userTable').DataTable( {	
								    "paging":   true,				      
							        "info":     true,
							         "searching": true,
							         "pageLength":10,
							         "lengthMenu": [[10, 20, 30], [10, 20, 30]],
							           language: {
							           	emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
									        searchPlaceholder: searchtext,
									          search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
									          infoFiltered: " "
									    }
							         	  
								});


					           },200); 
					  }

		  		}
    });	   	 
 })



