define(function(require){
	angular.module("app").controller("adduserCtrl",function($window,userService,$filter,apiService,$scope,$location,$state,$rootScope,dataFactory){
             $scope.activeTab = 1;
                  $rootScope.islogin = false;	
                  $scope.user={};	
                  $scope.validEmail={};
                  $scope.checkEmail=false; 
                  $scope.ddlRoleId=1;
                  $scope.downloadstatus=false;
                  $scope.QRCodeStatus=true;
                  $scope.isFocused=false;

                  $scope.roleTypes = [
                        { "RoleTypeID": 1, "Name": "Admin" },
                        { "RoleTypeID": 2, "Name": "Normal User" },
                        { "RoleTypeID": 3, "Name": "POS User" },
                        { "RoleTypeID": 4, "Name": "POS Admin" },
          	      ];

                  $scope.setActiveTab = function(tabToSet) {      
                        $scope.activeTab = tabToSet;
                  }
          	  	  $scope.backToUser = function(){
          	  		       $location.url("/users");
          	  	  }
                  //add user detail
                  $scope.addUser=function(user){                   
                                  
                    if(user.selectedRole.RoleTypeID==1 ||user.selectedRole.RoleTypeID==2)
                    {
                          if(user.Password == user.cnfPassword)
                          {
                              $scope.user.IsPause=true;
                              $scope.user.Role=$scope.user.selectedRole.RoleTypeID;
                              $scope.user.Status=1; 
                              dataFactory.setRole($scope.user.selectedRole.Name);           
                              if(!$scope.checkEmail){         
                              userService.saveUser($scope.user).then(function(response){  
                                                           
                                    if(response.data.status==200)
                                    {                          
                                      $location.url('/users?createUser='+$scope.user.Name);
                                    }
                                    else{
                                      $location.url('/users?IsMatchedData='+response.data.data.err_msg);
                                    }
                              });
                          }
                          }
                          else
                          {
                            return false;
                          }
                    }
                    else
                    {
                      if(user.QRCode !=undefined &&user.QRCode !=""  )
                          {
                             $scope.user.IsPause=true;
                              $scope.user.Role=user.selectedRole.RoleTypeID;
                              $scope.user.Status=1; 
                              dataFactory.setRole($scope.user.selectedRole.Name);           
                               if(!$scope.checkEmail && !$scope.QRCodeStatus){            
                              userService.saveUser($scope.user).then(function(response){                               
                                             
                                        if(response.data.status==200)
                                        {                          
                                   $location.url('/users?createUser='+$scope.user.Name);
                                        }
                                        else{
                                          $location.url('/users?IsMatchedData='+response.data.data.err_msg);
                                        }
                              });
                          }
                    }
                    }
                      
                  }
                  function FormValidation(){                    
                    var formValid = true;
                    if($scope.user.Email==undefined)
                      {
                        formValid =false;
                      }
                      
                    if($scope.user.Password==undefined)
                      {
                        formValid=false;
                      }
                     
                    if (formValid) {
                          return true;
                    }
                    else {
                         return false;
                    }
                  }
                    //email validate
                    $scope.CheckEmail=function(){
                          if($scope.user.Email!==undefined)
                          {
                           
                                      $scope.validEmail.Email=$scope.user.Email;
                                      userService.isExistEmail($scope.validEmail).then(function(response){
                                 
                                            if(response.data.data==true)
                                            {
                                             $scope.checkEmail=true; 

                                            }
                                            else{
                                                $scope.checkEmail=false; 
                                            }
                                      });
                          }
                          else
                          {
                            $scope.checkEmail=false;
                          }

                    }

                    $scope.newPassword=function(){
                      if($scope.user.Password!=$scope.user.cnfPassword)
                      {
                        $scope.notMatch=true;
                      }
                      else
                      {
                         $scope.notMatch=false;
                      }
                    }
                    $scope.cnfPassword=function(){
                      if($scope.user.Password==$scope.user.cnfPassword)
                      {
                        $scope.notMatch=false;
                      }
                      else{
                        $scope.notMatch=true;
                      }
                    }

                    $scope.IsRoleSelected=function(){                     
                      $scope.ddlRoleId=$scope.user.selectedRole.RoleTypeID;                
                    }
                     $scope.ReloadQRCode=function(){
                        $scope.qrCodeString ='empty qr code'; 
                        $scope.size = 135;
                        $scope.version = '1';
                    }
                    $scope.generadeQRCode=function(user){           
                      if( user.QRCode!==undefined &&  user.QRCode!="")
                      {    
                        $scope.qrCodeString = user.QRCode.toString();            
                      $scope.size = 130;
                      $scope.correctionLevel = 'M';
                      $scope.version = '5';
                      $scope.status=false;
                    }
                        else
                        {
                          $scope.ReloadQRCode()
                        }

                    }

                  $scope.downloadQrCode=function(){
                    var url=$('.qrcode-link').attr('href');
                    var qrcodename=$scope.user.Name;
                    if(qrcodename===undefined)
                        var qrcodename='qrcode';
                    $(".qrcode").prop("href", url);
                    $(".qrcode").prop("download", qrcodename);
                  } 

                  $scope.IsValidQRCode = function(){    
                    if($scope.user.QRCode != undefined &&($scope.user.QRCode + '').length >= 6)
                    {
                        userService.IsValidQRCode($scope.user).then(function(data){
                          if(data.status == 200)
                          {
                            $scope.QRCodeStatus=data.data;
                            
                          }
                        });
                    }
                  }
 
              $scope.FocusOut=function(user) {
                $scope.generadeQRCode(user);
              };
             $scope.ReloadQRCode();      
                  
                  
 

       
 })}
	);