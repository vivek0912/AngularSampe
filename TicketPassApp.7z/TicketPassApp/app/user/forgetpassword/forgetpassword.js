define(function(require){
	angular.module("app").
		controller("forgetpasswordCtrl",function($window,authenticationService,apiService,$scope,$location,$state,$rootScope,$timeout){
			$scope.sucessmessage=false;
			$rootScope.islogin = true;
			$scope.InvalideMsg=false;
			$scope.messageexpire=false;
			$scope.messagesuccess=false;
			$scope.message="";
			$scope.email={};
			$scope.reset={};
			var token=$location.search().token;
			$(".content ").css("margin-left","0");

	 		$scope.forgotPassword = function (){
	 			if($scope.email.Email!==undefined)
	 			{
	 				authenticationService.forgotPassword($scope.email).then(function(response){
	 					
	 					if(response.status!==401)
		    	 		{	
		    	 			$scope.sucessmessage=true;
		    	  	 	
				  		}
				  		else
				  		{
				  			$scope.InvalideMsg=true;
				  		}
	 				})
	 			}
	 			else
	 			{
	 				return false;
	 				
	 			}
  
     		};

				$scope.resetPassword=function(reset){
								 
					authenticationService.setPassword(reset.Password,token).then(function(response){
											
						if(response.status== 200)
						{
							$scope.messagesuccess=true;
					  		$timeout(function(){$scope.messageexpire=false, $location.url("/user/login")},3000);
						}
						else 
						{
							
							$scope.messageexpire=true;
					  		$timeout(function(){ $scope.messageexpire=false,$location.url("/user/login")},3000);
						}
						
					})
				}
				


							
	})
});