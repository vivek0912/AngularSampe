define(function(require){
	angular.module("app").
		controller("resetpasswordCtrl",function($window,authenticationService,apiService,$scope,$location,$state,$rootScope){
			

		})
	});