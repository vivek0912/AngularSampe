define(function(require){
	angular.module("app").controller("profilepageCtrl",function($window,userService,apiService,$scope,$location,$state,$rootScope,dataFactory,$route){
 
          		$scope.sucessmessage=false;
          	 	$rootScope.islogin = false;
              $scope.checkPwd={};
              $scope.hideNewPwd=false;
              $scope.ShowNewPwd=false;
              $scope.hidePwd=false;
              $scope.ShowPwd=false;
              $scope.hideCnfPwd=true;
              $scope.ShowCnfPwd=false;
              $scope.newPwd=false 
          	 	$scope.userId = $rootScope.loginUser.User_id;
          	 	 userService.getUser($scope.userId).then(function(data){                          
                           $scope.user=data.data.data;
                           $scope.email = $scope.user.Email;
                           $scope.role = $scope.user.RoleName;
                           $scope.status = $scope.user.UserStatus;
                           $scope.user.Password = "";
                   })

           		 $scope.saveUser=function(user){	
                  
                if(($scope.user.CurrentPassword!==undefined && $scope.user.CurrentPassword!="" )|| ($scope.user.newPassword !==undefined 
                     && $scope.user.newPassword!="")|| ($scope.user.cnfPassword!==undefined && $scope.user.cnfPassword!=""))
                  {
                          if($scope.hidePwd==true)
                          {
                              if($scope.user.newPassword===undefined)
                                  $scope.user.newPassword="";
                             	if($scope.user.newPassword===$scope.user.cnfPassword)
                    { 	
                          $scope.user.Password = $scope.user.newPassword;
                          userService.saveUser(user).then(function (data){                                     	 
            	             if (data.data.status === 200 || data.data.status === 201) {
                            $rootScope.$on("$stateChangeSuccess",function(){
                              $rootScope.loginUser.Name=$scope.user.Name;
                            })                
                                         $location.url("/dashboard");
                             }
                          });            
                      }
                              else{
                                $scope.hideNewPwd=true;
                                $scope.ShowCnfPwd=true;
                      }
                }
                    }
                    else{
                      
                         userService.saveUser(user).then(function (data){                                        
                                     if (data.data.status === 200 || data.data.status === 201) {
                                      $rootScope.$on("$stateChangeSuccess",function(){
                                        $rootScope.loginUser.Name=$scope.user.Name;
                                      })                
                                         $location.url("/dashboard");
                                       }
                                    });
                    }         
                      
                }

                     $scope.viewUser = function (userId) {           	    	  
                     	   dataFactory.setUserId(userId);
                         $location.path("/user/profilepage");
                    }

          		$scope.cancel = function()
          		{
          		   $location.url("/dashboard");
          		}
          		
              $scope.CheckPassword=function(user){
                   if($scope.user.CurrentPassword!==undefined && $scope.user.CurrentPassword!="")
                  {
                          $scope.checkPwd.User_Id= $rootScope.loginUser.User_id;
                          $scope.checkPwd.Password=$scope.user.CurrentPassword;
                          userService.isValidPassword($scope.checkPwd).then(function(response){
                                if(response.data.data ===true)
                            {
                                    $scope.hidePwd=true;
                                    $scope.ShowPwd=false; 
                            }
                            else{
                                    $scope.hidePwd=false;
                                    $scope.ShowPwd=true;
                                    
                            }
                      });
                  }
                  else
                  {
                    $scope.hideNewPwd=false;
                    $scope.ShowCnfPwd=false;
                      $scope.hidePwd=false;
                      $scope.ShowPwd=false;
                  }
              }
              $scope.newPassword=function(){
             
                  var passPattern=/^[A-Za-z0-9 ]{7,18}$/;
                  if($scope.user.newPassword!= undefined && passPattern.test($scope.user.newPassword))
              {
                    $scope.hideNewPwd=false;
                          $scope.ShowNewPwd=true;
                            if($scope.user.cnfPassword!= undefined)
                            { 
                              $scope.hideCnfPwd=false;
                                    $scope.ShowCnfPwd=false;
                            }
              }
              else
              {
                    if($scope.user.newPassword=="")
                      $scope.hideNewPwd=false;
                    else
                      $scope.hideNewPwd=true;
                          $scope.ShowNewPwd=false;
              }
            }
            $scope.cnfPassword=function(){
             
                  if($scope.user.cnfPassword!= undefined && $scope.user.cnfPassword!="" )
              {

                          $scope.hideCnfPwd=false;
                          $scope.ShowCnfPwd=false;
              }
                  else
                  {
                    if($scope.user.cnfPassword=="" || $scope.user.cnfPassword===undefined)
                    {
                      $scope.hideCnfPwd=true;
                      $scope.ShowCnfPwd=false;
                    }
                    else
                      $scope.ShowCnfPwd=true;
                          
              }
        }

   
	 	
   })
});