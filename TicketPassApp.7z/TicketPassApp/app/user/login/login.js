define(function(require){
	angular.module("app").
	controller("loginCtrl",function($window,authenticationService,apiService,session,$scope,$location,$state,$rootScope){
		$scope.UserDetails = {};
		$rootScope.islogin = true;
 		$scope.InvalideMsg=false;
		 
		$(".content" ).addClass( "hideleftnav" );		 
		 session.destroy();	
		 localStorage.clear();	 
         localStorage.removeItem("eventId");  
         localStorage.removeItem("siteserverId");
         localStorage.removeItem("exhibitor");
         localStorage.removeItem("companyId");
		 localStorage.removeItem("activeTab"); 
		 localStorage.removeItem("responseFormdetails"); 
			$scope.loginUser = function()
			{
						
					authenticationService.login($scope.UserDetails).then(function (AuthTockenobject) {
						if(AuthTockenobject.status!=401)
		    	 	 	{	
		    	  			session.create(AuthTockenobject);	    	  	
							/*$location.url("/events");*/
							$location.url("/dashboard");
				  		}
				  		else
				  		{
				  		 	$scope.InvalideMsg=true;
				  		}
					});			
			}
		

		$scope.validate=function(){
			$scope.alertMessage=false;
		}
			
	});
		
});