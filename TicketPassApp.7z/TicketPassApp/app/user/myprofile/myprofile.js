define(function(require){
	angular.module("app").controller("myprofileCtrl",function($window,usersService,apiService,$scope,$location,$state,$rootScope){
   $scope.activeTab = 1;
        $rootScope.islogin = false;		 
        $scope.setActiveTab = function(tabToSet) {      
          $scope.activeTab = tabToSet;
        }
	  	$scope.backToUser = function(){
	  		$location.url("/users");
	  	}
 })}
	);