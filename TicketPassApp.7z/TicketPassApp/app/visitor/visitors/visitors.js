define(function(require){
	angular.module("app").controller("visitorsCtrl",function($window,visitorService,eventService,apiService,
		dataFactory,$scope,$location,$timeout,$rootScope,$translate,filterFilter){ 
		 
		  $scope.visitors=-[];
		  $scope.visitorsResule =[];
		  $scope.EvenSelected =[];	
		  $scope.deletedVisitors =[];
		  $scope.visitordeleted = false;
		  $scope.visitormessageshow = false;
		  $scope.noitemsselected = 'no item selected';	
		  $scope.visitorupdatedmessageshow = false;	  
		  $scope.errorDeleteMessage =='';
		  $scope.showeerror = false;
		  $scope.deletedSingleVisitor=false;
		  $scope.visitordataTable;
		  $scope.events =[];
		  $scope.deleteVisitors="";
		  $scope.SingleVisitorDeleted=[];
		  $scope.SelectedEventId;
		  $scope.createvisitor=false;
		  $scope.totalItems=0;
		  $scope.visitorProfile=dataFactory.getvisitorProfile();
		  localStorage.removeItem("allexhibitor");
		  localStorage.removeItem("alluser");
		  localStorage.removeItem("eventtype"); 
		  //$scope.totalDisplayed=20;
		    $scope.PageOptions = {
		      10: 10,
		      20: 20,
		      30: 30      
		    };
		     //dataFactory.setSelectedEvent(undefined);

		  if($scope.visitorProfile!==undefined && $scope.visitorProfile!=null)
		  {
		  	$scope.createvisitor=true;
		  	if($scope.visitorProfile.profilestatus=="iscreated")
		  	{
		  	  $scope.createvisitor=true;
		  	  $timeout(function () { $scope.createvisitor=false;dataFactory.setvisitorProfile(null)}, 3000);
		  	}
		  	
		  }
	

	  	  setTimeout(function() {                  
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });

            $("#menu-toggle").click(function(e) {                        
            $(".content").toggleClass("toggled");
            e.preventDefault();
            });
             
            $("#menu-toggle").click(function(e) {            
            $("#sidebar").toggleClass("toggled");
            e.preventDefault();
            });
 

        }, 1500);

	  	  var noitemfounds = "";
	  	  var searchkeyword = "";

         $translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
         });
         $translate(['searchvisitors']).then(function (translations) {
                      searchtext = translations.searchvisitors;                      
         });

		  $scope.GetVisitors = function(){
		    eventService.getEventsforVisitor().then(function(data){	
		    	$scope.events=data.data;		    				  		
			  		 if(dataFactory.getAllVisitor()!="All" )
		             {
		             	if(data.data.length > 0)
		                    $scope.EvenSelected = data.data[0];
	                    $scope.Event_Id=$scope.EvenSelected.Event_Id;
	                    $scope.SelectedEventId = $scope.EvenSelected.Event_Id;
	                    $scope.eventId=dataFactory.getEventId();    
	                    if($scope.eventId!==undefined && $scope.eventId != null)
	                    {
	                      $scope.SelectedEventId =parseInt($scope.eventId);
	                       var selectedEvent = $scope.events.filter(function(e) { return e.Event_Id === $scope.SelectedEventId; });
	                       $scope.EvenSelected= selectedEvent[0];
	                       $scope.Event_Id=$scope.EvenSelected.Event_Id; 
	                        $scope.nodata=true;             
	                    }
	                }
	                else{
	                  $scope.Event_Id=0;
	                }
			  		
			  		if($scope.events.length > 0)
			  		{
					 visitorService.getFilteredVisitors('All Visitors', $scope.Event_Id).then(function(data){		 	   
					 	  if(data.length>0)
					 	  {
					 	  	//
					 	  }
					 	   $scope.visitors=data;
					 	   $scope.visitormessageshow = false;
					 	   $scope.visitorsResule =data;			 	    
				 	   	// pagination controls
				 	   		$scope.currentPage = 1;
							$scope.totalItems = $scope.visitors.length;
							$scope.entryLimit = 10; // items per page
							$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
	                       $scope.maxSize = 10; //Number of pager buttons to show
                        if( $scope.visitors.length == 0){
	                        $scope.nodata=false;   
	                      }
	                      else
	                      {
	                      	$scope.nodata=true;  
	                      }
						
				 	   if (!$scope.visitordeleted)
				 	   {
					 	   
				 		}
				 		else
				 		{
				 			$scope.noitemsselected = 'no item selected'; 		  		
				 		}
				 		$scope.visitordeleted  = false;
				 		localStorage.removeItem("eventid");
				 	  });
					}
				});


			}
		 $scope.GetVisitors();
		$scope.SearchByEvent = function(searchString)
		  {
		  	if($scope.EvenSelected != null)
		  	{

		  		if(($scope.SearchString==null)|| ($scope.SearchString=="")){  
		  		   searchresult = "All Visitors";  
	               $scope.GetFilteredVisitors(searchresult);
	           }
	           else
	           {
	           	searchresult = $scope.SearchString;  
	            $scope.GetFilteredVisitors(searchresult);
	           }
		  	}
		  	else 
		  	{
		  		 if(($scope.SearchString==null)|| ($scope.SearchString=="")){  
		  		   searchresult = "All Visitors"; 
		  		   dataFactory.setAllVisitor("All"); 
	               $scope.GetFilteredVisitors(searchresult);
	           }
		  		else
		  		{
		  			searchresult = $scope.SearchString; 
		  			$scope.GetFilteredVisitors(searchresult);
		  		}		  		
		  		$scope.visitorsResule = $scope.visitors;
		  	}		  	
		  }
		  $scope.BindVisitors = function(){
		  	visitorService.getFilteredVisitors('All Visitors',$scope.EvenSelected.Event_Id).then(function(data){		 	   
					 	   $scope.visitors=data;
					 	   $scope.visitormessageshow = false;
					 	   $scope.visitorsResule =data;			 	    
				 	   	// pagination controls
				 	   		$scope.currentPage = 1;
							$scope.totalItems = $scope.visitors.length;
							$scope.entryLimit = 10; // items per page
							$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
	                        $scope.maxSize = 10; //Number of pager buttons to show
					 	  if(data.length>0)
					 	  {
					 	  	$scope.EvenSelected = data[0];
					  	    $scope.SelectedEventId = $scope.EvenSelected.Event_Id;
					  		 $scope.eventId=dataFactory.getEventId();    
		                    if($scope.eventId!==undefined && $scope.eventId != null)
		                    {
		                      $scope.SelectedEventId =parseInt($scope.eventId);
		                       var selectedEvent = $scope.events.filter(function(e) { return e.Event_Id === $scope.SelectedEventId; });
		                       $scope.EvenSelected= selectedEvent[0]; 
		                        $scope.nodata=true;             
		                    }
					 	  }	                        
                      if( $scope.visitors.length == 0){
	                        $scope.nodata=false;   
	                      }
	                      else
	                      {
	                      	$scope.nodata=true;  
	                      }
							$('#visitorTable').destroy();
							setTimeout(function() {  
	                           var visitordattable= $('#visitorTable').DataTable( { 
	                              "paging":   false,             
	                              "info":     true,
	                              "searching": false,
	                              "pageLength":10,
	                              "ordering": false,
	                              "bInfo" : false,
	                              "lengthMenu": [[10, 20, 30], [10, 20, 30]],
	                                language: {
	                                	emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
	                                        searchPlaceholder:  searchtext,
	                                        search: ' <i class="fa fa-search" aria-hidden="true"></i> ',
	                                        infoFiltered: " "
	                                      }      
	                            });
	                          },200);

						
				 	   if (!$scope.visitordeleted)
				 	   {  
				 	   }
				 		else
				 		{
				 			$scope.noitemsselected = 'no item selected'; 		
				 		}
				 		$scope.visitordeleted  = false;
				 	  });
		  }

		  $scope.DeleteMultiple = function(){
		  	
		  	var list = $scope.visitorsResule.filter(function (obj) {
			              if (obj.checked !== undefined && obj.checked === true) {
			                  return obj;
			              }
			          });
		  	if(list.length==1)
		  		$scope.singleItemSelected=true;
		  	else
		  		$scope.singleItemSelected=false;
		  	if(list.length > 0)
		  	{
			  	visitorService.deletemMultipleVisitor(list).then(function(Response){
			  		
			  		$scope.deleteVisitors="";
			  		angular.forEach(list, function(value){
			  			$scope.deleteVisitors += value.Name+',';
			  			if(list.length==1)
		  					$scope.EventName=value.Event_Name;
			  		})

			  		$scope.deleteVisitors= $scope.deleteVisitors.substring(0, $scope.deleteVisitors.length - 1);

			  		if(Response.data.status === 200)
			  		{
			  			$scope.BindVisitors();
			  			$scope.ShowDeletedMessage();			  			
			  		}
			  		else
			  		{
			  			$scope.showErrorMessage(Response.data.err_msg);
			  		}


			  	});
			}
		  }

		  $scope.showErrorMessage = function(message)
		  {
		  		$scope.errorDeleteMessage = message;
		  		$scope.showeerror = true;
		  	 $timeout(function () {
			    $scope.errorDeleteMessage = '';
			    $scope.showeerror = false;
			}, 3000);
		  }

		  $scope.ShowDeletedMessage = function()
		  {		  		
		  	  
		  	if($scope.singleItemSelected==true)
		  		$scope.deletedSingleVisitor=true;
		  	else
		  		$scope.deletedMultipleVisitorMessage=true;
		  		$scope.visitordeleted = true;
  				$timeout(function () {
			    	$scope.deletedMultipleVisitorMessage = false;
			    	$scope.deletedSingleVisitor=false;
			}, 3000);
		  }
		  $scope.ShowChangesFromProfile = function()
		  {
		  	if($scope.deletedVisitors.length == 0)
		  	{
		  		var visitor = dataFactory.getvisitorProfile();
		  		if(visitor != undefined && visitor != '')
		  			if(visitor.profilestatus=="isdeleted"){
		  				$scope.deletedVisitors.push(visitor);
		  			}	  			
		  	}
		  	if($scope.deletedVisitors != undefined && $scope.deletedVisitors.length > 0)
		  	{		  		
		  		if($scope.deletedVisitors[0].isupdated !== undefined && $scope.deletedVisitors[0].isupdated === true)
		  			$scope.visitorupdatedmessageshow = true;	

		  		else{
		  			if(dataFactory.getPreviousPageName()!="visitorpage"){ 
		  		    dataFactory.setPreviousPageName("");
		  			$scope.visitormessageshow = true;
		  		}}

		  		$timeout(function () {
				    $scope.visitorupdatedmessageshow = false;
				    $scope.visitormessageshow = false;
				    $scope.deletedVisitors =[];
				    dataFactory.setvisitor('');
				}, 3000);
		  	}
		  	else
		  		$scope.deletedVisitors = [];
		  		dataFactory.setvisitor('');
		  }

		  $scope.DeleteVisitor = function(visitorfordelete){		  
		  	$scope.SingleVisitorDeleted=[];
		  	$scope.SingleVisitorDeleted.push(visitorfordelete);
		  	visitorService.deleteVisitor(visitorfordelete.Visitor_Id).then(function(Response){
		  		if(Response.data.status === 200)
		  		{		  			
		  			$scope.BindVisitors();	
		  			$scope.visitordeleted = true;
		  			$scope.deletedVisitorMessage=true	
		  			$timeout(function () {
			    	$scope.deletedVisitorMessage = false;
			   }, 3000);	  				
		  		}
		  		else
		  		{
		  			$scope.showErrorMessage(visitorfordelete.Name);
		  		}

		  	});
		  }

		   $scope.viewCompany = function (company) {
		   		localStorage.removeItem("visitorId");
               dataFactory.setCompanyId(company.Visitor_Id);
               $location.url("/survey/visitorprofile");
          }

		  $scope.VisitorProfilc = function(visitor)
		  {
		  	localStorage.removeItem("companyId");
		    if(visitor!==undefined)
		    {
		          dataFactory.setEventId(visitor.Event_Id);
		    } 
		  	dataFactory.setvisitorId(visitor.Visitor_Id);
		  	dataFactory.setvisitorObject(visitor);
		  	$location.url("/survey/visitorprofile");
		  }
		  $scope.visitorCheckedchanged = function(){
		  	var list = $scope.visitorsResule.filter(function (obj) {
			              if (obj.checked !== undefined && obj.checked === true) {
			                  return obj;
			              }
			          });
		  	if(list.length == 1)
		  		$scope.noitemsselected = list.length + " item selected";
		  	else if (list.length > 1)
		  		$scope.noitemsselected = list.length + " items selected";
		  	else 
		  		$scope.noitemsselected = 'no item selected';
		  }
		    
		$scope.ShowChangesFromProfile();

		$scope.addvisitor = function()
	 	{
		 $location.url("/company/addcompany");
		}
		$scope.gotocompany = function()
		{			
		 $location.url("/company/addcompany");
		}

		 $scope.GetFilteredVisitors = function(searchresult){ 	
				if((searchresult==null)|| (searchresult=="")){    
			               searchresult = "All Visitors";
			    }
			    if($scope.EvenSelected !=null)
			    {
			    	$scope.EventID=$scope.EvenSelected.Event_Id;
			    	 localStorage.removeItem("allvisitor");
			    }
			    else
			    {
			    	$scope.EventID=0;

			    }
		 		//dataFactory.setSelectedEvent($scope.EventID);     
                visitorService.getFilteredVisitors(searchresult,$scope.EventID).then(function(data){
                $scope.visitors= data;
                if( $scope.visitors.length == 0){
                    $scope.nodata=false;   
                  }
                  else
                  {
                  	$scope.nodata=true;  
                  }

                $scope.currentPage = 1;
				$scope.totalItems = $scope.visitors.length;
				$scope.entryLimit = 10; // items per page
				$scope.noOfPages = Math.ceil($scope.totalItems / $scope.entryLimit);
                 $scope.maxSize = 10; //Number of pager buttons to show
             });
        }
		 

})});
