define(function(require){
angular.module("app").controller("posCtrl",function($window,posService,$scope,$location,$rootScope,$translate){
	$rootScope.islogin = false;
	 

		 setTimeout(function() { 
                 
           $('[data-toggle=collapse]').click(function(){
            // toggle icon
            $(this).find("i").toggleClass("fa-angle-down");
            });
             
             $("#menu-toggle").click(function(e) {                          
            e.preventDefault();
            $(".content").toggleClass("toggled");
            });
             
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#sidebar").toggleClass("toggled");
            }); 

        }, 1500);

 				setTimeout(function() {  	  	 
				  $(".systm-setting .submenu").addClass("in");
				 $(".systm-setting .Toggleonload").removeClass("collapsed");
				  $(".systm-setting .Toggleonload i").addClass("fa-angle-down");  
				
				},300);
 	 localStorage.removeItem("allvisitor"); 
     localStorage.removeItem("alluser") 
     localStorage.removeItem("allexhibitor");
     localStorage.removeItem("eventtype"); 
        var noitemfounds = "";
        var searchtext = "";

         $translate(['itemnotfound']).then(function (translations) {
                      noitemfounds = translations.itemnotfound;                      
                    });
         $translate(['searchposvisitors']).then(function (translations) {
                      searchtext = translations.searchposvisitors;                      
         });

		posService.getPosDetails().then(function (data) {	
			 	 $scope.poss = data.data.data; 	  
		       	 setTimeout(function() {  
					 $('#possTable').DataTable( {	
					    "paging":   true,				      
				        "info":     true,
				         "searching": true,
				         "pageLength":10,
				         "lengthMenu": [[10, 20, 30], [10, 20, 30]],
				         language: {
								emptyTable: '<div class="no-items"><div class="no-items-text">'+ noitemfounds + '</div></div>',
						        searchPlaceholder: searchtext,
						        search: '<i class="fa fa-search" aria-hidden="true"></i> ',
						        infoFiltered: " "
						      } 
				         
					} );
					 $('#possTable').wrap('<div class="responsive-datatable" />'); 

		           },200);      
       });     



 })}
);