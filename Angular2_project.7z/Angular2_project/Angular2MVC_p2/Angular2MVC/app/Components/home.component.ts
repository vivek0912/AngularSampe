﻿import { Component } from "@angular/core";

@Component({
    template: `<img src="../../images/users.png" style="text-align:center"/>
               <!--<button class="btn btn-primary" (click)="IdontExist()">ErrorButton</button>-->
               `
})

export class HomeComponent{
}